export type UserRole = 'CUSTOMER' | 'VENDOR' | 'ADMIN';

export interface User {
  id: string;
  name: string;
  firstName?: string;
  lastName?: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar?: string;
  city?: string;
  vendorId?: string; // If role is VENDOR
  goCashBalance: number;
  savedPackageIds?: string[];
  createdAt?: string;
}

export interface Destination {
  id: string;
  name: string;
  tagline: string;
  state: string;
  country: string;
  image: string;
  description: string;
  bestTimeToVisit: string;
  popularFor: string[];
  startingPrice: number;
  featured: boolean;
}

export interface DayItinerary {
  day: number;
  title: string;
  description: string;
  mealsIncluded: string[];
  activities: string[];
  stayHotel?: string;
}

export interface TravelPackage {
  id: string;
  name: string;
  destination: string;
  duration: string; // e.g., "3 Nights / 4 Days"
  durationDays: number;
  startingPrice: number;
  discountedPrice?: number;
  badge?: string; // e.g., "Bestseller", "Top Rated"
  coverImage: string;
  gallery: string[];
  overview: string;
  itinerary: DayItinerary[];
  hotels: string[];
  transportation: string;
  meals: string;
  activities: string[];
  inclusions: string[];
  exclusions: string[];
  terms: string[];
  groupSize: string;
  category: 'BEACH' | 'HILL_STATION' | 'HERITAGE' | 'WILDLIFE' | 'PILGRIMAGE' | 'ADVENTURE' | 'HONEYMOON';
  status: 'ACTIVE' | 'DRAFT' | 'SOLD_OUT';
  featured: boolean;
  rating: number;
  reviewsCount: number;
}

export interface HotelRoom {
  id: string;
  name: string; // e.g., "Deluxe AC Sea View", "Executive Suite"
  capacity: number;
  bedType: string;
  pricePerNight: number;
  amenities: string[];
  image: string;
  availableRooms: number;
}

export interface Hotel {
  id: string;
  vendorId: string;
  name: string;
  location: string; // e.g., "Old Digha", "New Digha", "Mandarmani Beach"
  address: string;
  distanceFromBeach: string;
  rating: number;
  reviewsCount: number;
  images: string[];
  description: string;
  amenities: string[];
  startingPrice: number;
  rooms: HotelRoom[];
  policies: {
    checkIn: string;
    checkOut: string;
    cancellation: string;
  };
  contactPhone: string;
  featured: boolean;
}

export interface TransportService {
  id: string;
  name: string; // e.g., "Swift Dzire (AC)", "Innova Crysta"
  category: 'SEDAN' | 'SUV' | 'TEMPO' | 'LUXURY';
  seatingCapacity: number;
  luggageCapacity: string;
  basePrice: number;
  pricePerKm?: number;
  image: string;
  features: string[];
  serviceType: 'PICKUP_DROP' | 'RAILWAY_TRANSFER' | 'LOCAL_SIGHTSEEING' | 'OUTSTATION';
  available: boolean;
}

export interface SightseeingTour {
  id: string;
  name: string;
  destination: string;
  duration: string;
  price: number;
  image: string;
  description: string;
  highlights: string[];
  inclusions: string[];
  pickupPoints: string[];
}

export interface WaterActivity {
  id: string;
  name: string;
  location: string;
  duration: string;
  price: number;
  image: string;
  description: string;
  safetyBriefing: string;
  suitableFor: string;
}

export interface BikeRental {
  id: string;
  name: string; // e.g. "Honda Activa 6G", "Royal Enfield 350"
  type: 'SCOOTER' | 'CRUISER' | 'SPORTS';
  pricePerDay: number;
  securityDeposit: number;
  image: string;
  fuelType: string;
  helmetsIncluded: number;
  pickupLocation: string;
  terms: string[];
  available: boolean;
}

export interface EventService {
  id: string;
  name: string;
  category: 'PARTY' | 'CONFERENCE' | 'BANQUET' | 'DJ' | 'BEVERAGE';
  description: string;
  capacity?: string;
  startingPrice: number;
  image: string;
  features: string[];
}

export interface BookingGuest {
  fullName: string;
  age: number;
  gender: string;
  idProofType?: string;
}

export interface Booking {
  id: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  bookingType: 'PACKAGE' | 'HOTEL' | 'TRANSPORT' | 'ACTIVITY' | 'BIKE' | 'CUSTOM';
  itemId: string;
  itemTitle: string;
  itemSubtitle?: string;
  itemImage?: string;
  vendorId?: string;
  travelDate: string;
  returnDate?: string;
  travellers: number;
  guests: BookingGuest[];
  baseAmount: number;
  taxAmount: number;
  discountAmount: number;
  goCashUsed: number;
  totalAmount: number;
  paymentStatus: 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED';
  bookingStatus: 'CONFIRMED' | 'PROCESSING' | 'CANCELLED' | 'COMPLETED';
  paymentId?: string;
  orderId?: string;
  specialRequests?: string;
  createdAt: string;
}

export interface Enquiry {
  id: string;
  customerId?: string;
  name: string;
  phone: string;
  email: string;
  type: 'CORPORATE' | 'GROUP' | 'CUSTOM_PACKAGE' | 'EVENT' | 'GENERAL';
  destination: string;
  travelDates: string;
  travellersCount: number;
  budgetRange: string;
  transportRequired: boolean;
  hotelRequired: boolean;
  foodRequired: boolean;
  activitiesRequired: boolean;
  message: string;
  status: 'NEW' | 'CONTACTED' | 'QUOTED' | 'CONVERTED' | 'CLOSED';
  adminNotes?: string;
  createdAt: string;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
  verifiedSource: 'Google Reviews' | 'Direct Customer';
  tripType?: string;
}

export interface Coupon {
  code: string;
  discountPercentage: number;
  maxDiscount: number;
  minBookingValue: number;
  description: string;
}

export interface AccountNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'BOOKING' | 'PAYMENT' | 'ENQUIRY' | 'TRIP' | 'OFFER' | 'REFUND';
  read: boolean;
  date: string;
  linkTab?: string;
}

export interface PaymentTransaction {
  id: string;
  paymentId: string;
  orderId: string;
  bookingId: string;
  userId: string;
  amount: number;
  currency: string;
  method: 'UPI' | 'CARD' | 'NETBANKING' | 'WALLET';
  status: 'PAID' | 'PENDING' | 'FAILED' | 'REFUNDED';
  date: string;
  itemTitle: string;
  refundStatus?: 'NONE' | 'REQUESTED' | 'PROCESSING' | 'COMPLETED';
}

export interface InvoiceData {
  invoiceNumber: string;
  bookingId: string;
  paymentId: string;
  bookingDate: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  itemTitle: string;
  itemSubtitle?: string;
  destination: string;
  travelDates: string;
  travellers: number;
  baseAmount: number;
  taxAmount: number;
  discountAmount: number;
  goCashUsed: number;
  totalAmount: number;
  paymentMethod: string;
  paymentStatus: string;
}

export type ServiceCategory = 'hotel' | 'cab' | 'tour' | 'activity' | 'bike';

export interface RecentSearchItem {
  id: string;
  query: string;
  category: ServiceCategory;
  destination: string;
  params: Record<string, any>;
  timestamp: number;
  label: string;
  subtitle?: string;
}

export interface HotelSearchParams {
  destination: string;
  checkIn: string;
  checkOut: string;
  guests: string;
  propertyType?: string;
  priceRange?: [number, number];
  minRating?: number;
  amenities?: string[];
  distance?: string;
}

export interface CabSearchParams {
  tripMode?: 'oneway' | 'roundtrip';
  from: string;
  to: string;
  date: string;
  time: string;
  passengers: string;
  vehicleType?: string;
  acOnly?: boolean;
}

export interface TourSearchParams {
  destination: string;
  travelDate: string;
  duration: string;
  travellers: string;
  category?: string;
  maxPrice?: number;
}

export interface ActivitySearchParams {
  destination: string;
  activityType: string;
  date: string;
  guests: string;
  maxPrice?: number;
}

export interface BikeSearchParams {
  pickupLocation: string;
  pickupDate: string;
  returnDate: string;
  bikeType: string;
  maxPrice?: number;
}

export interface UnifiedSearchParams {
  category: ServiceCategory;
  query?: string;
  destination?: string;
  hotelParams?: HotelSearchParams;
  cabParams?: CabSearchParams;
  tourParams?: TourSearchParams;
  activityParams?: ActivitySearchParams;
  bikeParams?: BikeSearchParams;
}
