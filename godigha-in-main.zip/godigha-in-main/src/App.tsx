import React, { useState, useEffect } from 'react';
import { StorageService } from './services/storage';
import {
  User,
  TravelPackage,
  Hotel,
  HotelRoom,
  TransportService,
  WaterActivity,
  BikeRental,
  SightseeingTour,
  Booking,
  Enquiry,
  UnifiedSearchParams,
  ServiceCategory
} from './types';
import { SearchResultsView } from './components/SearchResultsView';
import { detectCategoryFromQuery } from './services/searchEngine';
import { Header } from './components/Header';
import { WhatsAppRibbon } from './components/WhatsAppRibbon';
import { OurServicesGrid } from './components/OurServicesGrid';
import { ExploreTopTours } from './components/ExploreTopTours';
import { HeroSearch } from './components/HeroSearch';
import { HotelsSection } from './components/HotelsSection';
import { TransportationSection } from './components/TransportationSection';
import { ExperiencesSection } from './components/ExperiencesSection';
import { CorporateEventsSection } from './components/CorporateEventsSection';
import { ReviewsSection } from './components/ReviewsSection';
import { Footer } from './components/Footer';
import { BottomNav } from './components/BottomNav';
import { PackageModal } from './components/PackageModal';
import { BookingModal } from './components/BookingModal';
import { PaymentModal } from './components/PaymentModal';
import { CustomerDashboard } from './components/CustomerDashboard';
import { VendorPortal } from './components/VendorPortal';
import { AdminPortal } from './components/AdminPortal';
import { OffersSection } from './components/OffersSection';
import { DestinationsSection } from './components/DestinationsSection';
import { PackagesList } from './components/PackagesList';
import { QuickPlanModal } from './components/QuickPlanModal';
import { WalletModal } from './components/WalletModal';
import { LoginModal } from './components/LoginModal';
import { GuestPromptModal } from './components/GuestPromptModal';
import { TripsView } from './components/TripsView';
import { SupportView } from './components/SupportView';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(StorageService.getCurrentUser());
  const [currentView, setCurrentView] = useState<string>('home');
  const [customerActiveTab, setCustomerActiveTab] = useState<string>('dashboard');
  const [packages, setPackages] = useState<TravelPackage[]>(StorageService.getPackages());
  const [hotels, setHotels] = useState<Hotel[]>(StorageService.getHotels());
  const [transports, setTransports] = useState<TransportService[]>(StorageService.getTransports());
  const [activities, setActivities] = useState<WaterActivity[]>(StorageService.getActivities());
  const [bikes, setBikes] = useState<BikeRental[]>(StorageService.getBikes());
  const [sightseeing, setSightseeing] = useState<SightseeingTour[]>(StorageService.getSightseeing());
  const [events, setEvents] = useState(StorageService.getEvents());
  const [destinations, setDestinations] = useState(StorageService.getDestinations());
  const [reviews, setReviews] = useState(StorageService.getReviews());

  // Modals state
  const [selectedPackage, setSelectedPackage] = useState<TravelPackage | null>(null);
  const [bookingItem, setBookingItem] = useState<{
    item: any;
    itemType: 'PACKAGE' | 'HOTEL' | 'TRANSPORT' | 'ACTIVITY' | 'BIKE';
  } | null>(null);
  const [paymentBookingData, setPaymentBookingData] = useState<Partial<Booking> | null>(null);
  const [pendingGuestBooking, setPendingGuestBooking] = useState<Partial<Booking> | null>(null);
  const [showQuickPlan, setShowQuickPlan] = useState(false);
  const [showWallet, setShowWallet] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [loginNotice, setLoginNotice] = useState<string | undefined>();
  const [showGuestPrompt, setShowGuestPrompt] = useState(false);
  const [guestPromptTitle, setGuestPromptTitle] = useState('Login to save this package');
  const [destinationFilter, setDestinationFilter] = useState<string | undefined>();
  const [searchParams, setSearchParams] = useState<UnifiedSearchParams>({
    category: 'hotel',
    destination: 'Digha, Mandarmani'
  });

  // Restore search or page state from URL query parameters (Section 19 & Active Tab Logic)
  useEffect(() => {
    const parseUrlParams = () => {
      const pathname = window.location.pathname;
      if (pathname === '/hotels') {
        setCurrentView('hotels');
        return;
      }
      if (pathname === '/trips') {
        setCurrentView('trips');
        return;
      }
      if (pathname === '/support') {
        setCurrentView('support');
        return;
      }
      if (pathname === '/account' || pathname === '/customer') {
        if (currentUser) {
          setCurrentView('customer');
        } else {
          setShowLogin(true);
        }
        return;
      }

      const search = window.location.search;
      if (!search) return;
      const params = new URLSearchParams(search);
      const type = params.get('type') as ServiceCategory | null;
      const dest = params.get('destination') || params.get('location') || params.get('to') || undefined;
      const q = params.get('q') || undefined;

      if (type || dest || q) {
        const cat = type || (q ? detectCategoryFromQuery(q) : null) || 'hotel';
        setSearchParams({
          category: cat,
          destination: dest || 'Digha',
          query: q
        });
        setCurrentView('search');
      }
    };

    parseUrlParams();
    window.addEventListener('popstate', parseUrlParams);
    return () => window.removeEventListener('popstate', parseUrlParams);
  }, [currentUser]);

  // Synchronize on storage updates
  useEffect(() => {
    const handleStorageUpdate = () => {
      setCurrentUser(StorageService.getCurrentUser());
      setPackages(StorageService.getPackages());
      setHotels(StorageService.getHotels());
      setTransports(StorageService.getTransports());
      setActivities(StorageService.getActivities());
      setBikes(StorageService.getBikes());
      setDestinations(StorageService.getDestinations());
    };

    window.addEventListener('godigha_storage_updated', handleStorageUpdate);
    return () => window.removeEventListener('godigha_storage_updated', handleStorageUpdate);
  }, []);

  // Navigation handler with route awareness and URL sync
  const handleNavigate = (view: string) => {
    if (view === 'customer' && !currentUser) {
      setLoginNotice('Please login to access your customer dashboard and bookings.');
      setShowLogin(true);
      return;
    }

    if (view === 'account') {
      if (!currentUser) {
        setLoginNotice('Please login to access your account.');
        setShowLogin(true);
        return;
      }
      setCustomerActiveTab('dashboard');
      setCurrentView('customer');
      try {
        window.history.pushState({}, '', '/account');
      } catch {}
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    if (view === 'trips') {
      setCurrentView('trips');
      try {
        window.history.pushState({}, '', '/trips');
      } catch {}
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    if (view === 'support') {
      setCurrentView('support');
      try {
        window.history.pushState({}, '', '/support');
      } catch {}
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    if (view === 'hotels') {
      setCurrentView('hotels');
      try {
        window.history.pushState({}, '', '/hotels');
      } catch {}
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    if (view === 'home') {
      setCurrentView('home');
      try {
        window.history.pushState({}, '', '/');
      } catch {}
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenAccountTab = (tab: string) => {
    if (!currentUser) {
      setLoginNotice('Please login to view your account details.');
      setShowLogin(true);
      return;
    }
    setCustomerActiveTab(tab);
    setCurrentView('customer');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogout = () => {
    StorageService.logout();
    setCurrentUser(null);
    setCurrentView('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Service grid click router
  const handleServiceSelect = (serviceKey: string) => {
    if (serviceKey === 'hotels') setCurrentView('hotels');
    else if (serviceKey === 'transports') setCurrentView('transports');
    else if (serviceKey === 'sightseeing' || serviceKey === 'activities' || serviceKey === 'bikes') setCurrentView('experiences');
    else if (serviceKey === 'corporate' || serviceKey === 'parties' || serviceKey === 'conferences' || serviceKey === 'banquets' || serviceKey === 'dj' || serviceKey === 'beverages' || serviceKey === 'fooding' || serviceKey === 'catering') setCurrentView('corporate');
    else setCurrentView('packages');

    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Search trigger from Hero (Section 7, 8, 19, 20)
  const handleHeroSearch = (params: UnifiedSearchParams) => {
    setSearchParams(params);
    setDestinationFilter(params.destination);
    setCurrentView('search');

    // Update URL query parameters for sharing, browser back/forward and refresh (Section 19)
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('type', params.category);
      if (params.destination) url.searchParams.set('destination', params.destination);
      if (params.query) url.searchParams.set('q', params.query);
      if (params.cabParams?.from && params.cabParams?.to) {
        url.searchParams.set('from', params.cabParams.from);
        url.searchParams.set('to', params.cabParams.to);
      }
      window.history.pushState({}, '', url.toString());
    } catch (e) {
      console.error('Error updating URL:', e);
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToSearch = () => {
    setCurrentView('home');
    try {
      const url = new URL(window.location.href);
      url.search = '';
      window.history.pushState({}, '', url.pathname);
    } catch {}
    setTimeout(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 50);
  };

  // Booking Initiation handlers
  const handleBookPackage = (pkg: TravelPackage) => {
    setSelectedPackage(null);
    setBookingItem({ item: pkg, itemType: 'PACKAGE' });
  };

  const handleBookHotelRoom = (hotel: Hotel, room: HotelRoom) => {
    setBookingItem({ item: { hotel, room }, itemType: 'HOTEL' });
  };

  const handleBookTransport = (transport: TransportService) => {
    setBookingItem({ item: transport, itemType: 'TRANSPORT' });
  };

  const handleBookActivity = (activity: WaterActivity) => {
    setBookingItem({ item: activity, itemType: 'ACTIVITY' });
  };

  const handleBookBike = (bike: BikeRental) => {
    setBookingItem({ item: bike, itemType: 'BIKE' });
  };

  const handleBookSightseeing = (tour: SightseeingTour) => {
    setBookingItem({ item: tour, itemType: 'TRANSPORT' });
  };

  // Handle guest requirement before payment (Section 26)
  const handleRequireAuthForBooking = (partialBooking: Partial<Booking>) => {
    setPendingGuestBooking(partialBooking);
    setBookingItem(null);
    setLoginNotice('Please sign in or create an account to proceed with your booking payment.');
    setShowLogin(true);
  };

  // Handle Login Success (Section 26 resumption & Section 13 recent search merge)
  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    setShowLogin(false);
    setLoginNotice(undefined);
    StorageService.mergeGuestRecentSearches(user.id);

    // If there was a pending booking, resume checkout immediately!
    if (pendingGuestBooking) {
      const readyBooking: Partial<Booking> = {
        ...pendingGuestBooking,
        customerId: user.id,
        customerName: pendingGuestBooking.customerName || user.name,
        customerEmail: pendingGuestBooking.customerEmail || user.email,
        customerPhone: pendingGuestBooking.customerPhone || user.phone
      };
      setPendingGuestBooking(null);
      setPaymentBookingData(readyBooking);
    } else {
      if (user.role === 'ADMIN') setCurrentView('admin');
      else if (user.role === 'VENDOR') setCurrentView('vendor');
      else {
        setCurrentView('customer');
        setCustomerActiveTab('dashboard');
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f8fafc] text-slate-800 antialiased">
      
      {/* 1. Header with dynamic login state & account dropdown */}
      <Header
        currentUser={currentUser}
        onNavigate={handleNavigate}
        currentView={currentView}
        onOpenLogin={() => {
          setLoginNotice(undefined);
          setShowLogin(true);
        }}
        onOpenWallet={() => {
          if (!currentUser) {
            setLoginNotice('Please login to check your GoCash balance.');
            setShowLogin(true);
          } else {
            setShowWallet(true);
          }
        }}
        onOpenAccountTab={handleOpenAccountTab}
        onOpenQuickPlan={() => setShowQuickPlan(true)}
        onLogout={handleLogout}
      />

      {/* 2. Orange WhatsApp Contact Ribbon */}
      <WhatsAppRibbon />

      {/* Main Content Area */}
      <main className="flex-1 pb-16 lg:pb-0">
        {currentView === 'home' && (
          <>
            {/* Travel Planning Hero with Search Engine */}
            <HeroSearch
              onSearch={handleHeroSearch}
              onExploreClick={() => handleNavigate('packages')}
              onQuickPlanClick={() => setShowQuickPlan(true)}
              initialParams={searchParams}
              currentUser={currentUser}
            />

            {/* "OUR SERVICES" Section */}
            <OurServicesGrid onSelectService={handleServiceSelect} />

            {/* "EXPLORE TOP TOURS" */}
            <ExploreTopTours
              packages={packages}
              onSelectPackage={(pkg) => setSelectedPackage(pkg)}
              onViewAllPackages={() => handleNavigate('packages')}
            />

            {/* Hotels & Stays Accommodation Module */}
            <HotelsSection
              hotels={hotels}
              onBookHotelRoom={handleBookHotelRoom}
            />

            {/* Transportation, Pickup & Drop Cabs */}
            <TransportationSection
              transports={transports}
              onBookTransport={handleBookTransport}
            />

            {/* Watersports, Rental Bikes & Guided Sightseeing */}
            <ExperiencesSection
              activities={activities}
              bikes={bikes}
              sightseeing={sightseeing}
              onBookActivity={handleBookActivity}
              onBookBike={handleBookBike}
              onBookSightseeing={handleBookSightseeing}
            />

            {/* Group Tours, Corporate Offsites & Event Services */}
            <CorporateEventsSection
              events={events}
              onEnquirySubmitted={() => {}}
            />

            {/* Genuine 5.0 Google Rating & Customer Testimonials */}
            <ReviewsSection reviews={reviews} />
          </>
        )}

        {currentView === 'search' && (
          <SearchResultsView
            searchParams={searchParams}
            hotels={hotels}
            transports={transports}
            packages={packages}
            activities={activities}
            bikes={bikes}
            sightseeing={sightseeing}
            onBackToSearch={handleBackToSearch}
            onBookHotelRoom={handleBookHotelRoom}
            onBookTransport={handleBookTransport}
            onSelectPackage={(pkg) => setSelectedPackage(pkg)}
            onBookPackage={handleBookPackage}
            onBookActivity={handleBookActivity}
            onBookBike={handleBookBike}
            onBookSightseeing={handleBookSightseeing}
            onCategoryChange={(newCategory) => {
              setSearchParams(prev => ({ ...prev, category: newCategory }));
              try {
                const url = new URL(window.location.href);
                url.searchParams.set('type', newCategory);
                window.history.pushState({}, '', url.toString());
              } catch {}
            }}
            onPopularSearchClick={(term) => {
              const detected = detectCategoryFromQuery(term) || 'hotel';
              const cleanDest = term.replace(' Hotels', '').replace(' Resort', '');
              const newParams: UnifiedSearchParams = {
                category: detected,
                query: term,
                destination: cleanDest
              };
              setSearchParams(newParams);
              try {
                const url = new URL(window.location.href);
                url.searchParams.set('type', detected);
                url.searchParams.set('q', term);
                window.history.pushState({}, '', url.toString());
              } catch {}
            }}
          />
        )}

        {currentView === 'packages' && (
          <PackagesList
            packages={packages}
            onSelectPackage={(pkg) => setSelectedPackage(pkg)}
            initialDestinationFilter={destinationFilter}
          />
        )}

        {currentView === 'hotels' && (
          <HotelsSection
            hotels={hotels}
            onBookHotelRoom={handleBookHotelRoom}
          />
        )}

        {currentView === 'transports' && (
          <TransportationSection
            transports={transports}
            onBookTransport={handleBookTransport}
          />
        )}

        {currentView === 'experiences' && (
          <ExperiencesSection
            activities={activities}
            bikes={bikes}
            sightseeing={sightseeing}
            onBookActivity={handleBookActivity}
            onBookBike={handleBookBike}
            onBookSightseeing={handleBookSightseeing}
          />
        )}

        {currentView === 'corporate' && (
          <CorporateEventsSection
            events={events}
            onEnquirySubmitted={() => {}}
          />
        )}

        {currentView === 'customer' && currentUser && (
          <CustomerDashboard
            currentUser={currentUser}
            initialTab={customerActiveTab}
            onExplorePackages={() => handleNavigate('packages')}
            onViewPackage={(pkg) => setSelectedPackage(pkg)}
            onBookPackage={handleBookPackage}
            onLogout={handleLogout}
          />
        )}

        {currentView === 'vendor' && currentUser && (
          <VendorPortal currentUser={currentUser} />
        )}

        {currentView === 'admin' && (
          <AdminPortal />
        )}

        {currentView === 'offers' && (
          <OffersSection onExplorePackages={() => handleNavigate('packages')} />
        )}

        {currentView === 'destinations' && (
          <DestinationsSection
            destinations={destinations}
            onSelectDestination={(destName) => {
              setDestinationFilter(destName);
              handleNavigate('packages');
            }}
          />
        )}

        {currentView === 'trips' && (
          <TripsView
            currentUser={currentUser}
            bookings={StorageService.getBookings()}
            onBackToHome={() => handleNavigate('home')}
            onExplorePackages={() => handleNavigate('packages')}
            onOpenLogin={() => {
              setLoginNotice('Sign in to view your bookings and trips.');
              setShowLogin(true);
            }}
            onViewPackage={(pkg) => setSelectedPackage(pkg)}
          />
        )}

        {currentView === 'support' && (
          <SupportView
            onBackToHome={() => handleNavigate('home')}
            onExplorePackages={() => handleNavigate('packages')}
          />
        )}
      </main>

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* 3. Bottom App Bar Navigation (Exact Mobile Reference Design) */}
      <BottomNav
        currentView={currentView}
        currentUser={currentUser}
        onNavigate={handleNavigate}
        onOpenLogin={() => {
          setLoginNotice('Sign in to access your GoDigha account.');
          setShowLogin(true);
        }}
        customerActiveTab={customerActiveTab}
      />

      {/* Modals & Overlays */}
      {selectedPackage && (
        <PackageModal
          pkg={selectedPackage}
          onClose={() => setSelectedPackage(null)}
          onBookNow={handleBookPackage}
          onEnquireNow={() => {
            setSelectedPackage(null);
            setShowQuickPlan(true);
          }}
        />
      )}

      {bookingItem && (
        <BookingModal
          item={bookingItem.item}
          itemType={bookingItem.itemType}
          currentUser={currentUser}
          onClose={() => setBookingItem(null)}
          onProceedToPayment={(partialBooking) => {
            setBookingItem(null);
            setPaymentBookingData(partialBooking);
          }}
          onRequireAuth={handleRequireAuthForBooking}
        />
      )}

      {paymentBookingData && (
        <PaymentModal
          bookingData={paymentBookingData}
          onClose={() => {
            setPaymentBookingData(null);
          }}
          onBookingSuccess={() => {
            // Handled inside PaymentModal
          }}
          onViewBookingInAccount={(bookingId) => {
            setPaymentBookingData(null);
            setCustomerActiveTab('bookings');
            setCurrentView('customer');
          }}
        />
      )}

      {showQuickPlan && (
        <QuickPlanModal
          onClose={() => setShowQuickPlan(false)}
          onSuccess={() => {}}
        />
      )}

      {showWallet && currentUser && (
        <WalletModal
          currentUser={currentUser}
          onClose={() => setShowWallet(false)}
          onExplorePackages={() => {
            setShowWallet(false);
            handleNavigate('packages');
          }}
        />
      )}

      {showLogin && (
        <LoginModal
          onClose={() => {
            setShowLogin(false);
            setLoginNotice(undefined);
          }}
          customNotice={loginNotice}
          onLoginSuccess={handleLoginSuccess}
        />
      )}

      {showGuestPrompt && (
        <GuestPromptModal
          title={guestPromptTitle}
          onClose={() => setShowGuestPrompt(false)}
          onLogin={() => {
            setShowGuestPrompt(false);
            setLoginNotice('Login to save packages to your wishlist.');
            setShowLogin(true);
          }}
          onCreateAccount={() => {
            setShowGuestPrompt(false);
            setLoginNotice('Create your GoDigha account to save packages.');
            setShowLogin(true);
          }}
        />
      )}

    </div>
  );
}
