import React, { useState, useEffect, useRef } from 'react';
import {
  Menu,
  X,
  Compass,
  Briefcase,
  Phone,
  ShieldCheck,
  User as UserIcon,
  LogOut,
  ChevronDown,
  Sparkles,
  MapPin,
  CalendarCheck,
  LayoutDashboard,
  Heart,
  Bell,
  CreditCard,
  Settings,
  HelpCircle,
  Headphones,
  ArrowRight
} from 'lucide-react';
import { User, UserRole } from '../types';
import { StorageService } from '../services/storage';
import { BUSINESS_INFO } from '../data/mockData';
import { GoDighaHorizontalLogo } from './GoDighaHorizontalLogo';

interface HeaderProps {
  currentUser: User | null;
  onNavigate: (view: string) => void;
  currentView: string;
  onOpenLogin: () => void;
  onOpenWallet: () => void;
  onOpenAccountTab?: (tab: string) => void;
  onOpenQuickPlan?: () => void;
  onLogout?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onNavigate,
  currentView,
  onOpenLogin,
  onOpenWallet,
  onOpenAccountTab,
  onOpenQuickPlan,
  onLogout
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);
  const [supportMenuOpen, setSupportMenuOpen] = useState(false);
  const accountMenuRef = useRef<HTMLDivElement>(null);
  const supportMenuRef = useRef<HTMLDivElement>(null);

  // Close menus on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (accountMenuRef.current && !accountMenuRef.current.contains(event.target as Node)) {
        setAccountMenuOpen(false);
      }
      if (supportMenuRef.current && !supportMenuRef.current.contains(event.target as Node)) {
        setSupportMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Calculate unread notifications count
  const unreadCount = currentUser
    ? StorageService.getNotifications(currentUser.id).filter(n => !n.read).length
    : 0;

  const handleRoleSwitch = (role: UserRole) => {
    const allUsers = StorageService.getUsers();
    const targetUser = allUsers.find(u => u.role === role);
    if (targetUser) {
      StorageService.setCurrentUser(targetUser);
      setAccountMenuOpen(false);
      if (role === 'ADMIN') onNavigate('admin');
      else if (role === 'VENDOR') onNavigate('vendor');
      else onNavigate('customer');
    }
  };

  const handleAccountNavClick = (tab: string) => {
    setAccountMenuOpen(false);
    if (onOpenAccountTab) {
      onOpenAccountTab(tab);
    } else {
      onNavigate('customer');
    }
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#061527]/95 backdrop-blur-md text-white shadow-lg border-b border-white/10 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 md:h-18 lg:h-20 gap-3 sm:gap-4">
            
            {/* Left: Mobile Menu Toggle & Official GoDigha Brand Identity */}
            <div className="flex items-center space-x-2 sm:space-x-3 shrink-0">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors focus:outline-none xl:hidden"
                aria-label="Toggle Navigation Menu"
              >
                {mobileMenuOpen ? <X className="w-5 h-5 sm:w-6 sm:h-6" /> : <Menu className="w-5 h-5 sm:w-6 sm:h-6" />}
              </button>

              <button
                onClick={() => onNavigate('home')}
                className="group flex flex-col text-left focus:outline-none transition-transform active:scale-95 py-0.5"
                aria-label="GoDigha Home"
              >
                <div className="flex items-center">
                  <GoDighaHorizontalLogo className="h-7 sm:h-8 md:h-9 w-auto group-hover:scale-[1.02] transition-transform duration-200" />
                </div>
                <span className="text-[9px] md:text-[10px] font-bold text-slate-300/80 tracking-wider uppercase mt-0.5 hidden xs:inline">
                  Old Digha • Tours & Stays
                </span>
              </button>
            </div>

            {/* Center: Main Navigation Links */}
            <nav className="hidden xl:flex items-center space-x-0.5 lg:space-x-1 text-xs lg:text-[12.5px] font-semibold text-slate-200">
              <button
                onClick={() => onNavigate('home')}
                className={`px-2 lg:px-2.5 py-1.5 rounded-full transition-all ${
                  currentView === 'home'
                    ? 'bg-white/15 text-amber-300 font-bold shadow-xs'
                    : 'hover:text-white hover:bg-white/10 text-slate-200'
                }`}
              >
                Home
              </button>
              <button
                onClick={() => onNavigate('packages')}
                className={`px-2 lg:px-2.5 py-1.5 rounded-full transition-all flex items-center space-x-1 ${
                  currentView === 'packages'
                    ? 'bg-white/15 text-amber-300 font-bold shadow-xs'
                    : 'hover:text-white hover:bg-white/10 text-slate-200'
                }`}
              >
                <span>Packages</span>
                <span className="px-1 py-0.5 rounded-full text-[8.5px] font-black bg-gradient-to-r from-orange-500 to-amber-500 text-white leading-none shadow-xs">
                  HOT
                </span>
              </button>
              <button
                onClick={() => onNavigate('hotels')}
                className={`px-2 lg:px-2.5 py-1.5 rounded-full transition-all ${
                  currentView === 'hotels'
                    ? 'bg-white/15 text-amber-300 font-bold shadow-xs'
                    : 'hover:text-white hover:bg-white/10 text-slate-200'
                }`}
              >
                Hotels & Stays
              </button>
              <button
                onClick={() => onNavigate('transports')}
                className={`px-2 lg:px-2.5 py-1.5 rounded-full transition-all ${
                  currentView === 'transports'
                    ? 'bg-white/15 text-amber-300 font-bold shadow-xs'
                    : 'hover:text-white hover:bg-white/10 text-slate-200'
                }`}
              >
                Transport
              </button>
              <button
                onClick={() => onNavigate('experiences')}
                className={`px-2 lg:px-2.5 py-1.5 rounded-full transition-all ${
                  currentView === 'experiences'
                    ? 'bg-white/15 text-amber-300 font-bold shadow-xs'
                    : 'hover:text-white hover:bg-white/10 text-slate-200'
                }`}
              >
                Activities & Bikes
              </button>
              <button
                onClick={() => onNavigate('corporate')}
                className={`px-2 lg:px-2.5 py-1.5 rounded-full transition-all ${
                  currentView === 'corporate'
                    ? 'bg-white/15 text-amber-300 font-bold shadow-xs'
                    : 'hover:text-white hover:bg-white/10 text-slate-200'
                }`}
              >
                Corporate & Events
              </button>
            </nav>

            {/* Right: Support + Go Cash + Plan My Trip + Login / Account Dropdown */}
            <div className="flex items-center space-x-1.5 sm:space-x-2.5 shrink-0">
              
              {/* 24x7 Support Dropdown */}
              <div className="relative hidden sm:block" ref={supportMenuRef}>
                <button
                  onClick={() => setSupportMenuOpen(!supportMenuOpen)}
                  className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-full text-xs font-medium text-slate-300 hover:text-white hover:bg-white/10 transition-colors border border-transparent hover:border-white/10"
                >
                  <Headphones className="w-3.5 h-3.5 text-sky-400" />
                  <span>Support</span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {supportMenuOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white text-slate-800 rounded-2xl shadow-2xl py-2 z-50 border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-3.5 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100">
                      GoDigha Helpdesk
                    </div>
                    <a
                      href={`tel:${BUSINESS_INFO.phone}`}
                      className="px-3.5 py-2 text-xs flex items-center space-x-2.5 hover:bg-slate-50 text-slate-700"
                    >
                      <Phone className="w-3.5 h-3.5 text-emerald-600" />
                      <div>
                        <div className="font-bold text-slate-900">{BUSINESS_INFO.phoneFormatted}</div>
                        <div className="text-[10px] text-slate-500">24x7 Call Support</div>
                      </div>
                    </a>
                    <a
                      href={BUSINESS_INFO.whatsappDirectLink}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3.5 py-2 text-xs flex items-center space-x-2.5 hover:bg-slate-50 text-slate-700"
                    >
                      <svg className="w-4 h-4 text-emerald-600 fill-current" viewBox="0 0 24 24">
                        <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.77-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86.173.086.275.072.376-.044.101-.116.433-.506.549-.68.116-.173.231-.145.39-.086s1.011.477 1.184.564.289.13.332.203c.044.072.044.419-.1.824z" />
                      </svg>
                      <div>
                        <div className="font-bold text-slate-900">WhatsApp Assistant</div>
                        <div className="text-[10px] text-slate-500">Quick Quotes & Booking</div>
                      </div>
                    </a>
                  </div>
                )}
              </div>

              {/* Go Cash Button */}
              {currentUser && (
                <button
                  onClick={onOpenWallet}
                  className="flex items-center space-x-1 px-2 py-0.5 md:px-2.5 md:py-1 rounded-full bg-[#18395e] hover:bg-[#204977] text-[11px] md:text-xs font-medium text-amber-300 border border-amber-400/30 transition-all shadow-sm"
                  title="Go Cash Wallet Balance"
                >
                  <Sparkles className="w-3 h-3 text-amber-400 animate-pulse" />
                  <span className="hidden sm:inline">Go Cash:</span>
                  <span className="font-bold text-white">₹{currentUser.goCashBalance}</span>
                </button>
              )}

              {/* Plan My Trip Button */}
              {onOpenQuickPlan && (
                <button
                  onClick={onOpenQuickPlan}
                  className="hidden md:flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-xs font-semibold text-slate-200 hover:text-white transition-colors border border-white/15"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>Plan My Trip</span>
                </button>
              )}

              {/* AUTHENTICATION STATE */}
              {currentUser === null ? (
                /* WHEN LOGGED OUT: [ Login / Sign up → ] Button matching reference image top right */
                <button
                  onClick={onOpenLogin}
                  className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-xs shadow-md shadow-orange-500/25 transition-all active:scale-95 cursor-pointer"
                >
                  <UserIcon className="w-3.5 h-3.5 text-white" />
                  <span>Login / Sign up</span>
                  <ArrowRight className="w-3 h-3 text-white hidden sm:inline" />
                </button>
              ) : (
                /* WHEN LOGGED IN: [ Avatar + User Name ▾ ] with unread notification badge */
                <div className="relative" ref={accountMenuRef}>
                  <button
                    onClick={() => setAccountMenuOpen(!accountMenuOpen)}
                    className="flex items-center space-x-2 px-2.5 py-1 rounded-full bg-[#18395e] hover:bg-[#204977] border border-slate-700/60 transition-all text-xs font-medium text-white focus:outline-none"
                    aria-label="User Account Menu"
                  >
                    <div className="relative w-6 h-6 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 text-slate-950 font-bold text-[11px] flex items-center justify-center shrink-0 overflow-hidden">
                      {currentUser.avatar ? (
                        <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
                      ) : (
                        currentUser.name.charAt(0).toUpperCase()
                      )}
                      {unreadCount > 0 && (
                        <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-red-500 ring-2 ring-[#18395e]" />
                      )}
                    </div>
                    
                    <span className="max-w-[85px] sm:max-w-[110px] truncate font-bold">
                      {currentUser.firstName || currentUser.name.split(' ')[0]}
                    </span>
                    
                    <ChevronDown className="w-3 h-3 text-slate-300" />
                  </button>

                  {/* Complete Customer Account Dropdown Menu (Section 24) */}
                  {accountMenuOpen && (
                    <div className="absolute right-0 mt-2 w-64 bg-white text-slate-800 rounded-3xl shadow-2xl py-2 z-50 border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
                      
                      {/* User Info Header */}
                      <div className="px-4 py-3 border-b border-slate-100 flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 text-slate-950 font-black text-sm flex items-center justify-center shrink-0 overflow-hidden shadow-xs">
                          {currentUser.avatar ? (
                            <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
                          ) : (
                            currentUser.name.charAt(0).toUpperCase()
                          )}
                        </div>
                        <div className="min-w-0">
                          <div className="font-black text-slate-900 text-xs sm:text-sm truncate">
                            {currentUser.name}
                          </div>
                          <div className="text-[11px] text-slate-500 truncate">
                            {currentUser.email}
                          </div>
                          <span className="inline-block mt-0.5 px-2 py-0.2 rounded text-[9px] font-bold bg-amber-100 text-amber-900">
                            {currentUser.role}
                          </span>
                        </div>
                      </div>

                      {/* Menu Links with Icons & Badges */}
                      <div className="py-1 text-xs font-semibold text-slate-700">
                        
                        <button
                          onClick={() => handleAccountNavClick('dashboard')}
                          className="w-full px-4 py-2 flex items-center space-x-2.5 hover:bg-slate-50 text-left transition-colors"
                        >
                          <LayoutDashboard className="w-4 h-4 text-slate-500" />
                          <span>My Account</span>
                        </button>

                        <button
                          onClick={() => handleAccountNavClick('trips')}
                          className="w-full px-4 py-2 flex items-center space-x-2.5 hover:bg-slate-50 text-left transition-colors"
                        >
                          <Compass className="w-4 h-4 text-slate-500" />
                          <span>My Trips</span>
                        </button>

                        <button
                          onClick={() => handleAccountNavClick('bookings')}
                          className="w-full px-4 py-2 flex items-center space-x-2.5 hover:bg-slate-50 text-left transition-colors"
                        >
                          <Briefcase className="w-4 h-4 text-slate-500" />
                          <span>My Bookings</span>
                        </button>

                        <button
                          onClick={() => handleAccountNavClick('enquiries')}
                          className="w-full px-4 py-2 flex items-center space-x-2.5 hover:bg-slate-50 text-left transition-colors"
                        >
                          <HelpCircle className="w-4 h-4 text-slate-500" />
                          <span>My Enquiries</span>
                        </button>

                        <button
                          onClick={() => handleAccountNavClick('saved')}
                          className="w-full px-4 py-2 flex items-center space-x-2.5 hover:bg-slate-50 text-left transition-colors"
                        >
                          <Heart className="w-4 h-4 text-slate-500" />
                          <span>Saved Packages</span>
                        </button>

                        <button
                          onClick={() => handleAccountNavClick('notifications')}
                          className="w-full px-4 py-2 flex items-center justify-between hover:bg-slate-50 text-left transition-colors"
                        >
                          <div className="flex items-center space-x-2.5">
                            <Bell className="w-4 h-4 text-slate-500" />
                            <span>Notifications</span>
                          </div>
                          {unreadCount > 0 && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-orange-600 text-white">
                              {unreadCount}
                            </span>
                          )}
                        </button>

                        <button
                          onClick={() => handleAccountNavClick('payments')}
                          className="w-full px-4 py-2 flex items-center space-x-2.5 hover:bg-slate-50 text-left transition-colors"
                        >
                          <CreditCard className="w-4 h-4 text-slate-500" />
                          <span>Payments & Invoices</span>
                        </button>

                      </div>

                      {/* Divider */}
                      <div className="border-t border-slate-100 my-1" />

                      {/* Settings & Role Testing */}
                      <div className="py-1 text-xs font-semibold text-slate-700">
                        <button
                          onClick={() => handleAccountNavClick('settings')}
                          className="w-full px-4 py-2 flex items-center space-x-2.5 hover:bg-slate-50 text-left transition-colors"
                        >
                          <Settings className="w-4 h-4 text-slate-500" />
                          <span>Settings</span>
                        </button>

                        {/* Role Switcher Submenu */}
                        <div className="px-4 py-1.5 flex items-center justify-between text-[11px] text-slate-400">
                          <span>Role View:</span>
                          <div className="flex space-x-1">
                            <button
                              onClick={() => handleRoleSwitch('CUSTOMER')}
                              className={`px-1.5 py-0.5 rounded ${currentUser.role === 'CUSTOMER' ? 'bg-blue-100 text-blue-700 font-bold' : 'text-slate-500'}`}
                            >
                              Cust
                            </button>
                            <button
                              onClick={() => handleRoleSwitch('VENDOR')}
                              className={`px-1.5 py-0.5 rounded ${currentUser.role === 'VENDOR' ? 'bg-emerald-100 text-emerald-700 font-bold' : 'text-slate-500'}`}
                            >
                              Vend
                            </button>
                            <button
                              onClick={() => handleRoleSwitch('ADMIN')}
                              className={`px-1.5 py-0.5 rounded ${currentUser.role === 'ADMIN' ? 'bg-indigo-100 text-indigo-700 font-bold' : 'text-slate-500'}`}
                            >
                              Admin
                            </button>
                          </div>
                        </div>

                        {/* Logout */}
                        <button
                          onClick={() => {
                            setAccountMenuOpen(false);
                            if (onLogout) onLogout();
                            else StorageService.logout();
                          }}
                          className="w-full px-4 py-2 flex items-center space-x-2.5 hover:bg-red-50 text-red-600 text-left transition-colors font-bold"
                        >
                          <LogOut className="w-4 h-4" />
                          <span>Logout</span>
                        </button>
                      </div>

                    </div>
                  )}
                </div>
              )}

            </div>

          </div>
        </div>
      </header>

      {/* Mobile Slide-down Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-[#0a1e35] text-white border-b border-[#1b3d63] px-4 pt-3 pb-6 space-y-3 z-30 shadow-2xl animate-in slide-in-from-top duration-200">
          <div className="grid grid-cols-2 gap-2 text-sm">
            <button
              onClick={() => { onNavigate('home'); setMobileMenuOpen(false); }}
              className={`p-2.5 rounded-lg text-left font-medium ${currentView === 'home' ? 'bg-amber-500 text-white' : 'bg-[#142e4e] text-slate-200'}`}
            >
              Home
            </button>
            <button
              onClick={() => { onNavigate('packages'); setMobileMenuOpen(false); }}
              className={`p-2.5 rounded-lg text-left font-medium ${currentView === 'packages' ? 'bg-amber-500 text-white' : 'bg-[#142e4e] text-slate-200'}`}
            >
              Holiday Packages
            </button>
            <button
              onClick={() => { onNavigate('hotels'); setMobileMenuOpen(false); }}
              className={`p-2.5 rounded-lg text-left font-medium ${currentView === 'hotels' ? 'bg-amber-500 text-white' : 'bg-[#142e4e] text-slate-200'}`}
            >
              Hotels & Resorts
            </button>
            <button
              onClick={() => { onNavigate('transports'); setMobileMenuOpen(false); }}
              className={`p-2.5 rounded-lg text-left font-medium ${currentView === 'transports' ? 'bg-amber-500 text-white' : 'bg-[#142e4e] text-slate-200'}`}
            >
              Pickup & Drop Cabs
            </button>
            <button
              onClick={() => { onNavigate('experiences'); setMobileMenuOpen(false); }}
              className={`p-2.5 rounded-lg text-left font-medium ${currentView === 'experiences' ? 'bg-amber-500 text-white' : 'bg-[#142e4e] text-slate-200'}`}
            >
              Water Sports & Bikes
            </button>
            <button
              onClick={() => { onNavigate('corporate'); setMobileMenuOpen(false); }}
              className={`p-2.5 rounded-lg text-left font-medium ${currentView === 'corporate' ? 'bg-amber-500 text-white' : 'bg-[#142e4e] text-slate-200'}`}
            >
              Corporate & Events
            </button>
          </div>

          {currentUser ? (
            <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between text-xs">
              <button
                onClick={() => {
                  onNavigate('customer');
                  setMobileMenuOpen(false);
                }}
                className="font-bold text-amber-300"
              >
                Go to My Account ({currentUser.name})
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  if (onLogout) onLogout();
                  else StorageService.logout();
                }}
                className="text-red-400 font-semibold"
              >
                Logout
              </button>
            </div>
          ) : (
            <div className="pt-2 border-t border-slate-700/60">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenLogin();
                }}
                className="w-full py-2.5 rounded-xl bg-orange-600 text-white font-bold text-xs text-center"
              >
                Login / Sign up
              </button>
            </div>
          )}

          <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center space-x-1">
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              <span>Old Digha, West Bengal</span>
            </div>
            <a
              href={`tel:${BUSINESS_INFO.phone}`}
              className="flex items-center space-x-1 text-amber-300 font-medium"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>{BUSINESS_INFO.phoneFormatted}</span>
            </a>
          </div>
        </div>
      )}
    </>
  );
};
