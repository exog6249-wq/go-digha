import React, { useState } from 'react';
import {
  ArrowLeft,
  Calendar,
  Users,
  Compass,
  Printer,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  MapPin,
  LogIn
} from 'lucide-react';
import { Booking, User, TravelPackage } from '../types';
import { InvoiceModal } from './InvoiceModal';

interface TripsViewProps {
  currentUser: User | null;
  bookings: Booking[];
  onBackToHome: () => void;
  onExplorePackages: () => void;
  onOpenLogin: () => void;
  onViewPackage?: (pkg: TravelPackage) => void;
}

export const TripsView: React.FC<TripsViewProps> = ({
  currentUser,
  bookings,
  onBackToHome,
  onExplorePackages,
  onOpenLogin
}) => {
  const [activeFilter, setActiveFilter] = useState<'UPCOMING' | 'COMPLETED' | 'CANCELLED'>('UPCOMING');
  const [selectedInvoice, setSelectedInvoice] = useState<Booking | null>(null);

  // Filter bookings for this customer
  const userBookings = currentUser
    ? bookings.filter((b) => b.customerId === currentUser.id)
    : [];

  const upcomingTrips = userBookings.filter(
    (b) => b.bookingStatus === 'CONFIRMED' || b.bookingStatus === 'PROCESSING'
  );
  const completedTrips = userBookings.filter((b) => b.bookingStatus === 'COMPLETED');
  const cancelledTrips = userBookings.filter((b) => b.bookingStatus === 'CANCELLED');

  const currentList =
    activeFilter === 'UPCOMING'
      ? upcomingTrips
      : activeFilter === 'COMPLETED'
      ? completedTrips
      : cancelledTrips;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-24 md:pb-16">
      
      {/* Top Header Bar */}
      <div className="bg-white border-b border-slate-200 sticky top-16 md:top-18 lg:top-20 z-30 shadow-xs">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between">
          <button
            onClick={onBackToHome}
            className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm transition-colors active:scale-95"
          >
            <ArrowLeft className="w-4 h-4 text-slate-600" />
            <span>Back to Home</span>
          </button>
          
          <div className="text-right">
            <h1 className="text-sm sm:text-base font-black text-slate-900 font-heading">
              My Trips
            </h1>
            <span className="text-[10px] text-slate-500 font-medium">
              {currentUser ? `${userBookings.length} total bookings` : 'Guest Mode'}
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8 space-y-6">
        
        {/* If Not Logged In State (Section 3) */}
        {!currentUser ? (
          <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 text-center shadow-xs space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-orange-50 text-orange-600 flex items-center justify-center">
              <Compass className="w-8 h-8" />
            </div>
            <div className="max-w-md mx-auto space-y-1">
              <h2 className="text-xl font-black text-slate-900 font-heading">
                Sign in to view your trips
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                Log in to access your hotel vouchers, itinerary details, cab driver contact information, and download official invoices.
              </p>
            </div>
            <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={onOpenLogin}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-xs sm:text-sm shadow-md shadow-orange-500/25 active:scale-95 transition-all flex items-center space-x-2"
              >
                <LogIn className="w-4 h-4" />
                <span>Login to GoDigha</span>
              </button>
              <button
                onClick={onExplorePackages}
                className="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm transition-colors"
              >
                Explore Packages
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Filter Tabs for Trips */}
            <div className="flex items-center space-x-2 bg-white p-1.5 rounded-2xl border border-slate-200 shadow-xs max-w-sm">
              {[
                { id: 'UPCOMING' as const, label: `Upcoming (${upcomingTrips.length})` },
                { id: 'COMPLETED' as const, label: `Past (${completedTrips.length})` },
                { id: 'CANCELLED' as const, label: `Cancelled (${cancelledTrips.length})` }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveFilter(tab.id)}
                  className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    activeFilter === tab.id
                      ? 'bg-[#FF6E00] text-white shadow-xs'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* List of trips */}
            {currentList.length === 0 ? (
              <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 text-center shadow-xs space-y-3">
                <Compass className="w-12 h-12 text-slate-300 mx-auto" />
                <h3 className="text-lg font-black text-slate-900 font-heading">
                  No {activeFilter.toLowerCase()} trips yet
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Your upcoming journeys to Digha and Mandarmani will appear here once booked.
                </p>
                <div className="pt-2">
                  <button
                    onClick={onExplorePackages}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-xs shadow-md transition-all active:scale-95"
                  >
                    Explore Packages
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {currentList.map((trip) => (
                  <div
                    key={trip.id}
                    className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs hover:border-orange-300 transition-all space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                      <div>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            trip.bookingStatus === 'CONFIRMED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : trip.bookingStatus === 'CANCELLED'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {trip.bookingStatus}
                        </span>
                        <h2 className="text-base sm:text-lg font-black text-slate-900 mt-1 font-heading">
                          {trip.itemTitle}
                        </h2>
                        <div className="text-xs text-slate-500 flex flex-wrap items-center gap-x-3 gap-y-1 mt-0.5">
                          <span className="flex items-center space-x-1">
                            <Calendar className="w-3.5 h-3.5 text-orange-500" />
                            <span>Travel: <strong>{trip.travelDate}</strong></span>
                          </span>
                          <span>•</span>
                          <span className="flex items-center space-x-1">
                            <Users className="w-3.5 h-3.5 text-blue-500" />
                            <span>{trip.travellers} Guests</span>
                          </span>
                          <span>•</span>
                          <span>Booking ID: <strong className="text-slate-700">{trip.id}</strong></span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Total Amount</span>
                        <span className="text-lg font-black text-slate-900">₹{trip.totalAmount}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                      <div className="text-xs text-emerald-700 font-semibold flex items-center space-x-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Instant Confirmation & GoDigha Vouchers Ready</span>
                      </div>

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setSelectedInvoice(trip)}
                          className="px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs border border-slate-200 flex items-center space-x-1.5 transition-colors"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>Download Invoice</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

      </div>

      {/* Invoice Modal */}
      {selectedInvoice && (
        <InvoiceModal
          booking={selectedInvoice}
          onClose={() => setSelectedInvoice(null)}
        />
      )}

    </div>
  );
};
