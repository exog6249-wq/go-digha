import React, { useState } from 'react';
import { TravelPackage } from '../types';
import {
  Calendar,
  Clock,
  MapPin,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  Heart,
  Share2,
  Car,
  Utensils,
  Hotel as HotelIcon,
  Sparkles,
  ArrowRight,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { StorageService } from '../services/storage';

interface PackageModalProps {
  pkg: TravelPackage;
  onClose: () => void;
  onBookNow: (pkg: TravelPackage) => void;
  onEnquireNow: (pkg: TravelPackage) => void;
}

export const PackageModal: React.FC<PackageModalProps> = ({
  pkg,
  onClose,
  onBookNow,
  onEnquireNow
}) => {
  const [activeDay, setActiveDay] = useState<number>(1);
  const [isSaved, setIsSaved] = useState<boolean>(
    StorageService.getSavedPackageIds().includes(pkg.id)
  );
  const [selectedImage, setSelectedImage] = useState<string>(pkg.coverImage);

  const toggleSave = () => {
    const updated = StorageService.toggleSavedPackage(pkg.id);
    setIsSaved(updated);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
        
        {/* Top Control Bar with Close and Save */}
        <div className="sticky top-0 z-20 bg-white/95 backdrop-blur-md px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-900 text-xs font-bold uppercase tracking-wider">
              {pkg.category.replace('_', ' ')}
            </span>
            {pkg.badge && (
              <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-xs font-bold">
                {pkg.badge}
              </span>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={toggleSave}
              className={`p-2 rounded-full border transition-colors ${
                isSaved ? 'bg-red-50 border-red-200 text-red-600' : 'bg-slate-50 border-slate-200 text-slate-600 hover:text-red-600'
              }`}
              title={isSaved ? 'Saved to Wishlist' : 'Save to Wishlist'}
            >
              <Heart className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900 flex items-center justify-center font-bold text-sm"
              aria-label="Close"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6">
          
          {/* Header Title & Specs */}
          <div>
            <div className="text-xs font-semibold text-blue-900 flex items-center space-x-1.5">
              <MapPin className="w-3.5 h-3.5 text-amber-500" />
              <span>{pkg.destination}</span>
              <span>·</span>
              <Clock className="w-3.5 h-3.5 text-blue-600" />
              <span>{pkg.duration}</span>
              <span>·</span>
              <span>{pkg.groupSize}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1 font-heading">
              {pkg.name}
            </h2>

            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              {pkg.overview}
            </p>
          </div>

          {/* Gallery View */}
          <div className="space-y-2">
            <div className="aspect-16/9 rounded-2xl overflow-hidden bg-slate-100 shadow-inner">
              <img
                src={selectedImage}
                alt={pkg.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            {pkg.gallery.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {pkg.gallery.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(img)}
                    className={`relative w-20 h-14 rounded-lg overflow-hidden shrink-0 border-2 transition-all ${
                      selectedImage === img ? 'border-amber-500 scale-95 shadow-xs' : 'border-transparent opacity-75 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="Thumbnail" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Key Inclusions Highlights Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs">
            <div className="flex items-start space-x-2.5">
              <div className="p-2 rounded-lg bg-blue-100 text-blue-900 shrink-0">
                <HotelIcon className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-slate-800 block">Stays Included</span>
                <span className="text-slate-500">{pkg.hotels.join(', ')}</span>
              </div>
            </div>

            <div className="flex items-start space-x-2.5">
              <div className="p-2 rounded-lg bg-amber-100 text-amber-900 shrink-0">
                <Car className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-slate-800 block">Chauffeur Transport</span>
                <span className="text-slate-500">{pkg.transportation}</span>
              </div>
            </div>

            <div className="flex items-start space-x-2.5">
              <div className="p-2 rounded-lg bg-emerald-100 text-emerald-900 shrink-0">
                <Utensils className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-slate-800 block">Fooding & Meals</span>
                <span className="text-slate-500">{pkg.meals}</span>
              </div>
            </div>
          </div>

          {/* Day-by-Day Itinerary Accordion / Tabs */}
          <div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900 mb-3 font-heading flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-blue-900" />
              <span>Day-by-Day Detailed Itinerary</span>
            </h3>

            <div className="space-y-2.5">
              {pkg.itinerary.map((day) => {
                const isOpen = activeDay === day.day;
                return (
                  <div
                    key={day.day}
                    className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-2xs"
                  >
                    <button
                      onClick={() => setActiveDay(isOpen ? 0 : day.day)}
                      className="w-full text-left p-3.5 sm:p-4 flex items-center justify-between bg-slate-50/60 hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center space-x-3">
                        <span className="w-7 h-7 rounded-full bg-blue-900 text-amber-300 font-bold text-xs flex items-center justify-center shrink-0">
                          D{day.day}
                        </span>
                        <span className="font-bold text-slate-800 text-xs sm:text-sm">
                          {day.title}
                        </span>
                      </div>
                      {isOpen ? (
                        <ChevronUp className="w-4 h-4 text-slate-500" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-500" />
                      )}
                    </button>

                    {isOpen && (
                      <div className="p-4 pt-2 text-xs text-slate-600 space-y-3 bg-white border-t border-slate-100 animate-in fade-in duration-150">
                        <p className="leading-relaxed">{day.description}</p>
                        
                        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-[11px]">
                          <span className="font-semibold text-slate-700">Meals:</span>
                          {day.mealsIncluded.map((m, i) => (
                            <span key={i} className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-100">
                              {m}
                            </span>
                          ))}
                          {day.stayHotel && (
                            <>
                              <span className="text-slate-300">·</span>
                              <span className="font-semibold text-slate-700">Night Stay:</span>
                              <span className="text-blue-900 font-medium">{day.stayHotel}</span>
                            </>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Inclusions & Exclusions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-100">
              <h4 className="font-bold text-emerald-950 text-xs sm:text-sm uppercase tracking-wider mb-2.5 flex items-center space-x-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                <span>Inclusions</span>
              </h4>
              <ul className="space-y-1.5 text-xs text-emerald-900">
                {pkg.inclusions.map((inc, i) => (
                  <li key={i} className="flex items-start space-x-1.5">
                    <span className="text-emerald-700 font-bold shrink-0">✓</span>
                    <span>{inc}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-2xl bg-red-50/60 border border-red-100">
              <h4 className="font-bold text-red-950 text-xs sm:text-sm uppercase tracking-wider mb-2.5 flex items-center space-x-1.5">
                <XCircle className="w-4 h-4 text-red-700" />
                <span>Exclusions</span>
              </h4>
              <ul className="space-y-1.5 text-xs text-red-900">
                {pkg.exclusions.map((exc, i) => (
                  <li key={i} className="flex items-start space-x-1.5">
                    <span className="text-red-700 font-bold shrink-0">✗</span>
                    <span>{exc}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Terms & Conditions */}
          <div className="p-3.5 rounded-xl bg-slate-100 text-slate-600 text-xs space-y-1">
            <span className="font-bold text-slate-800 block">Booking Terms & Policy:</span>
            {pkg.terms.map((t, idx) => (
              <p key={idx}>• {t}</p>
            ))}
          </div>

        </div>

        {/* Sticky Bottom Action Bar */}
        <div className="sticky bottom-0 z-20 bg-white/95 backdrop-blur-md px-6 py-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
          <div>
            <span className="text-[11px] text-slate-400 uppercase tracking-wider block">Package Price Per Person</span>
            <div className="flex items-baseline space-x-2">
              <span className="text-2xl font-black text-slate-900 font-heading">
                ₹{pkg.discountedPrice || pkg.startingPrice}
              </span>
              {pkg.discountedPrice && (
                <span className="text-sm text-slate-400 line-through">
                  ₹{pkg.startingPrice}
                </span>
              )}
              <span className="text-xs text-slate-500 font-normal">+ 5% GST</span>
            </div>
          </div>

          <div className="flex items-center space-x-2.5 w-full sm:w-auto">
            <button
              onClick={() => onEnquireNow(pkg)}
              className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl border border-slate-300 text-slate-800 font-bold text-xs hover:bg-slate-100 transition-colors"
            >
              Enquire Custom Dates
            </button>
            <button
              onClick={() => onBookNow(pkg)}
              className="flex-1 sm:flex-initial px-6 py-2.5 rounded-xl bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95 flex items-center justify-center space-x-1.5 cursor-pointer"
            >
              <span>Instant Book</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
