import React, { useState } from 'react';
import {
  TravelPackage,
  Hotel,
  Booking,
  Enquiry,
  User,
  Destination
} from '../types';
import { StorageService } from '../services/storage';
import {
  Users,
  Briefcase,
  Building,
  Package,
  CalendarCheck,
  MessageSquare,
  CreditCard,
  IndianRupee,
  Plus,
  Trash2,
  CheckCircle,
  XCircle,
  Edit,
  Eye,
  ArrowUpRight,
  Sparkles,
  MapPin
} from 'lucide-react';

export const AdminPortal: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'PACKAGES' | 'BOOKINGS' | 'ENQUIRIES' | 'HOTELS' | 'DESTINATIONS'>('OVERVIEW');

  // Live state from StorageService
  const packages = StorageService.getPackages();
  const bookings = StorageService.getBookings();
  const enquiries = StorageService.getEnquiries();
  const hotels = StorageService.getHotels();
  const destinations = StorageService.getDestinations();
  const users = StorageService.getUsers();

  const totalCustomers = users.filter(u => u.role === 'CUSTOMER').length;
  const totalPartners = users.filter(u => u.role === 'VENDOR').length;
  const paidBookings = bookings.filter(b => b.paymentStatus === 'PAID');
  const totalRevenue = paidBookings.reduce((sum, b) => sum + b.totalAmount, 0);

  // Package Form state (Add new package)
  const [showAddPackageModal, setShowAddPackageModal] = useState(false);
  const [newPackage, setNewPackage] = useState<Partial<TravelPackage>>({
    name: '',
    destination: 'Digha',
    duration: '2 Nights / 3 Days',
    durationDays: 3,
    startingPrice: 4999,
    discountedPrice: 4499,
    category: 'BEACH',
    overview: '',
    coverImage: '/src/assets/images/hero_digha_sea_1790324572880.jpg',
    groupSize: 'Min 2 Travellers'
  });

  // Destination Form state
  const [showAddDestModal, setShowAddDestModal] = useState(false);
  const [newDest, setNewDest] = useState<Partial<Destination>>({
    name: '',
    state: '',
    country: 'India',
    tagline: '',
    description: '',
    startingPrice: 5999,
    bestTimeToVisit: 'October to March',
    image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80'
  });

  const handleCreatePackage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPackage.name) return;

    const fullPackage: TravelPackage = {
      id: `pkg_${Date.now()}`,
      name: newPackage.name,
      destination: newPackage.destination || 'Digha',
      duration: newPackage.duration || '3 Days',
      durationDays: newPackage.durationDays || 3,
      startingPrice: Number(newPackage.startingPrice) || 4999,
      discountedPrice: Number(newPackage.discountedPrice) || 4499,
      coverImage: newPackage.coverImage || '/src/assets/images/hero_digha_sea_1790324572880.jpg',
      gallery: [newPackage.coverImage || '/src/assets/images/hero_digha_sea_1790324572880.jpg'],
      overview: newPackage.overview || 'Scenic curated holiday package with GoDigha tour planning assistance.',
      itinerary: [
        { day: 1, title: 'Arrival & Check-in', description: 'Warm welcome by GoDigha chauffeur.', mealsIncluded: ['Dinner'], activities: ['Arrival'] },
        { day: 2, title: 'Local Sightseeing & Experiences', description: 'Full day sightseeing excursion.', mealsIncluded: ['Breakfast', 'Dinner'], activities: ['Sightseeing'] }
      ],
      hotels: ['Verified GoDigha Partner Hotel'],
      transportation: 'Dedicated AC Vehicle with chauffeur',
      meals: 'Breakfast and Dinner included',
      activities: ['Guided Sightseeing'],
      inclusions: ['Accommodation', 'Transfers', 'Meals as specified'],
      exclusions: ['Flight / Rail fares', 'Personal tips'],
      terms: ['100% money back on 48h cancellation'],
      groupSize: newPackage.groupSize || 'Min 2 Pax',
      category: (newPackage.category as any) || 'BEACH',
      status: 'ACTIVE',
      featured: true,
      rating: 5.0,
      reviewsCount: 12
    };

    StorageService.savePackage(fullPackage);
    setShowAddPackageModal(false);
  };

  const handleDeletePackage = (id: string) => {
    if (confirm('Are you sure you want to remove this package?')) {
      StorageService.deletePackage(id);
    }
  };

  const handleCreateDestination = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDest.name) return;

    const fullDest: Destination = {
      id: `dest_${Date.now()}`,
      name: newDest.name,
      state: newDest.state || 'India',
      country: newDest.country || 'India',
      tagline: newDest.tagline || 'Scenic travel destination',
      description: newDest.description || 'Pristine travel destination with curated packages.',
      image: newDest.image || 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80',
      bestTimeToVisit: newDest.bestTimeToVisit || 'All Year',
      popularFor: ['Sightseeing', 'Leisure', 'Culture'],
      startingPrice: Number(newDest.startingPrice) || 4999,
      featured: true
    };

    StorageService.saveDestination(fullDest);
    setShowAddDestModal(false);
  };

  const handleUpdateBookingStatus = (id: string, status: Booking['bookingStatus']) => {
    StorageService.updateBookingStatus(id, status);
  };

  const handleUpdateEnquiryStatus = (id: string, status: Enquiry['status'], notes?: string) => {
    StorageService.updateEnquiryStatus(id, status, notes);
  };

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Admin Header */}
      <div className="bg-[#0f2847] text-white rounded-3xl p-6 sm:p-8 shadow-xl mb-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-400 text-slate-950 text-xs font-bold uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>GoDigha Super Admin Console</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
            Travel Agency Central Command
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Global management of packages, partner hotels, bookings, live payments & enquiries
          </p>
        </div>

        <div className="flex flex-wrap gap-2 self-start md:self-auto">
          <button
            onClick={() => setShowAddPackageModal(true)}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl font-bold text-xs flex items-center space-x-1.5 shadow-md"
          >
            <Plus className="w-4 h-4" />
            <span>Add Package</span>
          </button>
          <button
            onClick={() => setShowAddDestModal(true)}
            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl font-bold text-xs flex items-center space-x-1.5 border border-white/20"
          >
            <MapPin className="w-4 h-4 text-amber-300" />
            <span>Add Destination</span>
          </button>
        </div>
      </div>

      {/* 8 Core Admin Dashboard Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Customers</span>
          <div className="text-2xl font-black text-slate-900 mt-0.5 font-heading">{totalCustomers}</div>
          <span className="text-[10px] text-blue-700 font-medium">Registered travellers</span>
        </div>

        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Partners</span>
          <div className="text-2xl font-black text-slate-900 mt-0.5 font-heading">{totalPartners}</div>
          <span className="text-[10px] text-emerald-700 font-medium">Hotels & operators</span>
        </div>

        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Hotels</span>
          <div className="text-2xl font-black text-slate-900 mt-0.5 font-heading">{hotels.length}</div>
          <span className="text-[10px] text-slate-500 font-medium">Digha & Mandarmani</span>
        </div>

        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Packages</span>
          <div className="text-2xl font-black text-slate-900 mt-0.5 font-heading">{packages.length}</div>
          <span className="text-[10px] text-purple-700 font-medium">Live holiday itineraries</span>
        </div>

        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Bookings</span>
          <div className="text-2xl font-black text-slate-900 mt-0.5 font-heading">{bookings.length}</div>
          <span className="text-[10px] text-emerald-700 font-medium">{paidBookings.length} Paid</span>
        </div>

        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Enquiries</span>
          <div className="text-2xl font-black text-slate-900 mt-0.5 font-heading">{enquiries.length}</div>
          <span className="text-[10px] text-amber-700 font-medium">Corporate & Custom</span>
        </div>

        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Successful Payments</span>
          <div className="text-2xl font-black text-emerald-700 mt-0.5 font-heading">{paidBookings.length}</div>
          <span className="text-[10px] text-slate-500 font-medium">Razorpay 100% verified</span>
        </div>

        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Revenue</span>
          <div className="text-2xl font-black text-slate-900 mt-0.5 font-heading">₹{totalRevenue.toLocaleString()}</div>
          <span className="text-[10px] text-emerald-600 font-semibold font-mono">Gross Transaction Volume</span>
        </div>
      </div>

      {/* Sub Navigation Tabs */}
      <div className="flex bg-slate-200/80 p-1 rounded-2xl max-w-2xl mb-6">
        <button
          onClick={() => setActiveTab('OVERVIEW')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'OVERVIEW' ? 'bg-white text-blue-950 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Overview
        </button>
        <button
          onClick={() => setActiveTab('PACKAGES')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'PACKAGES' ? 'bg-white text-blue-950 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Packages ({packages.length})
        </button>
        <button
          onClick={() => setActiveTab('BOOKINGS')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'BOOKINGS' ? 'bg-white text-blue-950 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Bookings ({bookings.length})
        </button>
        <button
          onClick={() => setActiveTab('ENQUIRIES')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'ENQUIRIES' ? 'bg-white text-blue-950 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Enquiries ({enquiries.length})
        </button>
        <button
          onClick={() => setActiveTab('DESTINATIONS')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'DESTINATIONS' ? 'bg-white text-blue-950 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Destinations ({destinations.length})
        </button>
      </div>

      {/* Tab: Overview (Recent Bookings + Enquiries Split) */}
      {activeTab === 'OVERVIEW' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Latest Bookings */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-3">
            <h3 className="font-bold text-slate-900 text-base font-heading">
              Recent Live Bookings
            </h3>
            <div className="space-y-2.5">
              {bookings.slice(0, 5).map((b) => (
                <div key={b.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between text-xs">
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="font-mono font-bold text-blue-900">{b.id}</span>
                      <span className="text-slate-400">·</span>
                      <span className="font-semibold text-slate-800">{b.customerName}</span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5 truncate max-w-xs">{b.itemTitle}</div>
                  </div>
                  <div className="text-right">
                    <span className="font-black text-slate-900 block">₹{b.totalAmount}</span>
                    <span className="text-[10px] text-emerald-700 font-bold uppercase">{b.bookingStatus}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Latest Enquiries */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-3">
            <h3 className="font-bold text-slate-900 text-base font-heading">
              Actionable Group Enquiries
            </h3>
            <div className="space-y-2.5">
              {enquiries.slice(0, 5).map((enq) => (
                <div key={enq.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between text-xs">
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="font-mono font-bold text-amber-800">{enq.id}</span>
                      <span className="text-slate-400">·</span>
                      <span className="font-semibold text-slate-800">{enq.name}</span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">{enq.destination} ({enq.travellersCount} Pax)</div>
                  </div>
                  <div className="text-right">
                    <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 text-[10px] font-bold uppercase">
                      {enq.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab: Packages Management */}
      {activeTab === 'PACKAGES' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-slate-900 text-base font-heading">Travel Packages Catalog</h3>
              <p className="text-xs text-slate-500">Edit, activate or retire packages from the public marketplace</p>
            </div>
            <button
              onClick={() => setShowAddPackageModal(true)}
              className="px-3.5 py-1.5 bg-blue-900 hover:bg-blue-800 text-amber-300 rounded-lg text-xs font-bold flex items-center space-x-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create New</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 text-slate-800 font-bold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="p-3">Package Details</th>
                  <th className="p-3">Destination</th>
                  <th className="p-3">Duration</th>
                  <th className="p-3">Pricing (₹)</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {packages.map((pkg) => (
                  <tr key={pkg.id} className="hover:bg-slate-50/80">
                    <td className="p-3">
                      <div className="font-bold text-slate-900">{pkg.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{pkg.id}</div>
                    </td>
                    <td className="p-3 font-medium text-slate-800">{pkg.destination}</td>
                    <td className="p-3">{pkg.duration}</td>
                    <td className="p-3">
                      <span className="font-black text-slate-900">₹{pkg.discountedPrice || pkg.startingPrice}</span>
                    </td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        {pkg.status}
                      </span>
                    </td>
                    <td className="p-3 text-right space-x-2">
                      <button
                        onClick={() => handleDeletePackage(pkg.id)}
                        className="text-red-600 hover:text-red-800 p-1"
                        title="Delete Package"
                      >
                        <Trash2 className="w-4 h-4 inline" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Bookings Management */}
      {activeTab === 'BOOKINGS' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-base font-heading">All Bookings & Transactions</h3>
            <p className="text-xs text-slate-500">Live guest bookings, payment statuses, and verification IDs</p>
          </div>

          <div className="space-y-3">
            {bookings.map((b) => (
              <div key={b.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center space-x-2">
                    <span className="font-mono font-bold text-blue-900 text-sm">{b.id}</span>
                    <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px] uppercase">
                      Payment: {b.paymentStatus}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-bold text-[10px] uppercase">
                      Booking: {b.bookingStatus}
                    </span>
                  </div>

                  <div className="flex items-center space-x-2">
                    {b.bookingStatus === 'PROCESSING' && (
                      <button
                        onClick={() => handleUpdateBookingStatus(b.id, 'CONFIRMED')}
                        className="px-2.5 py-1 bg-emerald-700 text-white rounded font-bold text-[11px]"
                      >
                        Approve Confirmation
                      </button>
                    )}
                    {b.bookingStatus === 'CONFIRMED' && (
                      <button
                        onClick={() => handleUpdateBookingStatus(b.id, 'COMPLETED')}
                        className="px-2.5 py-1 bg-slate-700 text-white rounded font-bold text-[11px]"
                      >
                        Mark Completed
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 p-2.5 bg-white rounded-xl border border-slate-100">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Lead Guest</span>
                    <strong className="text-slate-800">{b.customerName}</strong> ({b.customerPhone})
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Item / Tour</span>
                    <span className="text-slate-800 truncate block">{b.itemTitle}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Total Revenue</span>
                    <strong className="text-emerald-700 text-sm">₹{b.totalAmount}</strong> (Govt Tax ₹{b.taxAmount})
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Enquiries */}
      {activeTab === 'ENQUIRIES' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-base font-heading">Corporate & Group Enquiries Pipeline</h3>
            <p className="text-xs text-slate-500">Track and respond to high-value group inquiries</p>
          </div>

          <div className="space-y-3">
            {enquiries.map((enq) => (
              <div key={enq.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-mono font-bold text-amber-800">{enq.id}</span>
                    <h4 className="font-bold text-slate-900 text-sm mt-0.5">
                      {enq.name} ({enq.phone}) · {enq.destination}
                    </h4>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    {(['NEW', 'CONTACTED', 'QUOTED', 'CONVERTED'] as const).map((status) => (
                      <button
                        key={status}
                        onClick={() => handleUpdateEnquiryStatus(enq.id, status)}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          enq.status === status
                            ? 'bg-blue-900 text-amber-300'
                            : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        {status}
                      </button>
                    ))}
                  </div>
                </div>

                <p className="text-slate-600 bg-white p-2.5 rounded-xl border border-slate-100">
                  {enq.message} (Dates: {enq.travelDates}, Pax: {enq.travellersCount}, Budget: {enq.budgetRange})
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Destinations */}
      {activeTab === 'DESTINATIONS' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-slate-900 text-base font-heading">Configured Destinations</h3>
              <p className="text-xs text-slate-500">Dynamic destination system allows adding new circuits anytime</p>
            </div>
            <button
              onClick={() => setShowAddDestModal(true)}
              className="px-3.5 py-1.5 bg-blue-900 hover:bg-blue-800 text-amber-300 rounded-lg text-xs font-bold flex items-center space-x-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Destination</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {destinations.map((d) => (
              <div key={d.id} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex space-x-3 items-center">
                <img
                  src={d.image}
                  alt={d.name}
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 rounded-xl object-cover shrink-0"
                />
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{d.name}</h4>
                  <div className="text-[11px] text-slate-500">{d.state}, {d.country}</div>
                  <div className="text-[11px] font-bold text-blue-900 mt-1">Starting from ₹{d.startingPrice}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal: Create Package */}
      {showAddPackageModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-base font-heading">Add New Travel Package</h3>
              <button onClick={() => setShowAddPackageModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>
            <form onSubmit={handleCreatePackage} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Package Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Meghalaya Living Root Bridge Odyssey"
                  value={newPackage.name}
                  onChange={(e) => setNewPackage({ ...newPackage, name: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-2"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Destination *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Meghalaya"
                    value={newPackage.destination}
                    onChange={(e) => setNewPackage({ ...newPackage, destination: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded p-2"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Duration *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 4 Nights / 5 Days"
                    value={newPackage.duration}
                    onChange={(e) => setNewPackage({ ...newPackage, duration: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded p-2"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Starting Price (₹)</label>
                  <input
                    type="number"
                    value={newPackage.startingPrice}
                    onChange={(e) => setNewPackage({ ...newPackage, startingPrice: parseInt(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded p-2"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Discounted Price (₹)</label>
                  <input
                    type="number"
                    value={newPackage.discountedPrice}
                    onChange={(e) => setNewPackage({ ...newPackage, discountedPrice: parseInt(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-300 rounded p-2"
                  />
                </div>
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1">Brief Overview</label>
                <textarea
                  rows={2}
                  value={newPackage.overview}
                  onChange={(e) => setNewPackage({ ...newPackage, overview: e.target.value })}
                  placeholder="Overview of this trip..."
                  className="w-full bg-slate-50 border border-slate-300 rounded p-2"
                />
              </div>
              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddPackageModal(false)}
                  className="px-3 py-1.5 bg-slate-200 rounded text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-900 text-amber-300 rounded font-bold"
                >
                  Publish Package
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Create Destination */}
      {showAddDestModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-base font-heading">Add New Travel Destination</h3>
              <button onClick={() => setShowAddDestModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>
            <form onSubmit={handleCreateDestination} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Destination Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Andaman & Nicobar"
                  value={newDest.name}
                  onChange={(e) => setNewDest({ ...newDest, name: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-2"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1">State / Region</label>
                <input
                  type="text"
                  placeholder="e.g. Andaman"
                  value={newDest.state}
                  onChange={(e) => setNewDest({ ...newDest, state: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-2"
                />
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1">Catchy Tagline</label>
                <input
                  type="text"
                  placeholder="e.g. Emerald Islands & Coral Reefs"
                  value={newDest.tagline}
                  onChange={(e) => setNewDest({ ...newDest, tagline: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-2"
                />
              </div>
              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddDestModal(false)}
                  className="px-3 py-1.5 bg-slate-200 rounded text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-900 text-amber-300 rounded font-bold"
                >
                  Save Destination
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
