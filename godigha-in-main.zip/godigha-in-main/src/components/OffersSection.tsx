import React, { useState } from 'react';
import { Tag, Sparkles, Copy, Check, ArrowRight } from 'lucide-react';

interface OffersSectionProps {
  onExplorePackages: () => void;
}

export const OffersSection: React.FC<OffersSectionProps> = ({ onExplorePackages }) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const offers = [
    {
      code: 'GODIGHA500',
      title: 'Flat ₹500 OFF on First Booking',
      description: 'Applicable on any Digha or Mandarmani beach package above ₹3,000.',
      expiry: 'Valid until 31 Dec 2026',
      badge: 'Bestseller'
    },
    {
      code: 'WELCOME10',
      title: '10% Instant Discount on Hill Packages',
      description: 'Special seasonal promotion on Darjeeling, Sikkim and Gangtok tour packages.',
      expiry: 'Limited Slots',
      badge: 'Limited Time'
    },
    {
      code: 'CORP2026',
      title: 'Corporate Offsite Special Package',
      description: 'Complimentary DJ & Sound Setup with any 25+ Pax corporate conference in Mandarmani.',
      expiry: 'Corporate Only',
      badge: 'Group Special'
    }
  ];

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold uppercase tracking-wider mb-2">
          <Tag className="w-3.5 h-3.5" />
          <span>Exclusive Travel Savings</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 font-heading">
          GoDigha Holiday Offers & Coupons
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 mt-1">
          Apply these verified promo codes at checkout for instant discounts on hotels and packages.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {offers.map((offer) => (
          <div
            key={offer.code}
            className="bg-white rounded-3xl p-6 border-2 border-dashed border-amber-300 shadow-sm flex flex-col justify-between relative overflow-hidden"
          >
            <div className="absolute top-3 right-3 bg-amber-500 text-slate-950 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase">
              {offer.badge}
            </div>

            <div>
              <span className="text-xs text-slate-400 block mb-1">{offer.expiry}</span>
              <h3 className="font-extrabold text-slate-900 text-base font-heading pr-12">
                {offer.title}
              </h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                {offer.description}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
              <div className="font-mono font-bold text-blue-900 bg-blue-50 px-3 py-1.5 rounded-lg text-xs tracking-wider border border-blue-100">
                {offer.code}
              </div>

              <button
                onClick={() => handleCopy(offer.code)}
                className="px-3.5 py-1.5 rounded-lg bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs flex items-center space-x-1 transition-colors"
              >
                {copiedCode === offer.code ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-10 text-center">
        <button
          onClick={onExplorePackages}
          className="inline-flex items-center space-x-2 px-6 py-3 rounded-2xl bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-sm shadow-md"
        >
          <span>Apply Code on Packages</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
