import React from 'react';
import { Review } from '../types';
import { Star, ShieldCheck, MapPin, Quote } from 'lucide-react';
import { BUSINESS_INFO } from '../data/mockData';

interface ReviewsSectionProps {
  reviews: Review[];
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({ reviews }) => {
  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center space-x-1.5 text-xs font-bold uppercase tracking-wider text-blue-900 mb-1">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Verified Customer Experiences</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading">
              Trusted by Travellers in Digha & Beyond
            </h2>
            <p className="text-sm text-slate-600 mt-1 max-w-xl">
              Authentic guest reviews from our Google Business Profile in Old Digha, West Bengal.
            </p>
          </div>

          {/* Google 5.0 Star Summary Card */}
          <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-4 self-start md:self-auto">
            <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-200 flex flex-col items-center justify-center font-heading">
              <span className="text-xl font-black text-amber-600 leading-none">5.0</span>
              <span className="text-[9px] text-slate-500 font-bold uppercase">Rating</span>
            </div>
            <div>
              <div className="flex text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <div className="text-xs font-bold text-slate-800 mt-0.5">
                {BUSINESS_INFO.reviewsCount} Google Reviews
              </div>
              <div className="text-[10px] text-slate-500 flex items-center space-x-1">
                <MapPin className="w-2.5 h-2.5 text-slate-400" />
                <span>{BUSINESS_INFO.address}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Testimonials Grid showcasing the authentic reviews from prompt */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {reviews.slice(0, 4).map((rev) => (
            <div
              key={rev.id}
              className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div>
                {/* 5-star rating */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex text-amber-400">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-current" />
                    ))}
                  </div>
                  <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-semibold border border-emerald-100">
                    {rev.verifiedSource}
                  </span>
                </div>

                <Quote className="w-6 h-6 text-slate-200 mb-1" />
                <p className="text-xs sm:text-sm text-slate-700 italic leading-relaxed">
                  "{rev.comment}"
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-900 block">{rev.author}</span>
                  {rev.tripType && <span className="text-[10px] text-slate-500">{rev.tripType}</span>}
                </div>
                <span className="text-[10px] text-slate-400">{rev.date}</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
