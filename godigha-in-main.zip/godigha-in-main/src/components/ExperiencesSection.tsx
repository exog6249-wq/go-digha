import React, { useState } from 'react';
import { WaterActivity, BikeRental, SightseeingTour } from '../types';
import { Waves, Bike, Compass, Check, ShieldAlert, ArrowRight, ShieldCheck, Clock } from 'lucide-react';
import { BUSINESS_INFO } from '../data/mockData';

interface ExperiencesSectionProps {
  activities: WaterActivity[];
  bikes: BikeRental[];
  sightseeing: SightseeingTour[];
  onBookActivity: (act: WaterActivity) => void;
  onBookBike: (bike: BikeRental) => void;
  onBookSightseeing: (tour: SightseeingTour) => void;
}

export const ExperiencesSection: React.FC<ExperiencesSectionProps> = ({
  activities,
  bikes,
  sightseeing,
  onBookActivity,
  onBookBike,
  onBookSightseeing
}) => {
  const [activeTab, setActiveTab] = useState<'WATER' | 'BIKES' | 'SIGHTSEEING'>('WATER');

  return (
    <section className="py-10 px-4 sm:px-6 lg:px-8 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header with Segmented Tab Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-cyan-700 mb-1">
              Coastal Adventures & Leisure
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading">
              Water Sports, Rental Bikes & Sightseeing
            </h2>
            <p className="text-sm text-slate-600 mt-1 max-w-xl">
              Make the most of Digha and Mandarmani with certified maritime watersports, self-drive rental scooters, and guided half-day excursions.
            </p>
          </div>

          {/* Segmented Controls */}
          <div className="flex bg-slate-200/80 p-1 rounded-xl self-start md:self-auto">
            <button
              onClick={() => setActiveTab('WATER')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
                activeTab === 'WATER' ? 'bg-white text-cyan-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Waves className="w-3.5 h-3.5" />
              <span>Water Sports</span>
            </button>
            <button
              onClick={() => setActiveTab('BIKES')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
                activeTab === 'BIKES' ? 'bg-white text-indigo-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Bike className="w-3.5 h-3.5" />
              <span>Rental Bikes</span>
            </button>
            <button
              onClick={() => setActiveTab('SIGHTSEEING')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 ${
                activeTab === 'SIGHTSEEING' ? 'bg-white text-emerald-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Sightseeing Tours</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Water Sports */}
        {activeTab === 'WATER' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {activities.map((act) => (
              <div
                key={act.id}
                className="bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  <div className="relative aspect-4/3 overflow-hidden bg-slate-100">
                    <img
                      src={act.image}
                      alt={act.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-xs text-white text-[10px] font-semibold px-2 py-0.5 rounded">
                      {act.duration}
                    </div>
                  </div>

                  <div className="p-4">
                    <div className="text-[11px] font-semibold text-cyan-700">{act.location}</div>
                    <h3 className="font-bold text-slate-900 text-sm mt-0.5 group-hover:text-blue-900 transition-colors">
                      {act.name}
                    </h3>
                    <p className="text-xs text-slate-600 mt-1 line-clamp-2">{act.description}</p>
                    
                    <div className="mt-3 p-2 rounded-lg bg-cyan-50/70 border border-cyan-100/60 text-[11px] text-cyan-900 flex items-start space-x-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-cyan-600 shrink-0 mt-0.5" />
                      <span>{act.safetyBriefing}</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 pt-0 flex items-center justify-between mt-2 border-t border-slate-100 pt-3">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Price per head</span>
                    <span className="text-base font-black text-slate-900">₹{act.price}</span>
                  </div>
                  <button
                    onClick={() => onBookActivity(act)}
                    className="px-3.5 py-1.5 rounded-lg bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs transition-colors"
                  >
                    Book Slot
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Rental Bikes */}
        {activeTab === 'BIKES' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {bikes.map((bike) => (
              <div
                key={bike.id}
                className="bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  <div className="relative aspect-16/10 overflow-hidden bg-slate-100">
                    <img
                      src={bike.image}
                      alt={bike.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-2 left-2 bg-indigo-900/80 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded">
                      {bike.type}
                    </div>
                  </div>

                  <div className="p-5">
                    <h3 className="font-bold text-slate-900 text-base">{bike.name}</h3>
                    <div className="text-xs text-slate-500 mt-1">
                      Pickup Hub: <strong>{bike.pickupLocation}</strong>
                    </div>

                    <div className="mt-3.5 space-y-1 text-xs text-slate-600">
                      <div className="flex items-center space-x-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{bike.helmetsIncluded} Clean Helmets Included</span>
                      </div>
                      <div className="flex items-center space-x-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Security Deposit: ₹{bike.securityDeposit} (Refundable)</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-5 pt-0 flex items-center justify-between border-t border-slate-100 pt-3.5">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Daily Rental</span>
                    <div className="flex items-baseline space-x-1">
                      <span className="text-xl font-black text-slate-900 font-heading">₹{bike.pricePerDay}</span>
                      <span className="text-xs text-slate-500">/ 24 hrs</span>
                    </div>
                  </div>
                  <button
                    onClick={() => onBookBike(bike)}
                    className="px-4 py-2 rounded-lg bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs transition-colors shadow-xs"
                  >
                    Rent This Bike
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 3: Guided Sightseeing Circuits */}
        {activeTab === 'SIGHTSEEING' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {sightseeing.map((tour) => (
              <div
                key={tour.id}
                className="bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col md:flex-row group"
              >
                <div className="md:w-5/12 relative aspect-16/10 md:aspect-auto overflow-hidden bg-slate-100">
                  <img
                    src={tour.image}
                    alt={tour.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-xs text-white text-[11px] font-semibold px-2 py-0.5 rounded flex items-center space-x-1">
                    <Clock className="w-3 h-3 text-amber-400" />
                    <span>{tour.duration}</span>
                  </div>
                </div>

                <div className="md:w-7/12 p-5 flex flex-col justify-between">
                  <div>
                    <div className="text-[11px] font-semibold text-emerald-700">{tour.destination}</div>
                    <h3 className="font-bold text-slate-900 text-base mt-0.5">{tour.name}</h3>
                    <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">{tour.description}</p>
                    
                    <div className="mt-3">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                        Tour Highlights:
                      </span>
                      <ul className="space-y-1 text-xs text-slate-600">
                        {tour.highlights.slice(0, 3).map((h, idx) => (
                          <li key={idx} className="flex items-start space-x-1.5">
                            <span className="text-emerald-600 font-bold">•</span>
                            <span className="line-clamp-1">{h}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Total Car Fare</span>
                      <span className="text-lg font-black text-slate-900 font-heading">₹{tour.price}</span>
                    </div>
                    <button
                      onClick={() => onBookSightseeing(tour)}
                      className="px-4 py-2 rounded-lg bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs transition-colors shadow-xs"
                    >
                      Book Tour
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
