import React, { useState, useEffect, useRef } from 'react';
import { User, UserRole } from '../types';
import { StorageService } from '../services/storage';
import {
  Lock,
  Mail,
  Phone,
  Eye,
  EyeOff,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  X,
  Smartphone,
  ShieldCheck,
  ChevronLeft,
  User as UserIcon,
  RotateCcw
} from 'lucide-react';
import { GoDighaLogo } from './GoDighaLogo';

interface LoginModalProps {
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
  initialMode?: 'LOGIN' | 'REGISTER' | 'OTP' | 'FORGOT';
  customNotice?: string;
}

type AuthMode = 'LOGIN' | 'REGISTER' | 'OTP_STEP_1' | 'OTP_STEP_2' | 'FORGOT' | 'FORGOT_SUCCESS';

export const LoginModal: React.FC<LoginModalProps> = ({
  onClose,
  onLoginSuccess,
  initialMode = 'LOGIN',
  customNotice
}) => {
  const [mode, setMode] = useState<AuthMode>(
    initialMode === 'REGISTER'
      ? 'REGISTER'
      : initialMode === 'OTP'
      ? 'OTP_STEP_1'
      : initialMode === 'FORGOT'
      ? 'FORGOT'
      : 'LOGIN'
  );

  // Standard Login State
  const [identifier, setIdentifier] = useState('rahul.b@example.com');
  const [password, setPassword] = useState('••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // Registration State
  const [regFirstName, setRegFirstName] = useState('');
  const [regLastName, setRegLastName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [optInOffers, setOptInOffers] = useState(true);

  // Mobile OTP State
  const [otpPhone, setOtpPhone] = useState('9830124567');
  const [otpDigits, setOtpDigits] = useState(['', '', '', '', '', '']);
  const [resendTimer, setResendTimer] = useState(30);
  const [timerActive, setTimerActive] = useState(false);
  const otpInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Forgot Password State
  const [resetEmail, setResetEmail] = useState('');

  // Loading & Error States
  const [isLoading, setIsLoading] = useState(false);
  const [loadingText, setLoadingText] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // OTP Countdown Timer
  useEffect(() => {
    let interval: any = null;
    if (timerActive && resendTimer > 0) {
      interval = setInterval(() => {
        setResendTimer(prev => prev - 1);
      }, 1000);
    } else if (resendTimer === 0) {
      setTimerActive(false);
    }
    return () => clearInterval(interval);
  }, [timerActive, resendTimer]);

  // Handle Standard Login
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!identifier.trim()) {
      setErrorMessage('Please enter your email or mobile number.');
      return;
    }

    setIsLoading(true);
    setLoadingText('Signing in...');

    setTimeout(() => {
      const result = StorageService.loginUser(identifier, password);
      setIsLoading(false);
      if (result.success && result.user) {
        onLoginSuccess(result.user);
        onClose();
      } else {
        setErrorMessage(result.error || 'Invalid credentials. Please try again.');
      }
    }, 700);
  };

  // Handle Mobile OTP Step 1 (Send OTP)
  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    const cleanPhone = otpPhone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      return;
    }

    setIsLoading(true);
    setLoadingText('Sending OTP...');

    setTimeout(() => {
      setIsLoading(false);
      setMode('OTP_STEP_2');
      setResendTimer(30);
      setTimerActive(true);
      // Auto fill mock OTP for smooth testing
      setOtpDigits(['6', '2', '8', '4', '9', '1']);
    }, 800);
  };

  // Handle OTP digit changes
  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) {
      // Paste handling
      const pasted = value.slice(0, 6).split('');
      const newDigits = [...otpDigits];
      pasted.forEach((char, i) => {
        if (i < 6) newDigits[i] = char;
      });
      setOtpDigits(newDigits);
      const nextIdx = Math.min(pasted.length, 5);
      otpInputRefs.current[nextIdx]?.focus();
      return;
    }

    const newDigits = [...otpDigits];
    newDigits[index] = value;
    setOtpDigits(newDigits);

    // Auto-advance
    if (value && index < 5) {
      otpInputRefs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      otpInputRefs.current[index - 1]?.focus();
    }
  };

  // Handle Mobile OTP Step 2 (Verify & Continue)
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    const fullOtp = otpDigits.join('');
    if (fullOtp.length < 6) {
      setErrorMessage('Please enter the full 6-digit OTP.');
      return;
    }

    setIsLoading(true);
    setLoadingText('Verifying OTP...');

    setTimeout(() => {
      setIsLoading(false);
      const fullPhone = `+91 ${otpPhone.replace(/\D/g, '')}`;
      const result = StorageService.loginUser(fullPhone);
      if (result.success && result.user) {
        onLoginSuccess(result.user);
        onClose();
      } else {
        setErrorMessage('Invalid OTP. Please check the code or request a new one.');
      }
    }, 900);
  };

  // Handle Registration
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!regFirstName.trim() || !regLastName.trim()) {
      setErrorMessage('Please provide both first and last name.');
      return;
    }
    if (!regEmail.trim() || !regEmail.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    if (!regPhone.trim() || regPhone.replace(/\D/g, '').length < 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number.');
      return;
    }
    if (regPassword.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }
    if (regPassword !== regConfirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }
    if (!agreeTerms) {
      setErrorMessage('You must agree to the Terms & Conditions and Privacy Policy.');
      return;
    }

    setIsLoading(true);
    setLoadingText('Creating your account...');

    setTimeout(() => {
      const result = StorageService.registerUser({
        firstName: regFirstName,
        lastName: regLastName,
        email: regEmail,
        phone: `+91 ${regPhone.replace(/\D/g, '')}`,
        password: regPassword
      });
      setIsLoading(false);
      if (result.success && result.user) {
        onLoginSuccess(result.user);
        onClose();
      } else {
        setErrorMessage(result.error || 'Failed to create account.');
      }
    }, 850);
  };

  // Handle Forgot Password
  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!resetEmail.trim() || !resetEmail.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }

    setIsLoading(true);
    setLoadingText('Sending reset link...');

    setTimeout(() => {
      setIsLoading(false);
      setMode('FORGOT_SUCCESS');
    }, 800);
  };

  // Simulate Google Sign-In
  const handleGoogleSignIn = () => {
    setIsLoading(true);
    setLoadingText('Connecting to Google...');

    setTimeout(() => {
      setIsLoading(false);
      const googleUser: User = {
        id: `user_google_${Date.now()}`,
        name: 'Rahul Banerjee',
        firstName: 'Rahul',
        lastName: 'Banerjee',
        email: 'rahul.banerjee.google@gmail.com',
        phone: '+91 98301 24567',
        role: 'CUSTOMER',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        goCashBalance: 1000,
        createdAt: new Date().toISOString()
      };
      StorageService.setCurrentUser(googleUser);
      onLoginSuccess(googleUser);
      onClose();
    }, 1000);
  };

  // Quick Demo account switcher helper
  const handleQuickDemoSwitch = (role: UserRole) => {
    if (role === 'CUSTOMER') {
      setIdentifier('rahul.b@example.com');
      setPassword('••••••••');
    } else if (role === 'VENDOR') {
      setIdentifier('samir.hotelier@godigha.com');
      setPassword('••••••••');
    } else if (role === 'ADMIN') {
      setIdentifier('admin@godigha.com');
      setPassword('••••••••');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200 text-slate-800 my-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-sm transition-colors"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-full shadow-md mx-auto mb-3 overflow-hidden border-2 border-amber-400">
            <GoDighaLogo className="w-full h-full object-cover" />
          </div>

          {/* Custom context notice (e.g. from booking / saved package) */}
          {customNotice && (
            <div className="mb-3 px-3 py-1.5 rounded-xl bg-orange-50 border border-orange-200 text-[11px] font-semibold text-orange-800 flex items-center justify-center space-x-1.5">
              <Sparkles className="w-3.5 h-3.5 text-orange-600 shrink-0" />
              <span>{customNotice}</span>
            </div>
          )}

          {/* Headings according to active mode */}
          {mode === 'LOGIN' && (
            <>
              <h2 className="text-2xl font-black text-slate-900 font-heading">
                Welcome to GoDigha
              </h2>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                Login to manage your trips, enquiries, bookings and travel plans.
              </p>
            </>
          )}

          {mode === 'OTP_STEP_1' && (
            <>
              <h2 className="text-2xl font-black text-slate-900 font-heading">
                Login with Mobile
              </h2>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                We will send an SMS with a 6-digit verification code.
              </p>
            </>
          )}

          {mode === 'OTP_STEP_2' && (
            <>
              <h2 className="text-2xl font-black text-slate-900 font-heading">
                Verify Mobile Number
              </h2>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                Enter the 6-digit OTP sent to <span className="font-bold text-slate-800">+91 {otpPhone}</span>.
              </p>
            </>
          )}

          {mode === 'REGISTER' && (
            <>
              <h2 className="text-2xl font-black text-slate-900 font-heading">
                Create your GoDigha Account
              </h2>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                Unlock member-only discounts, GoCash rewards and manage your beach holidays.
              </p>
            </>
          )}

          {mode === 'FORGOT' && (
            <>
              <h2 className="text-2xl font-black text-slate-900 font-heading">
                Reset your password
              </h2>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                Enter your registered email address and we'll send you instructions to reset your password.
              </p>
            </>
          )}

          {mode === 'FORGOT_SUCCESS' && (
            <>
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-2">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-black text-slate-900 font-heading">
                Reset Link Sent!
              </h2>
              <p className="text-xs text-slate-600 mt-1">
                Password reset instructions have been sent to your email.
              </p>
            </>
          )}
        </div>

        {/* Global Error Message */}
        {errorMessage && (
          <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-start space-x-2 animate-in fade-in duration-150">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* MODE 1: STANDARD EMAIL / MOBILE LOGIN */}
        {/* ------------------------------------------------------------- */}
        {mode === 'LOGIN' && (
          <div className="space-y-4">
            
            {/* Quick Demo Switcher Tabs */}
            <div className="flex p-1 bg-slate-100 rounded-xl text-[11px] font-bold text-slate-600">
              <button
                type="button"
                onClick={() => handleQuickDemoSwitch('CUSTOMER')}
                className={`flex-1 py-1 rounded-lg transition-all ${identifier.includes('rahul') ? 'bg-white text-blue-900 shadow-xs' : ''}`}
              >
                Customer
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoSwitch('VENDOR')}
                className={`flex-1 py-1 rounded-lg transition-all ${identifier.includes('samir') ? 'bg-white text-emerald-800 shadow-xs' : ''}`}
              >
                Partner
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoSwitch('ADMIN')}
                className={`flex-1 py-1 rounded-lg transition-all ${identifier.includes('admin') ? 'bg-white text-indigo-900 shadow-xs' : ''}`}
              >
                Admin
              </button>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-3.5">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Email / Mobile Number
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="Enter email or 10-digit mobile"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all pl-9"
                  />
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700">Password</label>
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMessage('');
                      setResetEmail(identifier.includes('@') ? identifier : '');
                      setMode('FORGOT');
                    }}
                    className="text-[11px] font-semibold text-orange-600 hover:text-orange-700 hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all pl-9 pr-10"
                  />
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                    title={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Remember Me */}
              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center space-x-2 text-xs text-slate-600 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 text-orange-600 rounded border-slate-300 focus:ring-orange-500"
                  />
                  <span>Remember me</span>
                </label>
              </div>

              {/* Primary Login Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-sm shadow-lg shadow-orange-500/25 transition-all active:scale-98 flex items-center justify-center space-x-2 disabled:opacity-60 cursor-pointer"
              >
                {isLoading ? (
                  <span>{loadingText}</span>
                ) : (
                  <>
                    <span>Login</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* OR Divider */}
            <div className="relative my-4">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-3 text-slate-400 font-bold">OR</span>
              </div>
            </div>

            {/* Alternative Login Actions */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isLoading}
                className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-bold text-xs sm:text-sm flex items-center justify-center space-x-2.5 transition-all shadow-xs active:scale-98"
              >
                {/* Google SVG Icon */}
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setErrorMessage('');
                  setMode('OTP_STEP_1');
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold text-xs sm:text-sm flex items-center justify-center space-x-2 transition-all active:scale-98"
              >
                <Smartphone className="w-4 h-4 text-orange-600" />
                <span>Login with Mobile OTP</span>
              </button>
            </div>

            {/* Bottom Register Switch */}
            <div className="pt-2 text-center text-xs text-slate-500">
              Don't have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setErrorMessage('');
                  setMode('REGISTER');
                }}
                className="text-orange-600 font-bold hover:underline"
              >
                Create Account
              </button>
            </div>

          </div>
        )}

        {/* ------------------------------------------------------------- */}
        {/* MODE 2: MOBILE OTP STEP 1 */}
        {/* ------------------------------------------------------------- */}
        {mode === 'OTP_STEP_1' && (
          <form onSubmit={handleSendOtp} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Mobile Number
              </label>
              <div className="flex">
                <span className="inline-flex items-center px-3 rounded-l-xl border border-r-0 border-slate-200 bg-slate-100 text-slate-700 text-xs font-bold">
                  🇮🇳 +91
                </span>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={otpPhone}
                  onChange={(e) => setOtpPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="Enter 10-digit number"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-r-xl text-xs sm:text-sm font-bold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-all font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-sm shadow-lg shadow-orange-500/25 transition-all active:scale-98 flex items-center justify-center space-x-2"
            >
              {isLoading ? <span>{loadingText}</span> : <span>Send OTP</span>}
            </button>

            <button
              type="button"
              onClick={() => {
                setErrorMessage('');
                setMode('LOGIN');
              }}
              className="w-full text-center text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center justify-center space-x-1"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Back to standard login</span>
            </button>
          </form>
        )}

        {/* ------------------------------------------------------------- */}
        {/* MODE 2: MOBILE OTP STEP 2 (VERIFY DIGITS) */}
        {/* ------------------------------------------------------------- */}
        {mode === 'OTP_STEP_2' && (
          <form onSubmit={handleVerifyOtp} className="space-y-4">
            
            {/* 6 Digit Input Boxes */}
            <div className="flex justify-between gap-2 max-w-xs mx-auto">
              {otpDigits.map((digit, index) => (
                <input
                  key={index}
                  ref={(el) => {
                    otpInputRefs.current[index] = el;
                  }}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOtpChange(index, e.target.value)}
                  onKeyDown={(e) => handleOtpKeyDown(index, e)}
                  className="w-11 h-12 text-center text-lg font-black font-mono bg-slate-50 border-2 border-slate-200 rounded-xl focus:bg-white focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 focus:outline-none transition-all text-slate-900"
                />
              ))}
            </div>

            {/* Countdown / Resend */}
            <div className="flex items-center justify-between text-xs px-1">
              {resendTimer > 0 ? (
                <span className="text-slate-400">
                  Resend OTP in <span className="font-bold text-slate-700">{resendTimer}s</span>
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setResendTimer(30);
                    setTimerActive(true);
                    setOtpDigits(['6', '2', '8', '4', '9', '1']);
                  }}
                  className="text-orange-600 font-bold hover:underline flex items-center space-x-1"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Resend OTP</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  setErrorMessage('');
                  setMode('OTP_STEP_1');
                }}
                className="text-slate-500 hover:text-slate-800 font-semibold"
              >
                Change Mobile Number
              </button>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-sm shadow-lg shadow-orange-500/25 transition-all active:scale-98 flex items-center justify-center space-x-2"
            >
              {isLoading ? <span>{loadingText}</span> : <span>Verify & Continue</span>}
            </button>
          </form>
        )}

        {/* ------------------------------------------------------------- */}
        {/* MODE 3: CREATE ACCOUNT */}
        {/* ------------------------------------------------------------- */}
        {mode === 'REGISTER' && (
          <form onSubmit={handleRegisterSubmit} className="space-y-3">
            
            {/* First and Last Name Grid */}
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">First Name</label>
                <input
                  type="text"
                  required
                  value={regFirstName}
                  onChange={(e) => setRegFirstName(e.target.value)}
                  placeholder="e.g. Subhajit"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Last Name</label>
                <input
                  type="text"
                  required
                  value={regLastName}
                  onChange={(e) => setRegLastName(e.target.value)}
                  placeholder="e.g. Ghosh"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">Email Address</label>
              <input
                type="email"
                required
                value={regEmail}
                onChange={(e) => setRegEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
              />
            </div>

            {/* Mobile Number */}
            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">Mobile Number</label>
              <div className="flex">
                <span className="inline-flex items-center px-2.5 rounded-l-xl border border-r-0 border-slate-200 bg-slate-100 text-slate-700 text-xs font-bold">
                  +91
                </span>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="10-digit mobile number"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-r-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                />
              </div>
            </div>

            {/* Password Grid */}
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Password</label>
                <div className="relative">
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 pr-8"
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPassword(!showRegPassword)}
                    className="absolute right-2 top-2 text-slate-400 hover:text-slate-600"
                  >
                    {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Confirm Password</label>
                <input
                  type={showRegPassword ? 'text' : 'password'}
                  required
                  value={regConfirmPassword}
                  onChange={(e) => setRegConfirmPassword(e.target.value)}
                  placeholder="Repeat password"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                />
              </div>
            </div>

            {/* Terms and Updates Checkboxes */}
            <div className="space-y-1.5 pt-1 text-[11px]">
              <label className="flex items-start space-x-2 text-slate-600 cursor-pointer select-none">
                <input
                  type="checkbox"
                  required
                  checked={agreeTerms}
                  onChange={(e) => setAgreeTerms(e.target.checked)}
                  className="w-4 h-4 text-orange-600 rounded border-slate-300 focus:ring-orange-500 mt-0.5"
                />
                <span>
                  I agree to the <span className="font-bold text-slate-800">Terms & Conditions</span> and <span className="font-bold text-slate-800">Privacy Policy</span>.
                </span>
              </label>

              <label className="flex items-start space-x-2 text-slate-500 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={optInOffers}
                  onChange={(e) => setOptInOffers(e.target.checked)}
                  className="w-4 h-4 text-orange-600 rounded border-slate-300 focus:ring-orange-500 mt-0.5"
                />
                <span>Send me travel offers and beach weekend deals.</span>
              </label>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-sm shadow-lg shadow-orange-500/25 transition-all active:scale-98 flex items-center justify-center space-x-2"
            >
              {isLoading ? <span>{loadingText}</span> : <span>Create Account</span>}
            </button>

            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isLoading}
              className="w-full py-2 px-3 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center space-x-2 transition-all shadow-xs"
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Continue with Google</span>
            </button>

            <div className="pt-1 text-center text-xs text-slate-500">
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setErrorMessage('');
                  setMode('LOGIN');
                }}
                className="text-orange-600 font-bold hover:underline"
              >
                Login
              </button>
            </div>
          </form>
        )}

        {/* ------------------------------------------------------------- */}
        {/* MODE 4: FORGOT PASSWORD */}
        {/* ------------------------------------------------------------- */}
        {mode === 'FORGOT' && (
          <form onSubmit={handleForgotSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Email Address
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={resetEmail}
                  onChange={(e) => setResetEmail(e.target.value)}
                  placeholder="Enter registered email address"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30 pl-9"
                />
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-sm shadow-lg shadow-orange-500/25 transition-all active:scale-98 flex items-center justify-center space-x-2"
            >
              {isLoading ? <span>{loadingText}</span> : <span>Send Reset Link</span>}
            </button>

            <button
              type="button"
              onClick={() => {
                setErrorMessage('');
                setMode('LOGIN');
              }}
              className="w-full text-center text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center justify-center space-x-1"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Back to Login</span>
            </button>
          </form>
        )}

        {/* ------------------------------------------------------------- */}
        {/* MODE 5: FORGOT SUCCESS */}
        {/* ------------------------------------------------------------- */}
        {mode === 'FORGOT_SUCCESS' && (
          <div className="space-y-4 text-center">
            <p className="text-xs text-slate-500">
              Please check your inbox at <span className="font-bold text-slate-800">{resetEmail}</span> for a secure password reset link.
            </p>

            <button
              type="button"
              onClick={() => {
                setErrorMessage('');
                setMode('LOGIN');
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 text-white font-bold text-xs sm:text-sm hover:bg-slate-800 transition-colors shadow-md"
            >
              Back to Login
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
