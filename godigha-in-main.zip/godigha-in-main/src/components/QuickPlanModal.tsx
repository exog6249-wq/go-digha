import React, { useState } from 'react';
import { Send, CheckCircle2, MessageSquare, Compass, Phone } from 'lucide-react';
import { StorageService } from '../services/storage';
import { Enquiry } from '../types';
import { BUSINESS_INFO } from '../data/mockData';

interface QuickPlanModalProps {
  onClose: () => void;
  onSuccess: (enquiry: Enquiry) => void;
}

export const QuickPlanModal: React.FC<QuickPlanModalProps> = ({ onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    destination: 'Digha & Mandarmani',
    travelDates: '',
    travellersCount: 2,
    serviceNeeded: 'Full Holiday Package (Hotel + Cab + Meals)',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) return;

    const newEnq: Enquiry = {
      id: `ENQ-QP-${Date.now().toString().slice(-4)}`,
      name: formData.name,
      phone: formData.phone,
      email: '',
      type: 'CUSTOM_PACKAGE',
      destination: formData.destination,
      travelDates: formData.travelDates || 'Upcoming Weekend',
      travellersCount: formData.travellersCount,
      budgetRange: 'Standard',
      transportRequired: true,
      hotelRequired: true,
      foodRequired: true,
      activitiesRequired: false,
      message: `${formData.serviceNeeded}: ${formData.message}`,
      status: 'NEW',
      createdAt: new Date().toISOString()
    };

    StorageService.saveEnquiry(newEnq);
    setSubmitted(true);
    onSuccess(newEnq);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-sm"
        >
          ✕
        </button>

        {submitted ? (
          <div className="text-center py-6 space-y-3">
            <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-black text-slate-900 font-heading">
              Plan Request Received!
            </h3>
            <p className="text-xs text-slate-600">
              Our Digha travel planner is preparing your customized options and will WhatsApp / call you immediately at <strong>{formData.phone}</strong>.
            </p>
            <div className="pt-3">
              <button
                onClick={onClose}
                className="w-full py-2.5 bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs rounded-xl"
              >
                Close & Continue Exploring
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div>
              <div className="inline-flex items-center space-x-1 text-xs font-bold text-blue-900 uppercase tracking-wider mb-1">
                <Compass className="w-3.5 h-3.5 text-amber-500" />
                <span>GoDigha Quick Trip Planner</span>
              </div>
              <h3 className="text-xl font-black text-slate-900 font-heading">
                Customize Your Trip
              </h3>
              <p className="text-xs text-slate-500">
                Tell us where you want to go. We handle stays, transfers & sightseeing.
              </p>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Your Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Suman Karmakar"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs text-slate-800"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">WhatsApp / Phone *</label>
              <input
                type="tel"
                required
                placeholder="+91 88491 XXXXX"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs text-slate-800"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Destination</label>
                <select
                  value={formData.destination}
                  onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800"
                >
                  <option value="Digha & Mandarmani">Digha & Mandarmani</option>
                  <option value="Darjeeling">Darjeeling</option>
                  <option value="Sikkim & Gangtok">Sikkim & Gangtok</option>
                  <option value="Manali">Manali</option>
                  <option value="Bhutan">Bhutan</option>
                  <option value="Uttarakhand">Uttarakhand</option>
                  <option value="Sundarban">Sundarban</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Travellers Count</label>
                <input
                  type="number"
                  min={1}
                  max={100}
                  value={formData.travellersCount}
                  onChange={(e) => setFormData({ ...formData, travellersCount: parseInt(e.target.value) || 2 })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Service Needed</label>
              <select
                value={formData.serviceNeeded}
                onChange={(e) => setFormData({ ...formData, serviceNeeded: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-800"
              >
                <option value="Full Holiday Package (Hotel + Cab + Meals)">Complete Holiday Package (Stay + Cab + Meals)</option>
                <option value="Hotel / Resort Stay Only">Hotel / Resort Stay Only</option>
                <option value="Transportation / Station Pickup & Drop">Transportation / Station Pickup & Drop</option>
                <option value="Rental Bike (Activa / Royal Enfield)">Rental Bike (Activa / Royal Enfield)</option>
                <option value="Corporate Offsite / Event / Conference">Corporate Offsite / Event / Conference</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs rounded-xl shadow-md flex items-center justify-center space-x-1.5 active:scale-98 transition-all cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Send Trip Planning Request</span>
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
