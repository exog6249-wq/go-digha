import React from 'react';
import {
  HotelIcon3D,
  TransportIcon3D,
  SightseeingIcon3D,
  FoodingIcon3D,
  FoodingCoverIcon3D,
  WaterActivitiesIcon3D,
  RentalBikesIcon3D,
  GroupCorporateIcon3D,
  PartiesCelebrationsIcon3D,
  MeetingsConferenceIcon3D,
  BanquetEventHallsIcon3D,
  DJEntertainmentIcon3D,
  BeveragesIcon3D
} from './ServiceIcons3D';

interface OurServicesGridProps {
  onSelectService: (serviceKey: string) => void;
}

export const OurServicesGrid: React.FC<OurServicesGridProps> = ({ onSelectService }) => {
  const services = [
    {
      id: 'hotels',
      label: 'Hotel Stay & Accommodation',
      icon: HotelIcon3D,
      actionKey: 'hotels'
    },
    {
      id: 'transport',
      label: 'Transportation Pickup & Drop',
      icon: TransportIcon3D,
      actionKey: 'transports'
    },
    {
      id: 'sightseeing',
      label: 'Local Sightseeing',
      icon: SightseeingIcon3D,
      actionKey: 'sightseeing'
    },
    {
      id: 'fooding',
      label: 'Fooding',
      icon: FoodingIcon3D,
      actionKey: 'fooding'
    },
    {
      id: 'fooding_cover',
      label: 'Fooding Cover',
      icon: FoodingCoverIcon3D,
      actionKey: 'catering'
    },
    {
      id: 'water_activities',
      label: 'Water Activities & Experiences',
      icon: WaterActivitiesIcon3D,
      actionKey: 'activities'
    },
    {
      id: 'rental_bikes',
      label: 'Rental Bikes',
      icon: RentalBikesIcon3D,
      actionKey: 'bikes'
    },
    {
      id: 'group_corporate',
      label: 'Group & Corporate Travel',
      icon: GroupCorporateIcon3D,
      actionKey: 'corporate'
    },
    {
      id: 'parties',
      label: 'Parties & Celebrations',
      icon: PartiesCelebrationsIcon3D,
      actionKey: 'parties'
    },
    {
      id: 'conferences',
      label: 'Meetings & Conference',
      icon: MeetingsConferenceIcon3D,
      actionKey: 'conferences'
    },
    {
      id: 'banquets',
      label: 'Banquet / Event Halls',
      icon: BanquetEventHallsIcon3D,
      actionKey: 'banquets'
    },
    {
      id: 'dj_entertainment',
      label: 'DJ & Entertainment',
      icon: DJEntertainmentIcon3D,
      actionKey: 'dj'
    },
    {
      id: 'beverages',
      label: 'Beverages & Arrangements',
      icon: BeveragesIcon3D,
      actionKey: 'beverages'
    }
  ];

  return (
    <section className="py-7 px-3 sm:px-6 bg-pattern-subtle border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto">
        
        {/* Header Pill matching reference */}
        <div className="flex justify-center mb-6">
          <div className="inline-block bg-[#cc7a29] text-white px-6 py-1.5 rounded-full text-xs sm:text-sm font-bold tracking-wider uppercase shadow-sm">
            OUR SERVICES
          </div>
        </div>

        {/* Services Grid (matches the exact icon layout from reference) */}
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 gap-2.5 sm:gap-4">
          {services.map((svc) => {
            const Icon = svc.icon;
            return (
              <button
                key={svc.id}
                onClick={() => onSelectService(svc.actionKey)}
                className="flex flex-col items-center justify-start p-2.5 sm:p-3 rounded-xl border border-slate-200/70 bg-white/90 hover:bg-white transition-all duration-200 hover:-translate-y-1 hover:shadow-md cursor-pointer group text-center shadow-xs"
              >
                {/* Visual Icon Carrier with Upgraded High-Resolution 3D Illustration */}
                <div className="w-13 h-13 sm:w-16 sm:h-16 rounded-full bg-slate-50/70 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform duration-300 p-1">
                  <Icon className="w-11 h-11 sm:w-14 sm:h-14" />
                </div>

                {/* Service Label (Exact names from GoDigha) */}
                <span className="text-[11px] sm:text-xs font-semibold text-slate-800 leading-tight group-hover:text-blue-900 transition-colors line-clamp-2">
                  {svc.label}
                </span>
              </button>
            );
          })}
        </div>

      </div>
    </section>
  );
};
