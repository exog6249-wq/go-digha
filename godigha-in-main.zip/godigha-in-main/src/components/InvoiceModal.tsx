import React from 'react';
import { Booking } from '../types';
import { Printer, Download, CheckCircle2, X, MapPin, Phone, Mail, Building2, ShieldCheck } from 'lucide-react';
import { BUSINESS_INFO } from '../data/mockData';
import { GoDighaLogo } from './GoDighaLogo';

interface InvoiceModalProps {
  booking: Booking;
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({ booking, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  const invoiceNumber = `GD-INV-${booking.id.replace(/[^0-9]/g, '') || '2026-8941'}`;
  const formattedDate = new Date(booking.createdAt).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200 text-slate-800 my-8">
        
        {/* Modal Controls - Hidden during print */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 print:hidden">
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 flex items-center space-x-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Official Tax Invoice</span>
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs flex items-center space-x-1.5 transition-colors shadow-sm"
              title="Print or Save PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Document */}
        <div id="invoice-printable-content" className="pt-4 space-y-6">
          
          {/* Header Row */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-6 border-b border-slate-200">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-full overflow-hidden shadow-md shrink-0">
                <GoDighaLogo className="w-full h-full object-cover" />
              </div>
              <div>
                <h2 className="text-xl font-black text-slate-900 font-heading">
                  GoDigha Travel & Tourism
                </h2>
                <p className="text-xs text-slate-500 font-medium">
                  Official Travel Agency & Tourism Portal
                </p>
                <div className="text-[11px] text-slate-400 mt-1 flex flex-wrap gap-x-2">
                  <span>Old Digha, West Bengal 721428</span>
                  <span>•</span>
                  <span>GSTIN: 19AABCU9603R1ZM</span>
                </div>
              </div>
            </div>

            <div className="text-left sm:text-right">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Invoice Number
              </div>
              <div className="text-base font-black text-slate-900 font-mono">
                {invoiceNumber}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">
                Date: <span className="font-semibold text-slate-700">{formattedDate}</span>
              </div>
            </div>
          </div>

          {/* Billed To & Booking Metadata */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100 text-xs">
            <div>
              <div className="font-bold text-slate-400 uppercase tracking-wider text-[10px] mb-1">
                Billed To (Customer)
              </div>
              <div className="text-sm font-black text-slate-900">
                {booking.customerName}
              </div>
              <div className="text-slate-600 mt-0.5">{booking.customerEmail}</div>
              <div className="text-slate-600">{booking.customerPhone}</div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">Booking ID:</span>
                <span className="font-bold text-slate-800 font-mono">{booking.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment ID:</span>
                <span className="font-bold text-slate-800 font-mono text-[11px]">{booking.paymentId || 'pay_verified_razorpay'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment Status:</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  {booking.paymentStatus}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Booking Status:</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800">
                  {booking.bookingStatus}
                </span>
              </div>
            </div>
          </div>

          {/* Service Details Table */}
          <div className="border border-slate-200 rounded-2xl overflow-hidden text-xs">
            <div className="bg-slate-100/80 px-4 py-2.5 font-bold text-slate-700 grid grid-cols-12 uppercase tracking-wider text-[11px]">
              <span className="col-span-7">Service / Travel Details</span>
              <span className="col-span-2 text-center">Travellers</span>
              <span className="col-span-3 text-right">Amount (₹)</span>
            </div>
            
            <div className="p-4 grid grid-cols-12 items-center border-b border-slate-100">
              <div className="col-span-7 pr-2">
                <div className="font-black text-slate-900 text-sm">{booking.itemTitle}</div>
                {booking.itemSubtitle && (
                  <div className="text-slate-500 text-[11px]">{booking.itemSubtitle}</div>
                )}
                <div className="text-[11px] text-slate-500 mt-1">
                  Dates: <span className="font-medium text-slate-700">{booking.travelDate} {booking.returnDate ? `to ${booking.returnDate}` : ''}</span>
                </div>
              </div>
              <div className="col-span-2 text-center font-bold text-slate-700">
                {booking.travellers} {booking.travellers > 1 ? 'Guests' : 'Guest'}
              </div>
              <div className="col-span-3 text-right font-black text-slate-900 text-sm">
                ₹{booking.baseAmount.toLocaleString('en-IN')}
              </div>
            </div>

            {/* Calculations Breakdown */}
            <div className="p-4 bg-slate-50/50 space-y-2">
              <div className="flex justify-between text-slate-600">
                <span>Base Package / Room Tariff</span>
                <span className="font-semibold">₹{booking.baseAmount.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>GST (18% Tourism / Hospitality)</span>
                <span className="font-semibold">₹{booking.taxAmount.toLocaleString('en-IN')}</span>
              </div>
              {booking.discountAmount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Special Discount Applied</span>
                  <span>-₹{booking.discountAmount.toLocaleString('en-IN')}</span>
                </div>
              )}
              {booking.goCashUsed > 0 && (
                <div className="flex justify-between text-amber-600 font-medium">
                  <span>GoCash Wallet Balance Redeemed</span>
                  <span>-₹{booking.goCashUsed.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="pt-2 border-t border-slate-200 flex justify-between items-center text-sm font-black text-slate-900">
                <span>Total Amount Paid</span>
                <span className="text-base text-orange-600 font-bold">
                  ₹{booking.totalAmount.toLocaleString('en-IN')}
                </span>
              </div>
            </div>
          </div>

          {/* Footer Terms & Verification Note */}
          <div className="pt-2 text-[11px] text-slate-400 space-y-1">
            <div className="flex items-center space-x-1.5 text-emerald-700 font-medium">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Verified Payment via Reserve Bank of India compliant payment gateway.</span>
            </div>
            <p>
              This is a computer-generated tax invoice issued by GoDigha Travel & Tourism Services. For assistance, contact support at 088491 25029 or support@godigha.com.
            </p>
          </div>

        </div>

      </div>
    </div>
  );
};
