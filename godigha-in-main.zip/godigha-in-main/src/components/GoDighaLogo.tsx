import React from 'react';

interface GoDighaLogoProps {
  className?: string;
  size?: number | string;
}

/**
 * Official GoDigha Circular Logo
 * Matching the authentic brand design:
 * - Circular deep navy blue (#041D48) badge
 * - White capital "G"
 * - White location pin marker as "o" with navy cut-out and orange pinpoint ground ring (#FF6E00)
 * - Orange "Digha" in vibrant warm orange (#FF6E00)
 */
export const GoDighaLogo: React.FC<GoDighaLogoProps> = ({
  className = 'w-full h-full',
  size
}) => {
  return (
    <svg
      viewBox="0 0 500 500"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={size ? { width: size, height: size } : undefined}
      aria-label="GoDigha Official Logo"
    >
      {/* Deep Navy Blue Circular Emblem Base */}
      <circle cx="250" cy="250" r="250" fill="#041D48" />

      {/* Brand Artwork Group */}
      <g transform="translate(36, 192)">
        {/* Letter 'G' in Crisp Pure White */}
        <text
          x="0"
          y="82"
          fontFamily="'Outfit', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
          fontSize="112"
          fontWeight="900"
          fill="#FFFFFF"
          letterSpacing="-1px"
        >
          G
        </text>

        {/* Location Pin Marker for 'o' */}
        <g transform="translate(86, -3)">
          {/* Orange Pinpoint Ground Echo Ring */}
          <ellipse
            cx="32"
            cy="104"
            rx="20"
            ry="7"
            fill="none"
            stroke="#FF6E00"
            strokeWidth="5"
          />

          {/* White Map Pin Pointer */}
          <path
            d="M32 98 C28 93 10 70 10 46 C10 25.5 19.8 14 32 14 C44.2 14 54 25.5 54 46 C54 70 36 93 32 98 Z"
            fill="#FFFFFF"
          />

          {/* Pin Center Cutout Hole */}
          <circle cx="32" cy="45" r="13" fill="#041D48" />
        </g>

        {/* Word 'Digha' in Vibrant Brand Orange */}
        <text
          x="154"
          y="82"
          fontFamily="'Outfit', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
          fontSize="112"
          fontWeight="900"
          fill="#FF6E00"
          letterSpacing="-1.5px"
        >
          Digha
        </text>
      </g>
    </svg>
  );
};

export default GoDighaLogo;
