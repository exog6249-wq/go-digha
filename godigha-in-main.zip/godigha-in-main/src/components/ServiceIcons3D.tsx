import React from 'react';

interface Icon3DProps extends React.SVGProps<SVGSVGElement> {
  className?: string;
}

/**
 * 1. Hotel Stay & Accommodation
 * 3D Luxury Coastal Resort Hotel with illuminated balconies, penthouse suite,
 * entrance portico, and decorative tropical palm trees with warm golden sunset glow.
 */
export const HotelIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <filter id="hotel-shadow" x="6" y="70" width="84" height="24" filterUnits="userSpaceOnUse">
        <feGaussianBlur stdDeviation="3.5" />
        <feColorMatrix type="matrix" values="0 0 0 0 0.08  0 0 0 0 0.15  0 0 0 0 0.3  0 0 0 0.28 0" />
      </filter>
      <linearGradient id="hotel-sky" x1="48" y1="6" x2="48" y2="88" gradientUnits="userSpaceOnUse">
        <stop stopColor="#38BDF8" stopOpacity="0.18" />
        <stop offset="1" stopColor="#0284C7" stopOpacity="0" />
      </linearGradient>
      <linearGradient id="hotel-main-front" x1="28" y1="20" x2="68" y2="80" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FFFFFF" />
        <stop offset="0.4" stopColor="#F1F5F9" />
        <stop offset="1" stopColor="#CBD5E1" />
      </linearGradient>
      <linearGradient id="hotel-main-side" x1="18" y1="26" x2="34" y2="80" gradientUnits="userSpaceOnUse">
        <stop stopColor="#94A3B8" />
        <stop offset="1" stopColor="#64748B" />
      </linearGradient>
      <linearGradient id="hotel-accent-gold" x1="24" y1="12" x2="72" y2="40" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FBBF24" />
        <stop offset="0.5" stopColor="#F59E0B" />
        <stop offset="1" stopColor="#D97706" />
      </linearGradient>
      <linearGradient id="hotel-glass-win" x1="0" y1="0" x2="1" y2="1">
        <stop stopColor="#38BDF8" />
        <stop offset="0.6" stopColor="#0284C7" />
        <stop offset="1" stopColor="#0369A1" />
      </linearGradient>
      <linearGradient id="hotel-roof" x1="20" y1="16" x2="76" y2="28" gradientUnits="userSpaceOnUse">
        <stop stopColor="#1E293B" />
        <stop offset="1" stopColor="#0F172A" />
      </linearGradient>
      <linearGradient id="hotel-palm-leaf" x1="72" y1="44" x2="88" y2="76" gradientUnits="userSpaceOnUse">
        <stop stopColor="#34D399" />
        <stop offset="1" stopColor="#059669" />
      </linearGradient>
      <linearGradient id="hotel-palm-trunk" x1="78" y1="60" x2="82" y2="82" gradientUnits="userSpaceOnUse">
        <stop stopColor="#D97706" />
        <stop offset="1" stopColor="#92400E" />
      </linearGradient>
    </defs>

    {/* Ground Soft Ambient Shadow */}
    <ellipse cx="48" cy="80" rx="38" ry="7" fill="url(#hotel-sky)" />
    <ellipse cx="46" cy="81" rx="32" ry="5.5" fill="#0F172A" opacity="0.18" filter="url(#hotel-shadow)" />

    {/* Backdrop Resort Accent / Star Glow */}
    <circle cx="48" cy="48" r="40" fill="url(#hotel-sky)" />

    {/* Tower Base & Isometric Left Wall */}
    <path d="M22 36L34 28V78L22 82V36Z" fill="url(#hotel-main-side)" />

    {/* Tower Main Facade */}
    <path d="M34 28L70 28V78L34 78V28Z" fill="url(#hotel-main-front)" />

    {/* Penthouse / Upper Floor */}
    <path d="M28 22L40 16H64L64 28H34L28 22Z" fill="url(#hotel-roof)" />
    <path d="M40 16L64 16V28H34L40 16Z" fill="#334155" />
    <rect x="42" y="19" width="18" height="6" rx="1.5" fill="url(#hotel-accent-gold)" />

    {/* Hotel Name / Star Crest Signboard */}
    <path d="M40 10L42 14L46 15L43 18L44 22L40 20L36 22L37 18L34 15L38 14L40 10Z" fill="url(#hotel-accent-gold)" />
    <circle cx="49" cy="14" r="2" fill="#FBBF24" />
    <circle cx="55" cy="14" r="2" fill="#FBBF24" />

    {/* Window Grid with Warm Coastal Lighting */}
    {/* Row 1 */}
    <rect x="38" y="32" width="7" height="8" rx="1.5" fill="url(#hotel-glass-win)" />
    <rect x="49" y="32" width="7" height="8" rx="1.5" fill="url(#hotel-accent-gold)" opacity="0.9" />
    <rect x="60" y="32" width="7" height="8" rx="1.5" fill="url(#hotel-glass-win)" />
    {/* Row 2 */}
    <rect x="38" y="44" width="7" height="8" rx="1.5" fill="url(#hotel-accent-gold)" opacity="0.85" />
    <rect x="49" y="44" width="7" height="8" rx="1.5" fill="url(#hotel-glass-win)" />
    <rect x="60" y="44" width="7" height="8" rx="1.5" fill="url(#hotel-glass-win)" />
    {/* Row 3 */}
    <rect x="38" y="56" width="7" height="8" rx="1.5" fill="url(#hotel-glass-win)" />
    <rect x="49" y="56" width="7" height="8" rx="1.5" fill="url(#hotel-glass-win)" />
    <rect x="60" y="56" width="7" height="8" rx="1.5" fill="url(#hotel-accent-gold)" opacity="0.9" />

    {/* Window Highlights / Gloss */}
    <line x1="39" y1="33" x2="44" y2="33" stroke="#BAE6FD" strokeWidth="1" strokeLinecap="round" />
    <line x1="61" y1="33" x2="66" y2="33" stroke="#BAE6FD" strokeWidth="1" strokeLinecap="round" />

    {/* Grand Entrance Canopy / Porch */}
    <path d="M42 68L56 68L60 74L38 74L42 68Z" fill="url(#hotel-accent-gold)" />
    <path d="M44 74H54V80H44V74Z" fill="#1E293B" />
    {/* Glass Door Glow */}
    <rect x="46" y="75" width="6" height="5" rx="0.5" fill="#FEF08A" />
    {/* Red Carpet Entrance */}
    <path d="M46 80L43 83H55L52 80H46Z" fill="#E11D48" />

    {/* Tropical Resort Palm Tree */}
    <path d="M78 81C78 74 81 68 80 58" stroke="url(#hotel-palm-trunk)" strokeWidth="3" strokeLinecap="round" />
    {/* Palm Fronds */}
    <path d="M80 58C84 52 90 53 91 56C87 59 83 60 80 58Z" fill="url(#hotel-palm-leaf)" />
    <path d="M80 58C82 50 85 47 88 47C87 52 84 55 80 58Z" fill="url(#hotel-palm-leaf)" />
    <path d="M80 58C76 50 72 49 71 52C75 54 78 56 80 58Z" fill="url(#hotel-palm-leaf)" />
    <path d="M80 58C73 57 70 61 70 63C74 63 77 61 80 58Z" fill="url(#hotel-palm-leaf)" />

    {/* Sun Glint Specular */}
    <circle cx="36" cy="30" r="1.5" fill="#FFFFFF" opacity="0.9" />
  </svg>
);

/**
 * 2. Transportation Pickup & Drop
 * 3D Sleek Executive Tourist SUV / Cab with metallic reflections, tinted windows,
 * golden journey trail, and road perspective shadow.
 */
export const TransportIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="car-body" x1="16" y1="36" x2="82" y2="72" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FFFFFF" />
        <stop offset="0.25" stopColor="#E2E8F0" />
        <stop offset="0.75" stopColor="#CBD5E1" />
        <stop offset="1" stopColor="#94A3B8" />
      </linearGradient>
      <linearGradient id="car-accent" x1="16" y1="52" x2="82" y2="52" gradientUnits="userSpaceOnUse">
        <stop stopColor="#F59E0B" />
        <stop offset="0.6" stopColor="#D97706" />
        <stop offset="1" stopColor="#B45309" />
      </linearGradient>
      <linearGradient id="car-glass" x1="28" y1="34" x2="68" y2="54" gradientUnits="userSpaceOnUse">
        <stop stopColor="#38BDF8" />
        <stop offset="0.5" stopColor="#0284C7" />
        <stop offset="1" stopColor="#0F172A" />
      </linearGradient>
      <linearGradient id="car-tire" x1="0" y1="0" x2="1" y2="1">
        <stop stopColor="#334155" />
        <stop offset="1" stopColor="#0F172A" />
      </linearGradient>
      <linearGradient id="car-rim" x1="0" y1="0" x2="1" y2="1">
        <stop stopColor="#F1F5F9" />
        <stop offset="1" stopColor="#94A3B8" />
      </linearGradient>
      <linearGradient id="car-headlight" x1="74" y1="54" x2="84" y2="58" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FEF08A" />
        <stop offset="1" stopColor="#F59E0B" />
      </linearGradient>
      <radialGradient id="car-glow" cx="48" cy="48" r="42" gradientUnits="userSpaceOnUse">
        <stop stopColor="#F59E0B" stopOpacity="0.2" />
        <stop offset="1" stopColor="#F59E0B" stopOpacity="0" />
      </radialGradient>
    </defs>

    {/* Ambient Glow */}
    <circle cx="48" cy="50" r="40" fill="url(#car-glow)" />

    {/* Road Surface & Shadow */}
    <ellipse cx="48" cy="76" rx="36" ry="6.5" fill="#0F172A" opacity="0.25" />
    <path d="M12 76C24 73 72 73 84 76" stroke="#E2E8F0" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="5 4" opacity="0.8" />

    {/* Location Pin Marker / Pickup Badge at Top Right */}
    <g transform="translate(62, 10)">
      <path d="M10 0C4.5 0 0 4.5 0 10C0 17 10 26 10 26C10 26 20 17 20 10C20 4.5 15.5 0 10 0Z" fill="url(#car-accent)" />
      <circle cx="10" cy="9" r="4" fill="#FFFFFF" />
      <path d="M10 7L11.5 10H8.5L10 7Z" fill="#D97706" />
    </g>

    {/* SUV Roof Rack / Luggage Carrier */}
    <rect x="28" y="30" width="34" height="3" rx="1.5" fill="#475569" />
    <line x1="34" y1="33" x2="34" y2="36" stroke="#475569" strokeWidth="2" />
    <line x1="56" y1="33" x2="56" y2="36" stroke="#475569" strokeWidth="2" />

    {/* Car Upper Body & Cabin */}
    <path
      d="M23 52L29 36C30 34 32 33 34 33H59C62 33 64 34.5 66 37L73 50C77 52 82 54 82 58V66C82 67.5 80.5 69 79 69H75C75 64 70 60 65 60C60 60 55 64 55 69H37C37 64 32 60 27 60C22 60 17 64 17 69H15C13.5 69 12 67.5 12 66V58C12 55 16 52 23 52Z"
      fill="url(#car-body)"
    />

    {/* Aerodynamic Windshield & Windows */}
    <path d="M31 37H44V50H26L31 37Z" fill="url(#car-glass)" />
    <path d="M47 37H59C60.5 37 62 38 63 39.5L69 50H47V37Z" fill="url(#car-glass)" />
    {/* Windshield Gloss Stripe */}
    <path d="M34 38L42 38L37 49H31L34 38Z" fill="#FFFFFF" opacity="0.35" />
    <path d="M52 38L58 38L53 49H49L52 38Z" fill="#FFFFFF" opacity="0.35" />

    {/* Sleek Side Body Crease & Golden Trim */}
    <path d="M14 55H79C81 55 82 56 82 57V59H12V57C12 56 13 55 14 55Z" fill="url(#car-accent)" />

    {/* Front Headlight (3D Crystal Projector) */}
    <path d="M74 53C76 53 79 54.5 81 57L75 58C73.5 58 72.5 56.5 73 55L74 53Z" fill="url(#car-headlight)" />
    {/* Headlight Beam Cone */}
    <path d="M81 55L94 51V63L81 59Z" fill="#FEF08A" opacity="0.35" />

    {/* Taillight */}
    <rect x="12" y="55" width="3" height="5" rx="1.5" fill="#EF4444" />

    {/* Rear Wheel */}
    <g transform="translate(17, 59)">
      <circle cx="10" cy="10" r="10" fill="url(#car-tire)" />
      <circle cx="10" cy="10" r="6" fill="url(#car-rim)" />
      <circle cx="10" cy="10" r="2.5" fill="#334155" />
      <line x1="10" y1="4" x2="10" y2="16" stroke="#94A3B8" strokeWidth="1.5" />
      <line x1="4" y1="10" x2="16" y2="10" stroke="#94A3B8" strokeWidth="1.5" />
    </g>

    {/* Front Wheel */}
    <g transform="translate(55, 59)">
      <circle cx="10" cy="10" r="10" fill="url(#car-tire)" />
      <circle cx="10" cy="10" r="6" fill="url(#car-rim)" />
      <circle cx="10" cy="10" r="2.5" fill="#334155" />
      <line x1="10" y1="4" x2="10" y2="16" stroke="#94A3B8" strokeWidth="1.5" />
      <line x1="4" y1="10" x2="16" y2="10" stroke="#94A3B8" strokeWidth="1.5" />
    </g>

    {/* Side Mirror */}
    <rect x="42" y="47" width="5" height="3" rx="1.5" fill="#334155" />
  </svg>
);

/**
 * 3. Local Sightseeing
 * 3D Folded Isometric Travel Map with coastal contours, prominent glossy 3D Ruby-Red GPS Pin,
 * and explorer's gold compass dial.
 */
export const SightseeingIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="map-panel-1" x1="14" y1="28" x2="34" y2="78" gradientUnits="userSpaceOnUse">
        <stop stopColor="#F8FAFC" />
        <stop offset="1" stopColor="#E2E8F0" />
      </linearGradient>
      <linearGradient id="map-panel-2" x1="34" y1="22" x2="58" y2="72" gradientUnits="userSpaceOnUse">
        <stop stopColor="#EDE9FE" />
        <stop offset="0.5" stopColor="#E2E8F0" />
        <stop offset="1" stopColor="#CBD5E1" />
      </linearGradient>
      <linearGradient id="map-panel-3" x1="58" y1="28" x2="82" y2="78" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FFFFFF" />
        <stop offset="1" stopColor="#F1F5F9" />
      </linearGradient>
      <linearGradient id="pin-grad" x1="48" y1="10" x2="68" y2="52" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FF4757" />
        <stop offset="0.4" stopColor="#EF4444" />
        <stop offset="1" stopColor="#991B1B" />
      </linearGradient>
      <linearGradient id="sea-coast" x1="16" y1="36" x2="78" y2="70" gradientUnits="userSpaceOnUse">
        <stop stopColor="#38BDF8" />
        <stop offset="1" stopColor="#0284C7" />
      </linearGradient>
      <linearGradient id="compass-gold" x1="18" y1="58" x2="38" y2="78" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FBBF24" />
        <stop offset="1" stopColor="#B45309" />
      </linearGradient>
      <filter id="pin-drop-shadow" x="38" y="44" width="28" height="18" filterUnits="userSpaceOnUse">
        <feGaussianBlur stdDeviation="2.5" />
        <feColorMatrix type="matrix" values="0 0 0 0 0.1  0 0 0 0 0.1  0 0 0 0 0.2  0 0 0 0.35 0" />
      </filter>
    </defs>

    {/* Map Base Shadow */}
    <path d="M12 76L36 84L60 76L84 84V86L60 78L36 86L12 78V76Z" fill="#0F172A" opacity="0.2" />

    {/* 3D Folded Map - Left Leaf */}
    <path d="M14 34L36 26V74L14 82V34Z" fill="url(#map-panel-1)" stroke="#CBD5E1" strokeWidth="0.75" />
    {/* Middle Leaf (Recessed Fold) */}
    <path d="M36 26L60 34V82L36 74V26Z" fill="url(#map-panel-2)" stroke="#94A3B8" strokeWidth="0.75" />
    {/* Right Leaf */}
    <path d="M60 34L82 26V74L60 82V34Z" fill="url(#map-panel-3)" stroke="#CBD5E1" strokeWidth="0.75" />

    {/* Map Roads & Coastline details */}
    <path d="M14 62C22 58 28 66 36 60C44 54 52 64 60 58C68 52 76 60 82 56" stroke="url(#sea-coast)" strokeWidth="3.5" strokeLinecap="round" opacity="0.85" />
    <path d="M20 44C28 48 44 42 54 48C62 52 72 44 80 46" stroke="#F59E0B" strokeWidth="2" strokeDasharray="3 2" strokeLinecap="round" />
    
    {/* Green National Park / Landmark Spot */}
    <circle cx="28" cy="46" r="4" fill="#10B981" opacity="0.8" />
    <circle cx="72" cy="64" r="5" fill="#3B82F6" opacity="0.7" />

    {/* GPS Pin Shadow */}
    <ellipse cx="52" cy="52" rx="9" ry="4" fill="#0F172A" opacity="0.3" filter="url(#pin-drop-shadow)" />

    {/* 3D Glowing Red GPS Pin */}
    <g transform="translate(1, -2)">
      <path
        d="M51 12C41.6 12 34 19.6 34 29C34 40.5 48.5 54 51 56C53.5 54 68 40.5 68 29C68 19.6 60.4 12 51 12Z"
        fill="url(#pin-grad)"
      />
      {/* Pin 3D Specular Highlight Curve */}
      <path
        d="M38 25C39 20 44 15 50 14"
        stroke="#FFFFFF"
        strokeWidth="2.5"
        strokeLinecap="round"
        opacity="0.7"
      />
      {/* Center White Gem */}
      <circle cx="51" cy="28" r="6.5" fill="#FFFFFF" />
      <circle cx="51" cy="28" r="3.5" fill="#DC2626" />
    </g>

    {/* Explorer's Golden Mini Compass (Bottom Left) */}
    <g transform="translate(16, 56)">
      <circle cx="12" cy="12" r="10" fill="#FFFFFF" stroke="url(#compass-gold)" strokeWidth="2" />
      <circle cx="12" cy="12" r="8" fill="#F8FAFC" />
      {/* Compass Needle */}
      <polygon points="12,5 15,12 12,14" fill="#EF4444" />
      <polygon points="12,19 15,12 12,10" fill="#3B82F6" />
      <polygon points="12,5 9,12 12,14" fill="#B91C1C" />
      <polygon points="12,19 9,12 12,10" fill="#1D4ED8" />
      <circle cx="12" cy="12" r="2" fill="#F59E0B" />
    </g>
  </svg>
);

/**
 * 4. Fooding
 * 3D Gourmet Culinary Dish with delicious coastal delicacy, fresh aromatic steaming wisps,
 * fresh basil garnish, and polished stainless steel cutlery.
 */
export const FoodingIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="food-plate-rim" x1="16" y1="24" x2="80" y2="82" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FFFFFF" />
        <stop offset="0.6" stopColor="#E2E8F0" />
        <stop offset="1" stopColor="#CBD5E1" />
      </linearGradient>
      <linearGradient id="food-gold-trim" x1="20" y1="30" x2="76" y2="76" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FBBF24" />
        <stop offset="0.5" stopColor="#F59E0B" />
        <stop offset="1" stopColor="#D97706" />
      </linearGradient>
      <radialGradient id="food-curry" cx="48" cy="56" r="24" gradientUnits="userSpaceOnUse">
        <stop stopColor="#EA580C" />
        <stop offset="0.6" stopColor="#C2410C" />
        <stop offset="1" stopColor="#7C2D12" />
      </radialGradient>
      <linearGradient id="cutlery-steel" x1="0" y1="0" x2="1" y2="1">
        <stop stopColor="#F8FAFC" />
        <stop offset="0.5" stopColor="#CBD5E1" />
        <stop offset="1" stopColor="#64748B" />
      </linearGradient>
    </defs>

    {/* Table Plate Ambient Shadow */}
    <ellipse cx="48" cy="62" rx="36" ry="16" fill="#0F172A" opacity="0.22" />

    {/* Gourmet Ceramic Plate Outer Rim */}
    <ellipse cx="48" cy="58" rx="34" ry="19" fill="url(#food-plate-rim)" />
    {/* Royal Golden Accent Rim */}
    <ellipse cx="48" cy="58" rx="30" ry="16.5" fill="none" stroke="url(#food-gold-trim)" strokeWidth="1.5" />
    {/* Inner Plate Well */}
    <ellipse cx="48" cy="58" rx="25" ry="13.5" fill="#FFFFFF" />

    {/* Rich Coastal Delicacy / Seafood & Rice Curry */}
    <ellipse cx="48" cy="58" rx="20" ry="10" fill="url(#food-curry)" />

    {/* Golden Sautéed Tiger Prawn / Delicacy Piece */}
    <path
      d="M42 54C43 51 47 49 51 51C55 53 56 57 53 60C50 62 45 61 43 58C42 56 42 55 42 54Z"
      fill="#FB923C"
      stroke="#C2410C"
      strokeWidth="1"
    />
    <circle cx="49" cy="53" r="1.5" fill="#FEF08A" />

    {/* Fresh Herb Garnish (Cilantro / Mint leaves) */}
    <path d="M48 52C48 49 52 48 54 50C52 52 50 53 48 52Z" fill="#22C55E" />
    <path d="M47 53C45 50 42 51 43 53C45 54 46 54 47 53Z" fill="#16A34A" />

    {/* Wholesome Aromatic Steam Wisps */}
    <path
      d="M38 42C36 36 40 32 37 26C35 22 37 18 39 16"
      stroke="#F97316"
      strokeWidth="2.5"
      strokeLinecap="round"
      opacity="0.65"
    />
    <path
      d="M48 38C46 32 50 28 47 22C45 18 48 14 50 12"
      stroke="#FB923C"
      strokeWidth="2.5"
      strokeLinecap="round"
      opacity="0.8"
    />
    <path
      d="M58 42C56 36 60 32 58 26C56 22 58 18 60 16"
      stroke="#F97316"
      strokeWidth="2.5"
      strokeLinecap="round"
      opacity="0.65"
    />

    {/* Polished Fork (Left) */}
    <g transform="translate(10, 34)">
      <line x1="8" y1="4" x2="8" y2="40" stroke="url(#cutlery-steel)" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M4 4V14C4 16 12 16 12 14V4" stroke="url(#cutlery-steel)" strokeWidth="2" strokeLinecap="round" />
      <line x1="8" y1="4" x2="8" y2="15" stroke="url(#cutlery-steel)" strokeWidth="1.5" />
    </g>

    {/* Polished Knife / Spoon (Right) */}
    <g transform="translate(74, 34)">
      <line x1="4" y1="16" x2="4" y2="40" stroke="url(#cutlery-steel)" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M4 4C7 6 7 13 4 16C1 13 1 6 4 4Z" fill="url(#cutlery-steel)" />
    </g>
  </svg>
);

/**
 * 5. Fooding Cover
 * 3D Luxury Mirror-Finish Restaurant Cloche / Food Serving Dome with golden crown handle,
 * round serving platter base, and hygiene sparkle glints.
 */
export const FoodingCoverIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="cloche-silver" x1="18" y1="28" x2="78" y2="72" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FFFFFF" />
        <stop offset="0.25" stopColor="#E2E8F0" />
        <stop offset="0.6" stopColor="#94A3B8" />
        <stop offset="1" stopColor="#475569" />
      </linearGradient>
      <linearGradient id="cloche-gold" x1="38" y1="12" x2="58" y2="34" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FDE047" />
        <stop offset="0.4" stopColor="#F59E0B" />
        <stop offset="1" stopColor="#B45309" />
      </linearGradient>
      <linearGradient id="tray-base" x1="12" y1="64" x2="84" y2="76" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FFFFFF" />
        <stop offset="0.5" stopColor="#CBD5E1" />
        <stop offset="1" stopColor="#64748B" />
      </linearGradient>
    </defs>

    {/* Ambient Platter Shadow */}
    <ellipse cx="48" cy="74" rx="38" ry="8" fill="#0F172A" opacity="0.28" />

    {/* Serving Tray Platter Base */}
    <ellipse cx="48" cy="70" rx="36" ry="7" fill="url(#tray-base)" />
    <ellipse cx="48" cy="69" rx="33" ry="5.5" fill="#F1F5F9" />
    <ellipse cx="48" cy="69" rx="31" ry="4.5" fill="none" stroke="url(#cloche-gold)" strokeWidth="1" />

    {/* Cloche Dome Main Structure */}
    <path
      d="M20 66C20 40 32 26 48 26C64 26 76 40 76 66H20Z"
      fill="url(#cloche-silver)"
    />

    {/* 3D Specular Highlight Band (Curved Light Reflection) */}
    <path
      d="M32 64C32 46 38 34 46 30C43 36 41 48 41 64H32Z"
      fill="#FFFFFF"
      opacity="0.55"
    />
    <path
      d="M48 27C58 27 66 36 70 56C68 40 60 32 48 30V27Z"
      fill="#FFFFFF"
      opacity="0.3"
    />

    {/* Golden Bottom Trim on Cloche Rim */}
    <path d="M19 65C19 63.5 21 63 24 63H72C75 63 77 63.5 77 65V67H19V65Z" fill="url(#cloche-gold)" />

    {/* Spherical Golden Crown Handle */}
    <ellipse cx="48" cy="27" rx="6" ry="3" fill="url(#cloche-gold)" />
    <circle cx="48" cy="21" r="5" fill="url(#cloche-gold)" />
    <circle cx="46.5" cy="19.5" r="1.5" fill="#FFFFFF" opacity="0.8" />

    {/* Freshness / Luxury Sparkle Stars */}
    <g transform="translate(68, 22)">
      <path d="M6 0L7.5 4.5L12 6L7.5 7.5L6 12L4.5 7.5L0 6L4.5 4.5L6 0Z" fill="#FBBF24" />
      <circle cx="6" cy="6" r="1.5" fill="#FFFFFF" />
    </g>
    <g transform="translate(18, 30)">
      <path d="M4 0L5 3L8 4L5 5L4 8L3 5L0 4L3 3L4 0Z" fill="#FBBF24" />
    </g>
  </svg>
);

/**
 * 6. Water Activities & Experiences
 * 3D Sporty Jet-Ski Watercraft jumping across dynamic turquoise ocean waves with sea spray,
 * racing windshield, and high-energy beach adventure aesthetic.
 */
export const WaterActivitiesIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="wave-grad-1" x1="10" y1="58" x2="86" y2="86" gradientUnits="userSpaceOnUse">
        <stop stopColor="#06B6D4" />
        <stop offset="0.5" stopColor="#0284C7" />
        <stop offset="1" stopColor="#0369A1" />
      </linearGradient>
      <linearGradient id="wave-grad-2" x1="14" y1="68" x2="82" y2="88" gradientUnits="userSpaceOnUse">
        <stop stopColor="#38BDF8" />
        <stop offset="1" stopColor="#0EA5E9" />
      </linearGradient>
      <linearGradient id="jetski-hull" x1="22" y1="36" x2="74" y2="64" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FF4757" />
        <stop offset="0.5" stopColor="#EF4444" />
        <stop offset="1" stopColor="#B91C1C" />
      </linearGradient>
      <linearGradient id="jetski-deck" x1="30" y1="28" x2="68" y2="52" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FFFFFF" />
        <stop offset="0.6" stopColor="#F1F5F9" />
        <stop offset="1" stopColor="#CBD5E1" />
      </linearGradient>
      <linearGradient id="jetski-seat" x1="32" y1="42" x2="52" y2="48" gradientUnits="userSpaceOnUse">
        <stop stopColor="#1E293B" />
        <stop offset="1" stopColor="#0F172A" />
      </linearGradient>
    </defs>

    {/* Background Sea Crests */}
    <ellipse cx="48" cy="76" rx="36" ry="9" fill="url(#wave-grad-1)" />

    {/* Jet Ski Hull (Angled Upward in Wave Action) */}
    <g transform="rotate(-12 48 50)">
      {/* Lower Hull */}
      <path
        d="M20 54L28 62H68L80 50L72 46H30L20 54Z"
        fill="url(#jetski-hull)"
      />
      {/* Upper Deck */}
      <path
        d="M26 46L32 38H60L74 46H26Z"
        fill="url(#jetski-deck)"
      />
      {/* Racing Stripe */}
      <path d="M30 46H72L69 49H32L30 46Z" fill="#F59E0B" />
      {/* Windshield & Hood */}
      <path d="M52 38L56 31H64L68 38H52Z" fill="#38BDF8" opacity="0.9" />
      {/* Handlebars */}
      <rect x="46" y="27" width="12" height="3" rx="1.5" fill="#1E293B" />
      <circle cx="46" cy="28.5" r="2" fill="#E2E8F0" />
      <circle cx="58" cy="28.5" r="2" fill="#E2E8F0" />
      {/* Cushioned Racing Seat */}
      <rect x="32" y="38" width="18" height="5" rx="2.5" fill="url(#jetski-seat)" />
    </g>

    {/* Front Surging Ocean Wave & Seafoam */}
    <path
      d="M10 74C18 68 28 72 36 67C44 62 52 70 62 65C72 60 80 68 86 64C86 78 78 84 48 84C18 84 10 78 10 74Z"
      fill="url(#wave-grad-2)"
    />

    {/* Sparkling Sea Spray & Splash Droplets */}
    <circle cx="22" cy="56" r="2.5" fill="#BAE6FD" />
    <circle cx="16" cy="62" r="2" fill="#FFFFFF" />
    <circle cx="28" cy="64" r="1.5" fill="#BAE6FD" />
    <circle cx="80" cy="56" r="3" fill="#BAE6FD" />
    <circle cx="86" cy="50" r="2" fill="#FFFFFF" />
    <circle cx="74" cy="52" r="2" fill="#E0F2FE" />
    {/* Dynamic splash streak */}
    <path d="M18 58C24 54 26 50 24 46" stroke="#E0F2FE" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

/**
 * 7. Rental Bikes
 * 3D Modern Stylish Touring Scooter (Activa/Vespa style) in vibrant mint-teal & chrome,
 * with rearview mirrors, headlight, and cushioned seat.
 */
export const RentalBikesIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="scooter-body" x1="20" y1="36" x2="78" y2="70" gradientUnits="userSpaceOnUse">
        <stop stopColor="#14B8A6" />
        <stop offset="0.5" stopColor="#0D9488" />
        <stop offset="1" stopColor="#0F766E" />
      </linearGradient>
      <linearGradient id="scooter-seat" x1="30" y1="40" x2="56" y2="52" gradientUnits="userSpaceOnUse">
        <stop stopColor="#78350F" />
        <stop offset="1" stopColor="#451A03" />
      </linearGradient>
      <linearGradient id="scooter-chrome" x1="0" y1="0" x2="1" y2="1">
        <stop stopColor="#FFFFFF" />
        <stop offset="0.6" stopColor="#CBD5E1" />
        <stop offset="1" stopColor="#94A3B8" />
      </linearGradient>
      <linearGradient id="scooter-wheel" x1="0" y1="0" x2="1" y2="1">
        <stop stopColor="#334155" />
        <stop offset="1" stopColor="#0F172A" />
      </linearGradient>
    </defs>

    {/* Ground Shadow */}
    <ellipse cx="48" cy="78" rx="34" ry="6" fill="#0F172A" opacity="0.25" />

    {/* Rear Wheel */}
    <g transform="translate(18, 56)">
      <circle cx="11" cy="11" r="11" fill="url(#scooter-wheel)" />
      <circle cx="11" cy="11" r="6.5" fill="url(#scooter-chrome)" />
      <circle cx="11" cy="11" r="2.5" fill="#334155" />
    </g>

    {/* Front Wheel */}
    <g transform="translate(60, 56)">
      <circle cx="11" cy="11" r="11" fill="url(#scooter-wheel)" />
      <circle cx="11" cy="11" r="6.5" fill="url(#scooter-chrome)" />
      <circle cx="11" cy="11" r="2.5" fill="#334155" />
    </g>

    {/* Rear Fender & Body Engine Cowl */}
    <path
      d="M20 62C20 50 30 46 42 46H52L48 66H26L20 62Z"
      fill="url(#scooter-body)"
    />

    {/* Center Footboard */}
    <path d="M42 66H62L60 70H40L42 66Z" fill="#334155" />

    {/* Front Apron / Steering Column */}
    <path
      d="M58 40L68 64H62L54 44L58 40Z"
      fill="url(#scooter-body)"
    />
    <path d="M64 42L72 64H68L60 42H64Z" fill="#0F766E" />

    {/* Front Headlight Cowl */}
    <path d="M60 32H72L70 42H62L60 32Z" fill="url(#scooter-body)" />
    {/* Crystal Headlight */}
    <circle cx="70" cy="37" r="4" fill="#FEF08A" stroke="url(#scooter-chrome)" strokeWidth="1.5" />
    <circle cx="69" cy="36" r="1.5" fill="#FFFFFF" />

    {/* Dual Rearview Mirrors */}
    <path d="M62 32L59 23" stroke="url(#scooter-chrome)" strokeWidth="2" strokeLinecap="round" />
    <circle cx="58" cy="22" r="3.5" fill="url(#scooter-chrome)" />
    <circle cx="58" cy="22" r="2" fill="#38BDF8" />

    <path d="M68 32L68 22" stroke="url(#scooter-chrome)" strokeWidth="2" strokeLinecap="round" />
    <circle cx="68" cy="21" r="3.5" fill="url(#scooter-chrome)" />
    <circle cx="68" cy="21" r="2" fill="#38BDF8" />

    {/* Handlebars */}
    <rect x="58" y="30" width="14" height="3" rx="1.5" fill="#1E293B" />

    {/* Premium Tan Cushioned Double Seat */}
    <path
      d="M26 46C26 43 30 41 36 41H50C53 41 55 43 54 46L52 48H28L26 46Z"
      fill="url(#scooter-seat)"
    />
    {/* Seat stitch line */}
    <line x1="38" y1="42" x2="38" y2="47" stroke="#92400E" strokeWidth="1" strokeDasharray="1.5 1" />

    {/* Chrome Exhaust Pipe */}
    <path d="M22 68H38L42 70H22V68Z" fill="url(#scooter-chrome)" />
  </svg>
);

/**
 * 8. Group & Corporate Travel
 * 3D Group of Professional & Leisure Travelers with rolling trolley suitcase, travel backpacks,
 * and collaborative global travel coordination.
 */
export const GroupCorporateIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="traveler-suit-blue" x1="0" y1="0" x2="1" y2="1">
        <stop stopColor="#1E40AF" />
        <stop offset="1" stopColor="#1E3A8A" />
      </linearGradient>
      <linearGradient id="traveler-suit-teal" x1="0" y1="0" x2="1" y2="1">
        <stop stopColor="#0D9488" />
        <stop offset="1" stopColor="#0F766E" />
      </linearGradient>
      <linearGradient id="traveler-suit-amber" x1="0" y1="0" x2="1" y2="1">
        <stop stopColor="#F59E0B" />
        <stop offset="1" stopColor="#D97706" />
      </linearGradient>
      <linearGradient id="suitcase-body" x1="62" y1="52" x2="84" y2="82" gradientUnits="userSpaceOnUse">
        <stop stopColor="#EF4444" />
        <stop offset="0.6" stopColor="#DC2626" />
        <stop offset="1" stopColor="#991B1B" />
      </linearGradient>
      <linearGradient id="skin-tone" x1="0" y1="0" x2="1" y2="1">
        <stop stopColor="#FED7AA" />
        <stop offset="1" stopColor="#FDBA74" />
      </linearGradient>
    </defs>

    {/* Base Ambient Shadow */}
    <ellipse cx="48" cy="80" rx="36" ry="6.5" fill="#0F172A" opacity="0.22" />

    {/* Left Traveler (Corporate / Tech Specialist) */}
    <g transform="translate(14, 22)">
      <circle cx="16" cy="14" r="8" fill="url(#skin-tone)" />
      {/* Hair */}
      <path d="M9 13C9 8 13 6 17 6C22 6 24 9 24 13C20 11 14 11 9 13Z" fill="#1E293B" />
      {/* Torso */}
      <path d="M6 32C6 24 10 22 16 22C22 22 26 24 26 32V52H6V32Z" fill="url(#traveler-suit-teal)" />
      {/* Bag Strap */}
      <line x1="8" y1="23" x2="24" y2="44" stroke="#042F2E" strokeWidth="2.5" />
    </g>

    {/* Right Traveler (Executive Leader) */}
    <g transform="translate(48, 22)">
      <circle cx="18" cy="14" r="8" fill="url(#skin-tone)" />
      {/* Hair */}
      <path d="M11 13C11 8 15 6 19 6C24 6 26 9 26 13C22 11 16 11 11 13Z" fill="#78350F" />
      {/* Torso */}
      <path d="M8 32C8 24 12 22 18 22C24 22 28 24 28 32V52H8V32Z" fill="url(#traveler-suit-amber)" />
    </g>

    {/* Center Lead Traveler (Prominent Foreground) */}
    <g transform="translate(32, 14)">
      <circle cx="16" cy="14" r="9.5" fill="url(#skin-tone)" />
      {/* Hair */}
      <path d="M7 13C7 6 12 4 17 4C23 4 26 7 26 13C21 10 13 10 7 13Z" fill="#0F172A" />
      {/* Corporate Blazer / Travel Jacket */}
      <path d="M4 36C4 26 9 24 16 24C23 24 28 26 28 36V62H4V36Z" fill="url(#traveler-suit-blue)" />
      {/* Shirt Collar & Golden Tie */}
      <polygon points="16,24 19,30 16,42 13,30" fill="#FBBF24" />
      <polygon points="16,24 17,29 15,29" fill="#FFFFFF" />
    </g>

    {/* 3D Rolling Trolley Suitcase (Bottom Right) */}
    <g transform="translate(64, 46)">
      {/* Telescopic Pull Handle */}
      <path d="M7 0V12H15V0" stroke="#64748B" strokeWidth="2" strokeLinecap="round" />
      <rect x="5" y="0" width="12" height="3" rx="1.5" fill="#1E293B" />
      {/* Suitcase Body */}
      <rect x="2" y="12" width="18" height="24" rx="4" fill="url(#suitcase-body)" />
      {/* Ridges on Luggage */}
      <line x1="5" y1="18" x2="17" y2="18" stroke="#FECACA" strokeWidth="1.5" strokeLinecap="round" opacity="0.6" />
      <line x1="5" y1="24" x2="17" y2="24" stroke="#FECACA" strokeWidth="1.5" strokeLinecap="round" opacity="0.6" />
      <line x1="5" y1="30" x2="17" y2="30" stroke="#FECACA" strokeWidth="1.5" strokeLinecap="round" opacity="0.6" />
      {/* Wheels */}
      <circle cx="5" cy="37" r="2" fill="#0F172A" />
      <circle cx="17" cy="37" r="2" fill="#0F172A" />
    </g>
  </svg>
);

/**
 * 9. Parties & Celebrations
 * 3D Metallic Celebration Balloons in rich jewel tones with satin ribbons,
 * exploding festive party poppers, golden stars and confetti ribbons.
 */
export const PartiesCelebrationsIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="balloon-gold" x1="28" y1="12" x2="52" y2="44" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FDE047" />
        <stop offset="0.4" stopColor="#F59E0B" />
        <stop offset="1" stopColor="#B45309" />
      </linearGradient>
      <linearGradient id="balloon-pink" x1="42" y1="16" x2="72" y2="52" gradientUnits="userSpaceOnUse">
        <stop stopColor="#F472B6" />
        <stop offset="0.5" stopColor="#EC4899" />
        <stop offset="1" stopColor="#9D174D" />
      </linearGradient>
      <linearGradient id="balloon-blue" x1="16" y1="26" x2="42" y2="60" gradientUnits="userSpaceOnUse">
        <stop stopColor="#60A5FA" />
        <stop offset="0.5" stopColor="#3B82F6" />
        <stop offset="1" stopColor="#1E3A8A" />
      </linearGradient>
      <linearGradient id="popper-cone" x1="18" y1="62" x2="38" y2="82" gradientUnits="userSpaceOnUse">
        <stop stopColor="#A855F7" />
        <stop offset="1" stopColor="#6B21A8" />
      </linearGradient>
    </defs>

    {/* Ambient Floor Shadow */}
    <ellipse cx="48" cy="84" rx="28" ry="5" fill="#0F172A" opacity="0.18" />

    {/* Balloon Strings */}
    <path d="M40 44C42 54 46 68 48 80" stroke="#CBD5E1" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M58 48C56 58 50 68 48 80" stroke="#CBD5E1" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M28 54C32 62 44 72 48 80" stroke="#CBD5E1" strokeWidth="1.5" strokeLinecap="round" />

    {/* Back Left Balloon (Royal Blue) */}
    <g>
      <ellipse cx="28" cy="40" rx="14" ry="17" fill="url(#balloon-blue)" />
      <polygon points="28,57 26,60 30,60" fill="#1E3A8A" />
      {/* Gloss Highlight */}
      <ellipse cx="24" cy="34" rx="4" ry="7" fill="#FFFFFF" opacity="0.45" transform="rotate(-20 24 34)" />
    </g>

    {/* Back Right Balloon (Ruby Rose) */}
    <g>
      <ellipse cx="58" cy="36" rx="15" ry="18" fill="url(#balloon-pink)" />
      <polygon points="58,54 56,57 60,57" fill="#9D174D" />
      {/* Gloss Highlight */}
      <ellipse cx="54" cy="30" rx="4" ry="8" fill="#FFFFFF" opacity="0.45" transform="rotate(-18 54 30)" />
    </g>

    {/* Center Front Balloon (Gleaming Gold) */}
    <g>
      <ellipse cx="42" cy="28" rx="16" ry="19" fill="url(#balloon-gold)" />
      <polygon points="42,47 40,50 44,50" fill="#B45309" />
      {/* Gloss Highlight */}
      <ellipse cx="37" cy="22" rx="4.5" ry="8" fill="#FFFFFF" opacity="0.6" transform="rotate(-22 37 22)" />
    </g>

    {/* Festive Exploding Party Popper (Bottom Left) */}
    <g transform="translate(14, 52) rotate(-25)">
      <polygon points="12,10 0,32 24,32" fill="url(#popper-cone)" />
      <path d="M0 32C0 30 24 30 24 32Z" fill="#FBBF24" />
      <circle cx="12" cy="24" r="2.5" fill="#FDE047" />
    </g>

    {/* Colorful Confetti, Ribbons & Stars */}
    {/* Golden Stars */}
    <g transform="translate(68, 14)">
      <path d="M5 0L6.5 3.5L10 5L6.5 6.5L5 10L3.5 6.5L0 5L3.5 3.5L5 0Z" fill="#FBBF24" />
    </g>
    <g transform="translate(16, 18)">
      <path d="M4 0L5 3L8 4L5 5L4 8L3 5L0 4L3 3L4 0Z" fill="#F59E0B" />
    </g>
    <g transform="translate(74, 50)">
      <path d="M4 0L5 3L8 4L5 5L4 8L3 5L0 4L3 3L4 0Z" fill="#EC4899" />
    </g>

    {/* Spiral Confetti Streamers */}
    <path d="M68 28C74 30 72 36 78 38C82 40 80 44 84 46" stroke="#EC4899" strokeWidth="2.5" strokeLinecap="round" />
    <path d="M12 40C16 42 14 46 18 48" stroke="#3B82F6" strokeWidth="2" strokeLinecap="round" />
    <circle cx="70" cy="44" r="2" fill="#10B981" />
    <circle cx="20" cy="30" r="1.5" fill="#FBBF24" />
  </svg>
);

/**
 * 10. Meetings & Conference
 * 3D Executive Boardroom Presentation Setup with widescreen presentation analytics display,
 * conference lectern/table with laptop and audio system, and ergonomic chairs.
 */
export const MeetingsConferenceIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="screen-frame" x1="16" y1="14" x2="80" y2="52" gradientUnits="userSpaceOnUse">
        <stop stopColor="#1E293B" />
        <stop offset="1" stopColor="#0F172A" />
      </linearGradient>
      <linearGradient id="screen-display" x1="20" y1="18" x2="76" y2="48" gradientUnits="userSpaceOnUse">
        <stop stopColor="#0284C7" />
        <stop offset="0.6" stopColor="#0369A1" />
        <stop offset="1" stopColor="#075985" />
      </linearGradient>
      <linearGradient id="table-wood" x1="14" y1="62" x2="82" y2="78" gradientUnits="userSpaceOnUse">
        <stop stopColor="#F8FAFC" />
        <stop offset="0.5" stopColor="#E2E8F0" />
        <stop offset="1" stopColor="#CBD5E1" />
      </linearGradient>
      <linearGradient id="chart-gold" x1="0" y1="0" x2="1" y2="0">
        <stop stopColor="#FBBF24" />
        <stop offset="1" stopColor="#F59E0B" />
      </linearGradient>
    </defs>

    {/* Ambient Floor Shadow */}
    <ellipse cx="48" cy="80" rx="36" ry="6" fill="#0F172A" opacity="0.22" />

    {/* Large Presentation Widescreen Display */}
    <rect x="18" y="14" width="60" height="38" rx="4" fill="url(#screen-frame)" />
    <rect x="21" y="17" width="54" height="32" rx="2" fill="url(#screen-display)" />

    {/* Screen Content: Business Growth Chart & Presentation Nodes */}
    <path d="M26 40L36 34L46 38L56 26L68 22" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    <polygon points="68,22 64,25 67,27" fill="#FFFFFF" />
    {/* Bar Charts */}
    <rect x="26" y="42" width="5" height="4" rx="1" fill="url(#chart-gold)" />
    <rect x="36" y="38" width="5" height="8" rx="1" fill="url(#chart-gold)" />
    <rect x="46" y="41" width="5" height="5" rx="1" fill="url(#chart-gold)" />
    <rect x="56" y="32" width="5" height="14" rx="1" fill="url(#chart-gold)" />
    <rect x="66" y="28" width="5" height="18" rx="1" fill="url(#chart-gold)" />

    {/* Display Stand Base */}
    <rect x="46" y="52" width="4" height="8" fill="#475569" />
    <ellipse cx="48" cy="60" rx="12" ry="2.5" fill="#334155" />

    {/* Executive Conference Boardroom Table */}
    <path
      d="M12 66C12 62 26 58 48 58C70 58 84 62 84 66L80 76C80 78 68 81 48 81C28 81 16 78 16 76L12 66Z"
      fill="url(#table-wood)"
    />
    <ellipse cx="48" cy="66" rx="34" ry="7" fill="#F1F5F9" stroke="#CBD5E1" strokeWidth="1" />

    {/* Center Laptop / Podium Screen */}
    <g transform="translate(42, 60)">
      <polygon points="2,8 10,8 11,4 1,4" fill="#38BDF8" />
      <rect x="0" y="8" width="12" height="2" rx="0.5" fill="#334155" />
    </g>

    {/* Conference Microphones */}
    <g transform="translate(26, 61)">
      <path d="M4 8C4 5 7 4 8 2" stroke="#475569" strokeWidth="1.5" strokeLinecap="round" />
      <circle cx="8" cy="2" r="1.5" fill="#EF4444" />
    </g>
    <g transform="translate(62, 61)">
      <path d="M4 8C4 5 1 4 0 2" stroke="#475569" strokeWidth="1.5" strokeLinecap="round" />
      <circle cx="0" cy="2" r="1.5" fill="#10B981" />
    </g>
  </svg>
);

/**
 * 11. Banquet / Event Halls
 * 3D Grand Luxurious Banquet & Ballroom Architecture with arched colonnade, draped royal curtains,
 * and opulent sparkling crystal chandelier casting ambient warm light.
 */
export const BanquetEventHallsIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="banquet-arch" x1="14" y1="12" x2="82" y2="82" gradientUnits="userSpaceOnUse">
        <stop stopColor="#F8FAFC" />
        <stop offset="0.5" stopColor="#E2E8F0" />
        <stop offset="1" stopColor="#94A3B8" />
      </linearGradient>
      <linearGradient id="banquet-drape" x1="16" y1="16" x2="80" y2="60" gradientUnits="userSpaceOnUse">
        <stop stopColor="#881337" />
        <stop offset="0.6" stopColor="#9F1239" />
        <stop offset="1" stopColor="#E11D48" />
      </linearGradient>
      <linearGradient id="chandelier-gold" x1="36" y1="20" x2="60" y2="52" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FEF08A" />
        <stop offset="0.5" stopColor="#F59E0B" />
        <stop offset="1" stopColor="#B45309" />
      </linearGradient>
      <radialGradient id="banquet-glow" cx="48" cy="42" r="28" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FEF08A" stopOpacity="0.45" />
        <stop offset="1" stopColor="#FEF08A" stopOpacity="0" />
      </radialGradient>
    </defs>

    {/* Ambient Floor Shadow */}
    <ellipse cx="48" cy="80" rx="36" ry="6" fill="#0F172A" opacity="0.25" />

    {/* Grand Ballroom Ceiling Arch */}
    <path
      d="M16 80V38C16 22 30 12 48 12C66 12 80 22 80 38V80H72V38C72 26 62 18 48 18C34 18 24 26 24 38V80H16Z"
      fill="url(#banquet-arch)"
    />

    {/* Royal Draped Velvet Curtains */}
    {/* Left Swag */}
    <path
      d="M20 18C30 20 38 28 38 38L24 46C22 36 20 28 20 18Z"
      fill="url(#banquet-drape)"
    />
    {/* Right Swag */}
    <path
      d="M76 18C66 20 58 28 58 38L72 46C74 36 76 28 76 18Z"
      fill="url(#banquet-drape)"
    />
    {/* Top Pelmet Valance */}
    <path
      d="M22 18C34 26 44 26 48 20C52 26 62 26 74 18C66 14 56 14 48 14C40 14 30 14 22 18Z"
      fill="#BE123C"
    />

    {/* Warm Chandelier Glow Aura */}
    <circle cx="48" cy="42" r="24" fill="url(#banquet-glow)" />

    {/* Hanging Chain & Multi-Tier Crystal Chandelier */}
    <line x1="48" y1="14" x2="48" y2="28" stroke="url(#chandelier-gold)" strokeWidth="2" />

    {/* Top Chandelier Tier */}
    <ellipse cx="48" cy="29" rx="10" ry="3" fill="url(#chandelier-gold)" />
    <line x1="40" y1="30" x2="42" y2="38" stroke="#FDE047" strokeWidth="1.5" />
    <line x1="48" y1="30" x2="48" y2="40" stroke="#FDE047" strokeWidth="1.5" />
    <line x1="56" y1="30" x2="54" y2="38" stroke="#FDE047" strokeWidth="1.5" />

    {/* Middle Chandelier Tier */}
    <ellipse cx="48" cy="40" rx="16" ry="4.5" fill="url(#chandelier-gold)" />
    {/* Crystal Pendants */}
    <polygon points="36,44 38,50 34,50" fill="#FEF08A" />
    <polygon points="42,44 44,52 40,52" fill="#FFFFFF" />
    <polygon points="48,44 50,54 46,54" fill="#FEF08A" />
    <polygon points="54,44 56,52 52,52" fill="#FFFFFF" />
    <polygon points="60,44 62,50 58,50" fill="#FEF08A" />

    {/* Center Bottom Crystal Tear */}
    <circle cx="48" cy="56" r="2.5" fill="#FFFFFF" />

    {/* Decorated Round Banquet Table with Floral Centerpiece (Bottom) */}
    <g transform="translate(28, 64)">
      <ellipse cx="20" cy="12" rx="18" ry="5.5" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="1" />
      <path d="M6 14C6 18 10 22 20 22C30 22 34 18 34 14" fill="#F8FAFC" />
      {/* Golden Floral Centerpiece */}
      <circle cx="20" cy="9" r="3.5" fill="#F59E0B" />
      <circle cx="18" cy="8" r="2" fill="#E11D48" />
      <circle cx="22" cy="8" r="2" fill="#E11D48" />
    </g>
  </svg>
);

/**
 * 12. DJ & Entertainment
 * 3D High-Energy DJ Turntable Console with vinyl records, glowing mixer sliders,
 * studio headphones draped diagonally, and dynamic soundwaves.
 */
export const DJEntertainmentIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="dj-deck-grad" x1="12" y1="46" x2="84" y2="78" gradientUnits="userSpaceOnUse">
        <stop stopColor="#334155" />
        <stop offset="0.5" stopColor="#1E293B" />
        <stop offset="1" stopColor="#0F172A" />
      </linearGradient>
      <linearGradient id="vinyl-groove" x1="0" y1="0" x2="1" y2="1">
        <stop stopColor="#18181B" />
        <stop offset="0.5" stopColor="#27272A" />
        <stop offset="1" stopColor="#09090B" />
      </linearGradient>
      <linearGradient id="headphones-red" x1="16" y1="12" x2="80" y2="48" gradientUnits="userSpaceOnUse">
        <stop stopColor="#EF4444" />
        <stop offset="0.5" stopColor="#DC2626" />
        <stop offset="1" stopColor="#991B1B" />
      </linearGradient>
      <linearGradient id="eq-neon" x1="0" y1="0" x2="0" y2="1">
        <stop stopColor="#38BDF8" />
        <stop offset="0.5" stopColor="#818CF8" />
        <stop offset="1" stopColor="#C084FC" />
      </linearGradient>
    </defs>

    {/* Ambient Shadow */}
    <ellipse cx="48" cy="80" rx="36" ry="6.5" fill="#0F172A" opacity="0.3" />

    {/* DJ Mixer Console Base */}
    <rect x="12" y="48" width="72" height="28" rx="4" fill="url(#dj-deck-grad)" stroke="#475569" strokeWidth="1" />

    {/* Left Vinyl Turntable Platter */}
    <g transform="translate(16, 52)">
      <circle cx="13" cy="11" r="10" fill="url(#vinyl-groove)" />
      <circle cx="13" cy="11" r="7.5" stroke="#3F3F46" strokeWidth="0.75" />
      <circle cx="13" cy="11" r="4.5" fill="#EF4444" />
      <circle cx="13" cy="11" r="1.5" fill="#FFFFFF" />
      {/* Vinyl reflection shine */}
      <path d="M7 8C9 6 13 6 16 8" stroke="#FFFFFF" strokeWidth="1" strokeLinecap="round" opacity="0.4" />
    </g>

    {/* Right Vinyl Turntable Platter */}
    <g transform="translate(54, 52)">
      <circle cx="13" cy="11" r="10" fill="url(#vinyl-groove)" />
      <circle cx="13" cy="11" r="7.5" stroke="#3F3F46" strokeWidth="0.75" />
      <circle cx="13" cy="11" r="4.5" fill="#3B82F6" />
      <circle cx="13" cy="11" r="1.5" fill="#FFFFFF" />
      {/* Vinyl reflection shine */}
      <path d="M7 8C9 6 13 6 16 8" stroke="#FFFFFF" strokeWidth="1" strokeLinecap="round" opacity="0.4" />
    </g>

    {/* Center Audio Mixer & Crossfaders */}
    <g transform="translate(42, 52)">
      <rect x="0" y="0" width="12" height="20" rx="2" fill="#0F172A" />
      {/* LED Equalizer lights */}
      <circle cx="4" cy="4" r="1" fill="#22C55E" />
      <circle cx="4" cy="7" r="1" fill="#22C55E" />
      <circle cx="4" cy="10" r="1" fill="#EAB308" />
      <circle cx="4" cy="13" r="1" fill="#EF4444" />

      <circle cx="8" cy="4" r="1" fill="#22C55E" />
      <circle cx="8" cy="7" r="1" fill="#22C55E" />
      <circle cx="8" cy="10" r="1" fill="#EAB308" />
      <circle cx="8" cy="13" r="1" fill="#EF4444" />

      {/* Crossfader horizontal track */}
      <line x1="2" y1="17" x2="10" y2="17" stroke="#334155" strokeWidth="1.5" />
      <rect x="5" y="16" width="3" height="2" rx="0.5" fill="#FFFFFF" />
    </g>

    {/* Professional DJ Studio Headphones Draped Overhead */}
    <path
      d="M26 44C26 22 36 14 48 14C60 14 70 22 70 44"
      stroke="url(#headphones-red)"
      strokeWidth="5"
      strokeLinecap="round"
    />
    <path
      d="M32 20C38 17 44 16 48 16C52 16 58 17 64 20"
      stroke="#1E293B"
      strokeWidth="2.5"
      strokeLinecap="round"
    />

    {/* Left Cushioned Ear Cup */}
    <g transform="translate(20, 36)">
      <ellipse cx="6" cy="10" rx="6" ry="9" fill="#1E293B" stroke="url(#headphones-red)" strokeWidth="2" />
      <ellipse cx="6" cy="10" rx="3.5" ry="6" fill="#0F172A" />
    </g>

    {/* Right Cushioned Ear Cup */}
    <g transform="translate(64, 36)">
      <ellipse cx="6" cy="10" rx="6" ry="9" fill="#1E293B" stroke="url(#headphones-red)" strokeWidth="2" />
      <ellipse cx="6" cy="10" rx="3.5" ry="6" fill="#0F172A" />
    </g>

    {/* Dynamic Neon Soundwaves & Music Notes */}
    <path d="M12 36C10 32 8 30 10 26" stroke="url(#eq-neon)" strokeWidth="2" strokeLinecap="round" />
    <path d="M84 36C86 32 88 30 86 26" stroke="url(#eq-neon)" strokeWidth="2" strokeLinecap="round" />
    {/* Floating Musical Note */}
    <g transform="translate(74, 12)">
      <circle cx="3" cy="8" r="2.5" fill="#C084FC" />
      <line x1="5.5" y1="8" x2="5.5" y2="2" stroke="#C084FC" strokeWidth="1.5" />
      <path d="M5.5 2C8 2 9 4 11 4" stroke="#C084FC" strokeWidth="1.5" strokeLinecap="round" />
    </g>
  </svg>
);

/**
 * 13. Beverages & Arrangements
 * 3D Premium Tropical Cocktail in hurricane/martini glass with sunset gradient drink,
 * striped paper straw, lime garnish, and chilled champagne bottle in ice bucket.
 */
export const BeveragesIcon3D: React.FC<Icon3DProps> = ({ className = 'w-full h-full', ...props }) => (
  <svg
    viewBox="0 0 96 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    {...props}
  >
    <defs>
      <linearGradient id="cocktail-drink" x1="28" y1="36" x2="54" y2="62" gradientUnits="userSpaceOnUse">
        <stop stopColor="#F97316" />
        <stop offset="0.4" stopColor="#F59E0B" />
        <stop offset="0.8" stopColor="#06B6D4" />
        <stop offset="1" stopColor="#0284C7" />
      </linearGradient>
      <linearGradient id="glass-specular" x1="0" y1="0" x2="1" y2="1">
        <stop stopColor="#FFFFFF" stopOpacity="0.8" />
        <stop offset="1" stopColor="#FFFFFF" stopOpacity="0.1" />
      </linearGradient>
      <linearGradient id="bottle-champagne" x1="62" y1="20" x2="80" y2="70" gradientUnits="userSpaceOnUse">
        <stop stopColor="#065F46" />
        <stop offset="0.6" stopColor="#047857" />
        <stop offset="1" stopColor="#064E3B" />
      </linearGradient>
      <linearGradient id="bottle-gold-foil" x1="66" y1="18" x2="74" y2="34" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FDE047" />
        <stop offset="0.5" stopColor="#F59E0B" />
        <stop offset="1" stopColor="#B45309" />
      </linearGradient>
      <linearGradient id="ice-bucket-metal" x1="56" y1="50" x2="86" y2="80" gradientUnits="userSpaceOnUse">
        <stop stopColor="#FFFFFF" />
        <stop offset="0.5" stopColor="#E2E8F0" />
        <stop offset="1" stopColor="#94A3B8" />
      </linearGradient>
    </defs>

    {/* Ambient Ground Shadow */}
    <ellipse cx="48" cy="80" rx="36" ry="6" fill="#0F172A" opacity="0.25" />

    {/* Chilled Champagne Bottle in Ice Bucket (Right Side) */}
    <g>
      {/* Bottle Upper Neck & Gold Foil */}
      <path d="M68 20H74L76 34L66 34L68 20Z" fill="url(#bottle-gold-foil)" />
      <rect x="69" y="16" width="4" height="4" rx="1" fill="#B45309" />
      {/* Bottle Shoulder & Body */}
      <path d="M66 34L62 48V62H79V48L76 34H66Z" fill="url(#bottle-champagne)" />
      <rect x="64" y="44" width="13" height="10" rx="1.5" fill="#FEF08A" />

      {/* Ice Cooler Bucket */}
      <path
        d="M58 54L62 76H80L84 54H58Z"
        fill="url(#ice-bucket-metal)"
      />
      <ellipse cx="71" cy="54" rx="13" ry="3.5" fill="#CBD5E1" />
      {/* Floating Ice Cubes */}
      <rect x="62" y="50" width="5" height="5" rx="1" fill="#FFFFFF" opacity="0.8" transform="rotate(12 62 50)" />
      <rect x="74" y="49" width="5" height="5" rx="1" fill="#E0F2FE" opacity="0.9" transform="rotate(-15 74 49)" />
      {/* Bucket handles */}
      <circle cx="58" cy="59" r="2.5" fill="#64748B" />
      <circle cx="84" cy="59" r="2.5" fill="#64748B" />
    </g>

    {/* Tropical Cocktail Hurricane Glass (Left / Front Foreground) */}
    <g transform="translate(4, 0)">
      {/* Stem & Base */}
      <ellipse cx="36" cy="76" rx="11" ry="3" fill="#E2E8F0" />
      <line x1="36" y1="58" x2="36" y2="76" stroke="#CBD5E1" strokeWidth="3" />

      {/* Glass Bowl with Drink */}
      <path
        d="M22 34C22 48 30 58 36 58C42 58 50 48 50 34H22Z"
        fill="url(#cocktail-drink)"
      />

      {/* Glass Top Rim & Specular Highlights */}
      <ellipse cx="36" cy="34" rx="14" ry="4" fill="#E0F2FE" opacity="0.7" />
      <path
        d="M24 36C24 48 30 55 35 56C30 53 26 44 26 36H24Z"
        fill="url(#glass-specular)"
      />

      {/* Striped Paper Straw */}
      <g>
        <path d="M38 48L48 18" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" />
        <path d="M39 44L41 38" stroke="#EF4444" strokeWidth="3" />
        <path d="M43 32L45 26" stroke="#EF4444" strokeWidth="3" />
      </g>

      {/* Fresh Lime Wheel Garnish on Rim */}
      <g transform="translate(18, 26)">
        <circle cx="6" cy="6" r="6" fill="#84CC16" />
        <circle cx="6" cy="6" r="4.5" fill="#BEF264" />
        <circle cx="6" cy="6" r="1.5" fill="#FFFFFF" />
        <line x1="6" y1="1.5" x2="6" y2="10.5" stroke="#84CC16" strokeWidth="0.75" />
        <line x1="1.5" y1="6" x2="10.5" y2="6" stroke="#84CC16" strokeWidth="0.75" />
      </g>

      {/* Cocktail Paper Umbrella */}
      <g transform="translate(40, 18) rotate(24)">
        <path d="M0 12L12 0L24 12C18 10 6 10 0 12Z" fill="#F43F5E" />
        <line x1="12" y1="0" x2="12" y2="18" stroke="#D97706" strokeWidth="1.5" />
      </g>
    </g>
  </svg>
);
