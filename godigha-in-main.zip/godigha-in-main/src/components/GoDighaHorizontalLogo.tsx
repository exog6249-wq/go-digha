import React from 'react';

interface GoDighaHorizontalLogoProps {
  className?: string;
  height?: number | string;
}

export const GoDighaHorizontalLogo: React.FC<GoDighaHorizontalLogoProps> = ({
  className = 'h-8 sm:h-9 md:h-10 w-auto',
  height
}) => {
  return (
    <svg
      viewBox="0 0 460 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={height ? { height } : undefined}
      aria-label="GoDigha Official Brand Logo"
    >
      {/* Letter 'G' in Pure White */}
      <text
        x="2"
        y="88"
        fontFamily="'Outfit', 'Montserrat', 'Inter', -apple-system, sans-serif"
        fontSize="102"
        fontWeight="900"
        fill="#FFFFFF"
        letterSpacing="-1.5px"
      >
        G
      </text>

      {/* Stylized Location Pin for 'o' */}
      <g transform="translate(80, 2)">
        {/* Orange Base Ellipse / Ground Anchor */}
        <ellipse cx="30" cy="100" rx="22" ry="7.5" fill="#FF7A00" />

        {/* White Map Pin Body */}
        <path
          d="M30 94 C26 88 8 64 8 42 C8 20 18 8 30 8 C42 8 52 20 52 42 C52 64 34 88 30 94 Z"
          fill="#FFFFFF"
        />

        {/* Center Cutout */}
        <circle cx="30" cy="38" r="11" fill="#061527" />
      </g>

      {/* Word 'Digha' in Vibrant Brand Orange */}
      <text
        x="146"
        y="88"
        fontFamily="'Outfit', 'Montserrat', 'Inter', -apple-system, sans-serif"
        fontSize="102"
        fontWeight="900"
        fill="#FF7A00"
        letterSpacing="-2px"
      >
        Digha
      </text>
    </svg>
  );
};

export default GoDighaHorizontalLogo;
