import React, { useState } from 'react';
import { EventService, Enquiry } from '../types';
import { StorageService } from '../services/storage';
import {
  Users,
  Presentation,
  PartyPopper,
  Building2,
  Headphones,
  CheckCircle2,
  Send,
  Sparkles,
  Phone,
  MessageSquare
} from 'lucide-react';
import { BUSINESS_INFO } from '../data/mockData';

interface CorporateEventsSectionProps {
  events: EventService[];
  onEnquirySubmitted: (enquiry: Enquiry) => void;
}

export const CorporateEventsSection: React.FC<CorporateEventsSectionProps> = ({
  events,
  onEnquirySubmitted
}) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    destination: 'Mandarmani Beachfront',
    travelDates: '',
    travellersCount: 30,
    budgetRange: '₹1,50,000 - ₹3,00,000',
    transportRequired: true,
    hotelRequired: true,
    foodRequired: true,
    activitiesRequired: true,
    message: ''
  });

  const [submittedEnquiryId, setSubmittedEnquiryId] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) return;

    const newEnquiry: Enquiry = {
      id: `ENQ-GD-${Date.now().toString().slice(-4)}`,
      name: formData.name,
      phone: formData.phone,
      email: formData.email,
      type: 'CORPORATE',
      destination: formData.destination,
      travelDates: formData.travelDates || 'Dates Flexible',
      travellersCount: Number(formData.travellersCount),
      budgetRange: formData.budgetRange,
      transportRequired: formData.transportRequired,
      hotelRequired: formData.hotelRequired,
      foodRequired: formData.foodRequired,
      activitiesRequired: formData.activitiesRequired,
      message: formData.message,
      status: 'NEW',
      createdAt: new Date().toISOString()
    };

    StorageService.saveEnquiry(newEnquiry);
    setSubmittedEnquiryId(newEnquiry.id);
    onEnquirySubmitted(newEnquiry);
  };

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-blue-100 text-blue-900 text-xs font-bold uppercase tracking-wider mb-2">
            <Users className="w-3.5 h-3.5" />
            <span>MICE & Group Travel Division</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 font-heading">
            Group Tours, Corporate Offsites & Event Services
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            GoDigha organizes end-to-end corporate conferences, college excursions, weddings, beach parties, banquet halls, DJ systems, and gourmet seafood catering in Digha & Mandarmani.
          </p>
        </div>

        {/* 2-Column: Event Services Showcase (Left) + Enquiry Form (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Event Services Cards (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 mb-3 flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <span>Full-Spectrum Travel & Event Arrangements</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {events.map((evt) => (
                <div
                  key={evt.id}
                  className="bg-slate-50 rounded-2xl p-4 border border-slate-200 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="relative aspect-16/10 rounded-xl overflow-hidden mb-3 bg-slate-200">
                      <img
                        src={evt.image}
                        alt={evt.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                      {evt.capacity && (
                        <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-xs text-white text-[10px] px-2 py-0.5 rounded font-medium">
                          {evt.capacity}
                        </div>
                      )}
                    </div>

                    <h4 className="font-bold text-slate-900 text-sm">{evt.name}</h4>
                    <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">
                      {evt.description}
                    </p>

                    <ul className="mt-2.5 space-y-1 text-[11px] text-slate-600">
                      {evt.features.slice(0, 2).map((feat, i) => (
                        <li key={i} className="flex items-center space-x-1.5 truncate">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                          <span className="truncate">{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-slate-200/80 flex items-center justify-between text-xs">
                    <span className="text-slate-500 font-medium">Arrangements from</span>
                    <span className="font-black text-slate-900">₹{evt.startingPrice}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Direct Assistance Card */}
            <div className="bg-[#0f2847] text-white p-5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 mt-6">
              <div>
                <h4 className="font-bold text-base text-amber-300">Need Immediate Custom Quote?</h4>
                <p className="text-xs text-slate-300 mt-0.5">
                  Directly consult our MICE manager on WhatsApp or phone for instant venue availability.
                </p>
              </div>
              <a
                href={BUSINESS_INFO.whatsappDirectLink}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs flex items-center space-x-1.5 shrink-0 transition-transform active:scale-95 shadow-md"
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp Coordinator</span>
              </a>
            </div>
          </div>

          {/* Right Column: Group & Corporate Enquiry Form (5 cols) */}
          <div className="lg:col-span-5 bg-slate-50 rounded-2xl p-6 border border-slate-200 shadow-lg">
            
            {submittedEnquiryId ? (
              <div className="text-center py-10 animate-in fade-in zoom-in-95 duration-200">
                <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 font-heading">
                  Enquiry Submitted Successfully!
                </h3>
                <p className="text-xs text-slate-600 mt-2">
                  Reference ID: <strong className="text-blue-900">{submittedEnquiryId}</strong>
                </p>
                <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                  Our GoDigha tour planning team has received your corporate/group specifications. We will call you within 30 minutes with a detailed itinerary & rate card.
                </p>
                <button
                  onClick={() => setSubmittedEnquiryId(null)}
                  className="mt-6 px-4 py-2 bg-[#0f2847] text-amber-300 font-bold text-xs rounded-lg hover:bg-blue-900"
                >
                  Submit Another Enquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-3.5">
                <div>
                  <h3 className="text-lg font-bold text-slate-900 font-heading">
                    Request Group or Corporate Quote
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Fast response with guaranteed transparent corporate pricing.
                  </p>
                </div>

                {/* Name */}
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Contact Person / Organization Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Rahul Sen / Tech Mahindra"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                {/* Phone & Email */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+91 98300 XXXXX"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      placeholder="contact@company.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Destination & Dates */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Destination
                    </label>
                    <select
                      value={formData.destination}
                      onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    >
                      <option value="Digha Sea Beach">Digha Sea Beach</option>
                      <option value="Mandarmani Beachfront">Mandarmani Beachfront</option>
                      <option value="Darjeeling & Gangtok">Darjeeling & Gangtok</option>
                      <option value="Sundarban Delta">Sundarban Delta</option>
                      <option value="Uttarakhand">Uttarakhand</option>
                      <option value="Custom Location">Custom Location</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Approx Travel Dates
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 15-18 Nov 2026"
                      value={formData.travelDates}
                      onChange={(e) => setFormData({ ...formData, travelDates: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Travellers count & Budget */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Travellers Count
                    </label>
                    <input
                      type="number"
                      min={5}
                      max={1000}
                      value={formData.travellersCount}
                      onChange={(e) => setFormData({ ...formData, travellersCount: parseInt(e.target.value) || 10 })}
                      className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Estimated Budget
                    </label>
                    <select
                      value={formData.budgetRange}
                      onChange={(e) => setFormData({ ...formData, budgetRange: e.target.value })}
                      className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    >
                      <option value="Under ₹1,00,000">Under ₹1,00,000</option>
                      <option value="₹1,50,000 - ₹3,00,000">₹1,50,000 - ₹3,00,000</option>
                      <option value="₹3,00,000 - ₹5,00,000">₹3,00,000 - ₹5,00,000</option>
                      <option value="₹5,00,000+">₹5,00,000+</option>
                    </select>
                  </div>
                </div>

                {/* Service checkboxes */}
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1.5">
                    Required Arrangements:
                  </label>
                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-700">
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={formData.transportRequired}
                        onChange={(e) => setFormData({ ...formData, transportRequired: e.target.checked })}
                        className="rounded text-blue-900"
                      />
                      <span>Transport / Bus</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={formData.hotelRequired}
                        onChange={(e) => setFormData({ ...formData, hotelRequired: e.target.checked })}
                        className="rounded text-blue-900"
                      />
                      <span>Resort / Hotel Stays</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={formData.foodRequired}
                        onChange={(e) => setFormData({ ...formData, foodRequired: e.target.checked })}
                        className="rounded text-blue-900"
                      />
                      <span>Fooding & Buffets</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={formData.activitiesRequired}
                        onChange={(e) => setFormData({ ...formData, activitiesRequired: e.target.checked })}
                        className="rounded text-blue-900"
                      />
                      <span>DJ & Activities</span>
                    </label>
                  </div>
                </div>

                {/* Message */}
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Special Requirements
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Specific requests, dietary preferences, conference hall projector needs..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-xl bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs sm:text-sm flex items-center justify-center space-x-2 shadow-md transition-all active:scale-98 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Enquiry to GoDigha</span>
                </button>
              </form>
            )}

          </div>

        </div>

      </div>
    </section>
  );
};
