import React, { useState } from 'react';
import { TransportService } from '../types';
import { Car, Users, Luggage, Check, ShieldCheck, ArrowRight } from 'lucide-react';
import { BUSINESS_INFO } from '../data/mockData';

interface TransportationSectionProps {
  transports: TransportService[];
  onBookTransport: (transport: TransportService) => void;
}

export const TransportationSection: React.FC<TransportationSectionProps> = ({
  transports,
  onBookTransport
}) => {
  const [filterType, setFilterType] = useState<string>('ALL');

  const categories = [
    { id: 'ALL', label: 'All Fleets' },
    { id: 'RAILWAY_TRANSFER', label: 'Station Pickup / Drop' },
    { id: 'LOCAL_SIGHTSEEING', label: 'Local Sightseeing Cabs' },
    { id: 'OUTSTATION', label: 'Outstation / Kolkata' }
  ];

  const filtered = transports.filter((t) => {
    if (filterType === 'ALL') return true;
    return t.serviceType === filterType;
  });

  return (
    <section className="py-10 px-4 sm:px-6 lg:px-8 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-amber-600 mb-1">
              GoDigha Mobility & Fleet
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading">
              Transportation, Station Pickup & Cabs
            </h2>
            <p className="text-sm text-slate-600 mt-1 max-w-xl">
              Clean, sanitized AC Sedans, Innova Crystas & 17-Seater Tempo Travellers with polite, local mountain & coastal chauffeurs.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setFilterType(cat.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
                  filterType === cat.id
                    ? 'bg-[#0f2847] text-white shadow-sm'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Transport Fleet Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="bg-slate-50 rounded-2xl p-5 border border-slate-200 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-md bg-blue-100 text-blue-900 font-bold text-[10px] uppercase tracking-wider">
                    {item.category}
                  </span>
                  <span className="text-emerald-700 text-xs font-semibold flex items-center space-x-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Verified AC Fleet</span>
                  </span>
                </div>

                <h3 className="text-base sm:text-lg font-bold text-slate-900 mt-3 font-heading">
                  {item.name}
                </h3>

                {/* Specs */}
                <div className="mt-3 flex items-center space-x-4 text-xs text-slate-600">
                  <div className="flex items-center space-x-1.5">
                    <Users className="w-4 h-4 text-slate-400" />
                    <span>{item.seatingCapacity} Seats</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <Luggage className="w-4 h-4 text-slate-400" />
                    <span>{item.luggageCapacity}</span>
                  </div>
                </div>

                {/* Features list */}
                <ul className="mt-3.5 space-y-1.5 text-xs text-slate-600">
                  {item.features.map((feat, i) => (
                    <li key={i} className="flex items-start space-x-1.5">
                      <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Pricing & CTA */}
              <div className="mt-6 pt-3 border-t border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Fares starting at</span>
                  <div className="flex items-baseline space-x-1">
                    <span className="text-xl font-black text-slate-900 font-heading">₹{item.basePrice}</span>
                    {item.pricePerKm && <span className="text-[11px] text-slate-500">(+₹{item.pricePerKm}/km)</span>}
                  </div>
                </div>

                <button
                  onClick={() => onBookTransport(item)}
                  className="px-4 py-2 rounded-lg bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs transition-colors shadow-xs flex items-center space-x-1 cursor-pointer"
                >
                  <span>Book Cab</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
