import React from 'react';
import { Sparkles, CheckCircle2, Gift, ArrowRight } from 'lucide-react';
import { User } from '../types';

interface WalletModalProps {
  currentUser: User;
  onClose: () => void;
  onExplorePackages: () => void;
}

export const WalletModal: React.FC<WalletModalProps> = ({
  currentUser,
  onClose,
  onExplorePackages
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-sm"
        >
          ✕
        </button>

        <div className="flex items-center space-x-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center">
            <Sparkles className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <span className="text-[10px] text-amber-600 font-bold uppercase tracking-wider block">
              Customer Loyalty Wallet
            </span>
            <h3 className="text-xl font-black text-slate-900 font-heading">
              GoCash Balance
            </h3>
          </div>
        </div>

        {/* Current Balance Card */}
        <div className="p-5 rounded-2xl bg-gradient-to-r from-[#0c223c] to-[#12365e] text-white space-y-1 mb-5 shadow-lg">
          <span className="text-xs text-amber-300 font-medium">Available Redeemable Credit</span>
          <div className="text-3xl font-black text-white font-heading">
            ₹{currentUser.goCashBalance}
          </div>
          <span className="text-[11px] text-slate-300 block pt-1">
            Registered to: {currentUser.phone}
          </span>
        </div>

        <div className="space-y-3 text-xs text-slate-600">
          <h4 className="font-bold text-slate-800 text-sm">How to use GoCash:</h4>
          
          <div className="flex items-start space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>Redeem up to 20% on any hotel booking, tour package, or rental bike.</span>
          </div>

          <div className="flex items-start space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>Earn 5% guaranteed GoCash cashback automatically credited after every journey.</span>
          </div>

          <div className="flex items-start space-x-2">
            <Gift className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <span>No expiry date. Redeemable across all GoDigha travel services.</span>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100 flex items-center space-x-3">
          <button
            onClick={() => { onClose(); onExplorePackages(); }}
            className="w-full py-2.5 bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs rounded-xl shadow-md flex items-center justify-center space-x-1.5"
          >
            <span>Book Trips & Redeem</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
