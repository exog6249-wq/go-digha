import React from 'react';
import { MapPin, Phone, MessageSquare, Instagram, Clock, Star, ShieldCheck, Mail } from 'lucide-react';
import { BUSINESS_INFO } from '../data/mockData';
import { GoDighaLogo } from './GoDighaLogo';

interface FooterProps {
  onNavigate: (view: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-[#0b1c30] text-slate-300 border-t border-[#183659] pb-24 lg:pb-12 pt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 pb-10 border-b border-slate-800">
          
          {/* Brand Info & Trust (2 cols) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full border-2 border-amber-400/80 bg-[#041D48] overflow-hidden flex items-center justify-center shadow-md">
                <GoDighaLogo className="w-full h-full object-cover" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-white font-heading tracking-tight">
                  {BUSINESS_INFO.name}
                </h3>
                <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block">
                  Travel Agency & Tourism Services
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed max-w-sm">
              Old Digha’s top-rated 5.0★ travel management company. We arrange verified hotel stays in Digha & Mandarmani, chauffeur cabs, local sightseeing, water sports, and domestic & international holiday packages.
            </p>

            {/* Google Rating Badge */}
            <div className="inline-flex items-center space-x-2 bg-white/5 border border-white/10 px-3 py-1.5 rounded-xl text-xs">
              <div className="flex text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-current" />
                ))}
              </div>
              <span className="font-bold text-white">5.0 / 5.0</span>
              <span className="text-slate-400">({BUSINESS_INFO.reviewsCount} Google Reviews)</span>
            </div>
          </div>

          {/* Quick Travel Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Travel Services
            </h4>
            <ul className="space-y-2 text-xs text-slate-300">
              <li>
                <button onClick={() => onNavigate('hotels')} className="hover:text-white transition-colors">
                  Digha & Mandarmani Hotels
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('transports')} className="hover:text-white transition-colors">
                  Railway Station Pickup & Drop
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('experiences')} className="hover:text-white transition-colors">
                  Beach Water Sports & Jet Ski
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('experiences')} className="hover:text-white transition-colors">
                  Rental Bikes (Activa & Cruiser)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('corporate')} className="hover:text-white transition-colors">
                  Corporate Conferences & DJ
                </button>
              </li>
            </ul>
          </div>

          {/* Popular Circuits */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Top Circuits
            </h4>
            <ul className="space-y-2 text-xs text-slate-300">
              <li>
                <button onClick={() => onNavigate('packages')} className="hover:text-white transition-colors">
                  Darjeeling Toy Train Heritage
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('packages')} className="hover:text-white transition-colors">
                  Sikkim & Gangtok Alpine Tour
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('packages')} className="hover:text-white transition-colors">
                  Kedarnath & Uttarakhand Yatra
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('packages')} className="hover:text-white transition-colors">
                  Bhutan Dragon Kingdom Tour
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('packages')} className="hover:text-white transition-colors">
                  Sundarban Delta Boat Safari
                </button>
              </li>
            </ul>
          </div>

          {/* Contact & Hours */}
          <div className="space-y-3 text-xs">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Office & Contact
            </h4>
            <div className="space-y-2 text-slate-300">
              <div className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  {BUSINESS_INFO.address}<br />
                  <span className="text-[10px] text-slate-400 font-mono">Plus Code: {BUSINESS_INFO.googlePlusCode}</span>
                </span>
              </div>

              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`tel:${BUSINESS_INFO.phone}`} className="hover:text-white font-bold">
                  {BUSINESS_INFO.phoneFormatted}
                </a>
              </div>

              <div className="flex items-center space-x-2">
                <MessageSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                <a
                  href={BUSINESS_INFO.whatsappDirectLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white"
                >
                  WhatsApp: {BUSINESS_INFO.whatsapp}
                </a>
              </div>

              <div className="flex items-center space-x-2">
                <Instagram className="w-4 h-4 text-pink-400 shrink-0" />
                <a
                  href={BUSINESS_INFO.instagramLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white font-mono"
                >
                  {BUSINESS_INFO.instagram}
                </a>
              </div>

              <div className="flex items-center space-x-2 text-amber-300 font-medium">
                <Clock className="w-4 h-4 shrink-0" />
                <span>{BUSINESS_INFO.businessHours}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Strip */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <div>
            © {new Date().getFullYear()} {BUSINESS_INFO.name}. All rights reserved.
          </div>
          <div className="flex items-center space-x-4 text-[11px]">
            <span>Privacy Policy</span>
            <span>·</span>
            <span>Terms of Service</span>
            <span>·</span>
            <span>Cancellation & Refund Policy</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
