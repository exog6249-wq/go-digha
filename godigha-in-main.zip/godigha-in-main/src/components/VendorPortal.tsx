import React, { useState } from 'react';
import { User, Hotel, Booking } from '../types';
import { StorageService } from '../services/storage';
import {
  Building,
  Bed,
  CalendarCheck,
  IndianRupee,
  ShieldCheck,
  TrendingUp,
  Clock,
  CheckCircle,
  Plus,
  Edit2
} from 'lucide-react';

interface VendorPortalProps {
  currentUser: User;
}

export const VendorPortal: React.FC<VendorPortalProps> = ({ currentUser }) => {
  const vendorId = currentUser.vendorId || 'vendor_sea_star';

  // Isolated data fetching for this vendor
  const allHotels = StorageService.getHotels();
  const assignedHotels = allHotels.filter(h => h.vendorId === vendorId);
  const selectedHotel = assignedHotels[0] || allHotels[0];

  const allBookings = StorageService.getBookings();
  const vendorBookings = allBookings.filter(b => b.vendorId === vendorId || b.itemId === selectedHotel?.id);

  // Revenue calculation (85% settlement share)
  const totalGrossRevenue = vendorBookings
    .filter(b => b.paymentStatus === 'PAID')
    .reduce((sum, b) => sum + b.totalAmount, 0);

  const vendorPayoutShare = Math.round(totalGrossRevenue * 0.85);

  const [rooms, setRooms] = useState(selectedHotel?.rooms || []);
  const [editingRoomId, setEditingRoomId] = useState<string | null>(null);
  const [editPrice, setEditPrice] = useState<number>(0);
  const [editInventory, setEditInventory] = useState<number>(0);

  const handleStartEdit = (roomId: string, currentPrice: number, available: number) => {
    setEditingRoomId(roomId);
    setEditPrice(currentPrice);
    setEditInventory(available);
  };

  const handleSaveRoom = (roomId: string) => {
    if (!selectedHotel) return;
    const updatedRooms = selectedHotel.rooms.map(r => {
      if (r.id === roomId) {
        return { ...r, pricePerNight: editPrice, availableRooms: editInventory };
      }
      return r;
    });

    const updatedHotel: Hotel = {
      ...selectedHotel,
      rooms: updatedRooms,
      startingPrice: Math.min(...updatedRooms.map(r => r.pricePerNight))
    };

    StorageService.saveHotel(updatedHotel);
    setRooms(updatedRooms);
    setEditingRoomId(null);
  };

  const handleUpdateBookingStatus = (bookingId: string, status: Booking['bookingStatus']) => {
    StorageService.updateBookingStatus(bookingId, status);
  };

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Vendor Header */}
      <div className="bg-emerald-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl mb-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-emerald-800 text-emerald-200 text-xs font-bold uppercase tracking-wider mb-2">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Verified Partner / Hotelier Portal</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
            {selectedHotel ? selectedHotel.name : 'Partner Operator Desk'}
          </h1>
          <p className="text-xs sm:text-sm text-emerald-200 mt-1">
            Partner Manager: <strong>{currentUser.name}</strong> · {selectedHotel?.location}
          </p>
        </div>

        {/* Vendor Isolation Guarantee */}
        <div className="bg-black/30 p-4 rounded-2xl border border-white/10 text-xs text-emerald-100 max-w-xs">
          <strong>Security Isolation:</strong> You are authorized to manage only properties and guest arrivals assigned to Partner ID: <code className="text-amber-300 font-mono">{vendorId}</code>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Vendor Payout Share (85%)
          </span>
          <div className="text-2xl font-black text-slate-900 mt-1 font-heading">
            ₹{vendorPayoutShare.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-600 font-semibold mt-1">
            Net payable via direct NEFT / IMPS
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Total Bookings
          </span>
          <div className="text-2xl font-black text-slate-900 mt-1 font-heading">
            {vendorBookings.length}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Guest reservations logged
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Active Rooms Managed
          </span>
          <div className="text-2xl font-black text-slate-900 mt-1 font-heading">
            {selectedHotel?.rooms.length || 0}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Room categories live on portal
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Platform Service Fee (15%)
          </span>
          <div className="text-2xl font-black text-slate-700 mt-1 font-heading">
            ₹{(totalGrossRevenue - vendorPayoutShare).toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            GoDigha marketing & operations fee
          </div>
        </div>
      </div>

      {/* 2-Column: Room Inventory & Rates (Left) + Assigned Bookings (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left: Rooms Management (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-slate-900 text-base font-heading">
                Room Inventory & Dynamic Tariffs
              </h3>
              <p className="text-xs text-slate-500">
                Update seasonal room rates & daily availability instantaneously
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {rooms.map((room) => {
              const isEditing = editingRoomId === room.id;
              return (
                <div
                  key={room.id}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{room.name}</h4>
                      <span className="text-xs text-slate-500">{room.bedType} · Max {room.capacity} Pax</span>
                    </div>

                    {!isEditing && (
                      <button
                        onClick={() => handleStartEdit(room.id, room.pricePerNight, room.availableRooms)}
                        className="px-2.5 py-1 rounded bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-xs font-semibold flex items-center space-x-1"
                      >
                        <Edit2 className="w-3 h-3" />
                        <span>Edit Tariff</span>
                      </button>
                    )}
                  </div>

                  {isEditing ? (
                    <div className="p-3 bg-white rounded-xl border border-blue-200 space-y-3 text-xs">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="font-bold text-slate-700 block mb-1">
                            Price Per Night (₹)
                          </label>
                          <input
                            type="number"
                            value={editPrice}
                            onChange={(e) => setEditPrice(parseInt(e.target.value) || 0)}
                            className="w-full bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 font-bold"
                          />
                        </div>
                        <div>
                          <label className="font-bold text-slate-700 block mb-1">
                            Available Inventory
                          </label>
                          <input
                            type="number"
                            value={editInventory}
                            onChange={(e) => setEditInventory(parseInt(e.target.value) || 0)}
                            className="w-full bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 font-bold"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end space-x-2 pt-1">
                        <button
                          onClick={() => setEditingRoomId(null)}
                          className="px-3 py-1 bg-slate-200 text-slate-700 rounded text-xs font-semibold"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => handleSaveRoom(room.id)}
                          className="px-3 py-1 bg-emerald-700 text-white rounded text-xs font-bold"
                        >
                          Save Changes
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-200/60">
                      <div>
                        <span className="text-slate-400">Current Rate:</span>{' '}
                        <strong className="text-slate-900 text-sm">₹{room.pricePerNight}</strong>/night
                      </div>
                      <div>
                        <span className="text-slate-400">Stock Available:</span>{' '}
                        <strong className="text-emerald-700 font-bold">{room.availableRooms} rooms</strong>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Guest Bookings Assigned to This Vendor (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-base font-heading">
              Assigned Guest Reservations
            </h3>
            <p className="text-xs text-slate-500">
              Live guest arrivals, verification codes & check-in approvals
            </p>
          </div>

          {vendorBookings.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              No reservations logged for this property yet.
            </div>
          ) : (
            <div className="space-y-3">
              {vendorBookings.map((b) => (
                <div
                  key={b.id}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-mono font-bold text-blue-900">{b.id}</span>
                      <h4 className="font-bold text-slate-900 text-sm mt-0.5">{b.customerName}</h4>
                      <p className="text-slate-500 text-[11px]">{b.customerPhone}</p>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded font-bold text-[10px] uppercase ${
                        b.bookingStatus === 'CONFIRMED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {b.bookingStatus}
                    </span>
                  </div>

                  <div className="p-2.5 bg-white rounded-xl border border-slate-100 space-y-1 text-[11px] text-slate-600">
                    <p><strong>Travel Date:</strong> {b.travelDate} · <strong>Pax:</strong> {b.travellers}</p>
                    <p><strong>Item:</strong> {b.itemTitle}</p>
                    {b.specialRequests && (
                      <p className="text-blue-900"><strong>Guest Request:</strong> {b.specialRequests}</p>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <span className="text-slate-500">Vendor Net Share: <strong className="text-emerald-700">₹{Math.round(b.totalAmount * 0.85)}</strong></span>
                    {b.bookingStatus === 'PROCESSING' && (
                      <button
                        onClick={() => handleUpdateBookingStatus(b.id, 'CONFIRMED')}
                        className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold text-xs"
                      >
                        Accept & Confirm
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
