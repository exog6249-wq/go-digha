import React from 'react';
import { TravelPackage } from '../types';
import { Sparkles, Calendar, ArrowRight } from 'lucide-react';

interface ExploreTopToursProps {
  packages: TravelPackage[];
  onSelectPackage: (pkg: TravelPackage) => void;
  onViewAllPackages: () => void;
}

export const ExploreTopTours: React.FC<ExploreTopToursProps> = ({
  packages,
  onSelectPackage,
  onViewAllPackages
}) => {
  // Tour items corresponding to the user's reference image
  const topTours = [
    {
      title: 'Darjeeling Tour',
      tag: 'Toy Train & Tea Hills',
      image: '/src/assets/images/tour_darjeeling_tea_1790324589896.jpg',
      packageId: 'pkg_darjeeling_01',
      price: '₹8,499'
    },
    {
      title: 'Sikkim Tour',
      tag: 'Monasteries & Lakes',
      image: '/src/assets/images/tour_gangtok_ropeway_1790324618130.jpg',
      packageId: 'pkg_sikkim_01',
      price: '₹11,499'
    },
    {
      title: 'Gangtok Tour',
      tag: 'Cable Car & MG Marg',
      image: '/src/assets/images/tour_gangtok_ropeway_1790324618130.jpg',
      packageId: 'pkg_sikkim_01',
      price: '₹11,499'
    },
    {
      title: 'Manali Tour',
      tag: 'Snow Peaks & Valleys',
      image: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=600&auto=format&fit=crop&q=80',
      packageId: 'pkg_manali_01',
      price: '₹13,499'
    },
    {
      title: 'Ladakh Tour',
      tag: 'Pangong & High Passes',
      image: 'https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?w=600&auto=format&fit=crop&q=80',
      packageId: 'pkg_manali_01', // Fallback or dedicated package
      price: '₹22,999'
    },
    {
      title: 'Bhutan Tour',
      tag: 'Tiger’s Nest & Dzongs',
      image: 'https://images.unsplash.com/photo-1578637387939-43c525550085?w=600&auto=format&fit=crop&q=80',
      packageId: 'pkg_bhutan_01',
      price: '₹28,999'
    },
    {
      title: 'Uttarakhand Tour',
      tag: 'Kedarnath & Rivers',
      image: 'https://images.unsplash.com/photo-1596895111956-bf1cf0599ce5?w=600&auto=format&fit=crop&q=80',
      packageId: 'pkg_uttarakhand_01',
      price: '₹12,499'
    },
    {
      title: 'Sundarban Tour',
      tag: 'Mangroves & Tigers',
      image: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?w=600&auto=format&fit=crop&q=80',
      packageId: 'pkg_sundarban_01',
      price: '₹4,499'
    },
    {
      title: 'Digha Beach Tour',
      tag: 'Sea View & Relaxation',
      image: '/src/assets/images/hero_digha_sea_1790324572880.jpg',
      packageId: 'pkg_digha_weekend',
      price: '₹3,499'
    },
    {
      title: 'Mandarmani Tour',
      tag: 'Beach Resorts & Water Fun',
      image: '/src/assets/images/tour_mandarmani_resort_1790324605435.jpg',
      packageId: 'pkg_mandarmani_01',
      price: '₹4,999'
    }
  ];

  const handleCardClick = (tour: typeof topTours[0]) => {
    const pkg = packages.find(p => p.id === tour.packageId) || packages[0];
    if (pkg) onSelectPackage(pkg);
  };

  return (
    <section className="py-8 px-3 sm:px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Title matching reference */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 pb-2 border-b border-slate-100 gap-2">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight uppercase font-heading">
              EXPLORE TOP TOURS
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Handcrafted holiday itineraries curated with hotels, cabs, sightseeing & local support
            </p>
          </div>

          <button
            onClick={onViewAllPackages}
            className="self-start sm:self-auto inline-flex items-center space-x-1.5 text-xs sm:text-sm font-semibold text-blue-800 hover:text-amber-600 transition-colors"
          >
            <span>View All Packages</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 4-column desktop / 2-column mobile rounded card grid */}
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-5">
          {topTours.map((tour, idx) => (
            <div
              key={`${tour.title}-${idx}`}
              onClick={() => handleCardClick(tour)}
              className="group cursor-pointer rounded-2xl overflow-hidden bg-white shadow-sm hover:shadow-xl border border-slate-200/70 transition-all duration-300 flex flex-col hover:-translate-y-1"
            >
              {/* Image Container with aspect ratio matching reference */}
              <div className="relative aspect-4/3 overflow-hidden bg-slate-100">
                <img
                  src={tour.image}
                  alt={tour.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                
                {/* Starting Price Pill */}
                <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-xs text-white px-2 py-0.5 rounded-md text-[10px] sm:text-xs font-semibold">
                  from {tour.price}
                </div>
              </div>

              {/* White bottom banner with Tour Name matching reference */}
              <div className="py-2.5 px-2 bg-white text-center border-t border-slate-100 flex flex-col justify-center">
                <h3 className="font-bold text-slate-800 text-xs sm:text-sm md:text-base group-hover:text-blue-900 transition-colors truncate">
                  {tour.title}
                </h3>
                <span className="text-[10px] text-slate-400 truncate mt-0.5">
                  {tour.tag}
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
