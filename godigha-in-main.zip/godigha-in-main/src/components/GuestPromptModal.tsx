import React from 'react';
import { Heart, Lock, UserPlus, LogIn, X, Compass } from 'lucide-react';
import { GoDighaLogo } from './GoDighaLogo';

interface GuestPromptModalProps {
  title?: string;
  description?: string;
  onClose: () => void;
  onLogin: () => void;
  onCreateAccount: () => void;
}

export const GuestPromptModal: React.FC<GuestPromptModalProps> = ({
  title = 'Login to save this package',
  description = 'Sign in to sync your saved destinations, holiday packages, and travel itineraries across all your devices.',
  onClose,
  onLogin,
  onCreateAccount
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200 text-center">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-sm"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="w-14 h-14 rounded-2xl bg-orange-50 text-orange-600 flex items-center justify-center mx-auto mb-4 border border-orange-100 shadow-sm">
          <Heart className="w-7 h-7 fill-orange-500 text-orange-500" />
        </div>

        <h3 className="text-lg font-black text-slate-900 font-heading mb-1.5">
          {title}
        </h3>
        
        <p className="text-xs text-slate-500 leading-relaxed mb-6">
          {description}
        </p>

        <div className="space-y-2.5">
          <button
            onClick={() => {
              onClose();
              onLogin();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center space-x-2 transition-colors shadow-md shadow-orange-500/20 active:scale-95"
          >
            <LogIn className="w-4 h-4" />
            <span>Login to GoDigha</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onCreateAccount();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs sm:text-sm flex items-center justify-center space-x-2 transition-colors active:scale-95"
          >
            <UserPlus className="w-4 h-4 text-slate-600" />
            <span>Create New Account</span>
          </button>

          <button
            onClick={onClose}
            className="w-full py-2 text-xs font-semibold text-slate-400 hover:text-slate-600 transition-colors"
          >
            Continue Browsing
          </button>
        </div>

      </div>
    </div>
  );
};
