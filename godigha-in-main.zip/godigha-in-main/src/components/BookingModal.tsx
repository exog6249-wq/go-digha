import React, { useState } from 'react';
import { TravelPackage, Hotel, HotelRoom, Booking, User, BookingGuest } from '../types';
import { StorageService } from '../services/storage';
import {
  Calendar,
  Users,
  ShieldCheck,
  CreditCard,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Tag,
  AlertCircle
} from 'lucide-react';

interface BookingModalProps {
  item: TravelPackage | { hotel: Hotel; room: HotelRoom } | any;
  itemType: 'PACKAGE' | 'HOTEL' | 'TRANSPORT' | 'ACTIVITY' | 'BIKE';
  currentUser: User | null;
  onClose: () => void;
  onProceedToPayment: (bookingData: Partial<Booking>) => void;
  onRequireAuth?: (bookingData: Partial<Booking>) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  item,
  itemType,
  currentUser,
  onClose,
  onProceedToPayment,
  onRequireAuth
}) => {
  // Extract item details
  const isPackage = itemType === 'PACKAGE';
  const isHotel = itemType === 'HOTEL';

  const title = isPackage
    ? (item as TravelPackage).name
    : isHotel
    ? `${(item as any).hotel.name} - ${(item as any).room.name}`
    : (item as any).name;

  const image = isPackage
    ? (item as TravelPackage).coverImage
    : isHotel
    ? (item as any).room.image || (item as any).hotel.images[0]
    : (item as any).image;

  const unitPrice = isPackage
    ? (item as TravelPackage).discountedPrice || (item as TravelPackage).startingPrice
    : isHotel
    ? (item as any).room.pricePerNight
    : (item as any).basePrice || (item as any).price || (item as any).pricePerDay;

  const vendorId = isHotel ? (item as any).hotel.vendorId : 'vendor_sea_star';

  // Form states
  const [travelDate, setTravelDate] = useState('2026-10-15');
  const [returnDate, setReturnDate] = useState('2026-10-18');
  const [travellersCount, setTravellersCount] = useState<number>(2);
  const [customerName, setCustomerName] = useState(currentUser?.name || 'Rahul Banerjee');
  const [customerPhone, setCustomerPhone] = useState(currentUser?.phone || '+91 88491 25029');
  const [customerEmail, setCustomerEmail] = useState(currentUser?.email || 'rahul.b@example.com');
  const [specialRequests, setSpecialRequests] = useState('');

  // Primary Guest Details
  const [guests, setGuests] = useState<BookingGuest[]>([
    { fullName: currentUser?.name || 'Primary Traveller', age: 32, gender: 'Male', idProofType: 'Aadhaar Card' },
    { fullName: 'Guest 2', age: 28, gender: 'Female', idProofType: 'Aadhaar Card' }
  ]);

  // Discounts & Wallet
  const [couponCode, setCouponCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(0);
  const [useGoCash, setUseGoCash] = useState(false);

  // Update guests array when travellersCount changes
  const handleTravellerChange = (count: number) => {
    setTravellersCount(count);
    const newGuests = [...guests];
    if (count > guests.length) {
      for (let i = guests.length; i < count; i++) {
        newGuests.push({
          fullName: `Traveller ${i + 1}`,
          age: 30,
          gender: 'Male',
          idProofType: 'Aadhaar Card'
        });
      }
    } else {
      newGuests.length = count;
    }
    setGuests(newGuests);
  };

  const handleGuestFieldChange = (index: number, field: keyof BookingGuest, value: any) => {
    const updated = [...guests];
    updated[index] = { ...updated[index], [field]: value };
    setGuests(updated);
  };

  const applyCoupon = () => {
    if (couponCode.toUpperCase() === 'GODIGHA500') {
      setDiscountApplied(500);
    } else if (couponCode.toUpperCase() === 'WELCOME10') {
      const discount = Math.round(unitPrice * travellersCount * 0.1);
      setDiscountApplied(Math.min(discount, 1000));
    } else {
      alert('Invalid coupon code. Try GODIGHA500 or WELCOME10');
    }
  };

  // Calculations
  const baseAmount = unitPrice * (isPackage ? travellersCount : 1);
  const taxAmount = Math.round(baseAmount * 0.05); // 5% GST
  const availableGoCash = currentUser?.goCashBalance || 0;
  const maxGoCashUsable = Math.min(availableGoCash, Math.round(baseAmount * 0.2)); // Max 20% by GoCash
  const goCashUsed = useGoCash ? maxGoCashUsable : 0;
  const totalAmount = Math.max(0, baseAmount + taxAmount - discountApplied - goCashUsed);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const bookingId = `GD-BK-${Date.now().toString().slice(-6)}`;

    const partialBooking: Partial<Booking> = {
      id: bookingId,
      customerId: currentUser?.id || 'guest_pending',
      customerName,
      customerEmail,
      customerPhone,
      bookingType: itemType,
      itemId: (item as any).id || 'pkg_custom',
      itemTitle: title,
      itemSubtitle: `${isPackage ? 'Holiday Package' : itemType} · ${travellersCount} Guests`,
      itemImage: image,
      vendorId,
      travelDate,
      returnDate: isPackage ? returnDate : undefined,
      travellers: travellersCount,
      guests,
      baseAmount,
      taxAmount,
      discountAmount: discountApplied,
      goCashUsed,
      totalAmount,
      paymentStatus: 'PENDING',
      bookingStatus: 'PROCESSING',
      specialRequests,
      createdAt: new Date().toISOString()
    };

    if (!currentUser && onRequireAuth) {
      onRequireAuth(partialBooking);
    } else {
      onProceedToPayment(partialBooking);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-y-auto shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="sticky top-0 z-20 bg-white/95 backdrop-blur-md px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="font-bold text-slate-800 text-sm sm:text-base font-heading">
              Confirm & Book with GoDigha
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 text-slate-600 hover:bg-slate-200 flex items-center justify-center font-bold"
          >
            ✕
          </button>
        </div>

        {/* Selected Item Summary Card */}
        <div className="p-6 border-b border-slate-100 bg-slate-50/70 flex items-center space-x-4">
          <img
            src={image}
            alt={title}
            referrerPolicy="no-referrer"
            className="w-20 h-20 rounded-xl object-cover shrink-0 border border-slate-200"
          />
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-blue-900 block">
              {itemType}
            </span>
            <h3 className="font-bold text-slate-900 text-sm sm:text-base line-clamp-1">{title}</h3>
            <div className="text-xs text-slate-500 mt-1 flex items-center space-x-2">
              <span className="font-semibold text-slate-800">₹{unitPrice}</span>
              <span>·</span>
              <span>{isPackage ? 'Per Person' : 'Per Night/Service'}</span>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Dates & Travellers */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Travel Date *</label>
              <input
                type="date"
                required
                value={travelDate}
                onChange={(e) => setTravelDate(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
              />
            </div>

            {isPackage && (
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Return Date</label>
                <input
                  type="date"
                  value={returnDate}
                  onChange={(e) => setReturnDate(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>
            )}

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Travellers Count *</label>
              <select
                value={travellersCount}
                onChange={(e) => handleTravellerChange(parseInt(e.target.value))}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
              >
                {[1, 2, 3, 4, 5, 6, 8, 10].map((num) => (
                  <option key={num} value={num}>
                    {num} {num === 1 ? 'Traveller' : 'Travellers'}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Primary Contact Details */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              Primary Contact Details (Booking Confirmation & Tickets)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <input
                  type="text"
                  required
                  placeholder="Full Name *"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>
              <div>
                <input
                  type="tel"
                  required
                  placeholder="Phone Number *"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>
              <div>
                <input
                  type="email"
                  required
                  placeholder="Email Address *"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Guest Names & ID Verification */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
              Traveller Roster & Gov ID Details
            </label>
            {guests.map((guest, idx) => (
              <div key={idx} className="grid grid-cols-1 sm:grid-cols-4 gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                <div className="sm:col-span-2">
                  <input
                    type="text"
                    required
                    placeholder={`Guest ${idx + 1} Name`}
                    value={guest.fullName}
                    onChange={(e) => handleGuestFieldChange(idx, 'fullName', e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-md px-2.5 py-1.5 text-xs text-slate-800"
                  />
                </div>
                <div>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    placeholder="Age"
                    value={guest.age}
                    onChange={(e) => handleGuestFieldChange(idx, 'age', parseInt(e.target.value) || 25)}
                    className="w-full bg-white border border-slate-300 rounded-md px-2.5 py-1.5 text-xs text-slate-800"
                  />
                </div>
                <div>
                  <select
                    value={guest.gender}
                    onChange={(e) => handleGuestFieldChange(idx, 'gender', e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-md px-2 py-1.5 text-xs text-slate-800"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>
            ))}
          </div>

          {/* Coupon Code & GoCash Wallet */}
          <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-950 flex items-center space-x-1.5">
                <Tag className="w-4 h-4 text-amber-600" />
                <span>Offers & GoCash Wallet Savings</span>
              </span>
              <span className="text-xs text-slate-500">
                Wallet Balance: <strong>₹{availableGoCash}</strong>
              </span>
            </div>

            <div className="flex space-x-2">
              <input
                type="text"
                placeholder="Try GODIGHA500 or WELCOME10"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                className="flex-1 bg-white border border-amber-300 rounded-lg px-3 py-1.5 text-xs uppercase font-mono font-bold text-slate-800"
              />
              <button
                type="button"
                onClick={applyCoupon}
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-lg transition-colors"
              >
                Apply
              </button>
            </div>

            {availableGoCash > 0 && (
              <label className="flex items-center space-x-2 text-xs font-semibold text-slate-800 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={useGoCash}
                  onChange={(e) => setUseGoCash(e.target.checked)}
                  className="rounded text-amber-600"
                />
                <span>Redeem ₹{maxGoCashUsable} from your GoCash wallet balance</span>
              </label>
            )}
          </div>

          {/* Special Requests */}
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Special Requests (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Higher floor sea facing room, non-spicy meals for kids"
              value={specialRequests}
              onChange={(e) => setSpecialRequests(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
            />
          </div>

          {/* Price Breakdown */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-2">
            <div className="flex justify-between text-slate-600">
              <span>Base Fare ({travellersCount} {travellersCount > 1 ? 'travellers' : 'traveller'}):</span>
              <span className="font-semibold text-slate-800">₹{baseAmount}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Govt Taxes & Coastal Tourism GST (5%):</span>
              <span className="font-semibold text-slate-800">+₹{taxAmount}</span>
            </div>
            {discountApplied > 0 && (
              <div className="flex justify-between text-emerald-700 font-semibold">
                <span>Coupon Discount:</span>
                <span>-₹{discountApplied}</span>
              </div>
            )}
            {goCashUsed > 0 && (
              <div className="flex justify-between text-amber-700 font-semibold">
                <span>GoCash Wallet Redeemed:</span>
                <span>-₹{goCashUsed}</span>
              </div>
            )}
            <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline text-sm font-bold text-slate-900">
              <span>Net Payable Amount:</span>
              <span className="text-xl font-black text-slate-900 font-heading">
                ₹{totalAmount}
              </span>
            </div>
            <div className="text-[10px] text-slate-400 text-right">
              Earns 5% GoCash cashback (₹{Math.round(totalAmount * 0.05)}) credited on trip completion
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-3 px-4 rounded-xl bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-sm shadow-md transition-all active:scale-98 flex items-center justify-center space-x-2 cursor-pointer"
          >
            <CreditCard className="w-4 h-4 text-amber-400" />
            <span>Proceed to Secure Gateway (₹{totalAmount})</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
