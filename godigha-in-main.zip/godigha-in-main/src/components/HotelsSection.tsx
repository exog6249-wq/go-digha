import React, { useState } from 'react';
import { Hotel, HotelRoom } from '../types';
import { MapPin, Star, Check, Phone, ShieldCheck, ChevronRight, Eye } from 'lucide-react';
import { BUSINESS_INFO } from '../data/mockData';

interface HotelsSectionProps {
  hotels: Hotel[];
  onBookHotelRoom: (hotel: Hotel, room: HotelRoom) => void;
}

export const HotelsSection: React.FC<HotelsSectionProps> = ({ hotels, onBookHotelRoom }) => {
  const [selectedLocation, setSelectedLocation] = useState<string>('ALL');
  const [activeHotelModal, setActiveHotelModal] = useState<Hotel | null>(null);

  const locations = [
    { id: 'ALL', label: 'All Stays' },
    { id: 'Old Digha', label: 'Old Digha' },
    { id: 'New Digha', label: 'New Digha' },
    { id: 'Mandarmani', label: 'Mandarmani Beach' }
  ];

  const filteredHotels = hotels.filter((h) => {
    if (selectedLocation === 'ALL') return true;
    return h.location.toLowerCase().includes(selectedLocation.toLowerCase());
  });

  return (
    <section className="py-10 px-4 sm:px-6 lg:px-8 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-blue-900 mb-1">
              GoDigha Partner Stays
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-heading">
              Hotels & Beach Accommodations
            </h2>
            <p className="text-sm text-slate-600 mt-1 max-w-xl">
              Carefully vetted, spotlessly clean hotels & seaside resorts in Digha and Mandarmani with verified room service and beach proximity.
            </p>
          </div>

          {/* Location Filter Pills */}
          <div className="flex flex-wrap gap-2">
            {locations.map((loc) => (
              <button
                key={loc.id}
                onClick={() => setSelectedLocation(loc.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
                  selectedLocation === loc.id
                    ? 'bg-[#0f2847] text-white shadow-sm'
                    : 'bg-white text-slate-700 hover:bg-slate-200/80 border border-slate-200'
                }`}
              >
                {loc.label}
              </button>
            ))}
          </div>
        </div>

        {/* Hotels Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredHotels.map((hotel) => (
            <div
              key={hotel.id}
              className="bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group"
            >
              {/* Hotel Image & Distance Badge */}
              <div className="relative aspect-16/10 overflow-hidden bg-slate-100">
                <img
                  src={hotel.images[0]}
                  alt={hotel.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-xs text-white text-[11px] font-semibold px-2.5 py-1 rounded-md flex items-center space-x-1">
                  <MapPin className="w-3 h-3 text-amber-400" />
                  <span>{hotel.distanceFromBeach}</span>
                </div>

                <div className="absolute top-3 right-3 bg-white/95 text-slate-900 text-xs font-bold px-2 py-0.5 rounded shadow-sm flex items-center space-x-1">
                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                  <span>{hotel.rating}</span>
                </div>
              </div>

              {/* Content */}
              <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 group-hover:text-blue-900 transition-colors">
                    {hotel.name}
                  </h3>
                  <div className="text-xs text-slate-500 flex items-center space-x-1 mt-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{hotel.location}</span>
                  </div>

                  <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                    {hotel.description}
                  </p>

                  {/* Key Amenities */}
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {hotel.amenities.slice(0, 4).map((amenity, i) => (
                      <span
                        key={i}
                        className="text-[11px] text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md flex items-center space-x-1"
                      >
                        <Check className="w-2.5 h-2.5 text-emerald-600" />
                        <span>{amenity}</span>
                      </span>
                    ))}
                  </div>
                </div>

                {/* Pricing & CTA */}
                <div className="mt-5 pt-3.5 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Starts from</span>
                    <div className="flex items-baseline space-x-1">
                      <span className="text-lg font-black text-slate-900 font-heading">
                        ₹{hotel.startingPrice}
                      </span>
                      <span className="text-[11px] text-slate-500">/ night</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setActiveHotelModal(hotel)}
                      className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold transition-colors flex items-center space-x-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Rooms</span>
                    </button>
                    <button
                      onClick={() => onBookHotelRoom(hotel, hotel.rooms[0])}
                      className="px-3.5 py-1.5 rounded-lg bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs transition-colors shadow-xs"
                    >
                      Book Now
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Hotel Detail Modal with Room Types & Policies */}
      {activeHotelModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-5 sm:p-7 relative animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setActiveHotelModal(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-lg"
            >
              ✕
            </button>

            <div className="text-xs font-bold text-blue-900 uppercase tracking-wider">
              {activeHotelModal.location}
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 mt-1 font-heading">
              {activeHotelModal.name}
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              {activeHotelModal.address} · {activeHotelModal.distanceFromBeach}
            </p>

            {/* Gallery */}
            <div className="grid grid-cols-2 gap-2 mt-4 rounded-xl overflow-hidden">
              {activeHotelModal.images.map((img, idx) => (
                <img
                  key={idx}
                  src={img}
                  alt={`${activeHotelModal.name} view ${idx + 1}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-40 object-cover"
                />
              ))}
            </div>

            {/* Available Room Types */}
            <div className="mt-6">
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-800 mb-3">
                Available Room Options
              </h4>
              <div className="space-y-3">
                {activeHotelModal.rooms.map((room) => (
                  <div
                    key={room.id}
                    className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <h5 className="font-bold text-slate-900 text-sm">{room.name}</h5>
                      <div className="text-xs text-slate-500 flex items-center space-x-2 mt-0.5">
                        <span>Max {room.capacity} Guests</span>
                        <span>·</span>
                        <span>{room.bedType}</span>
                        <span>·</span>
                        <span className="text-emerald-700 font-semibold">{room.availableRooms} rooms left</span>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {room.amenities.map((a, i) => (
                          <span key={i} className="text-[10px] bg-white text-slate-600 px-2 py-0.5 rounded border border-slate-200">
                            {a}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:flex-col sm:items-end gap-2 shrink-0">
                      <div className="text-right">
                        <span className="text-lg font-black text-slate-900">₹{room.pricePerNight}</span>
                        <span className="text-[11px] text-slate-500"> / night</span>
                      </div>
                      <button
                        onClick={() => {
                          const h = activeHotelModal;
                          setActiveHotelModal(null);
                          onBookHotelRoom(h, room);
                        }}
                        className="px-4 py-1.5 rounded-lg bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs shadow-xs"
                      >
                        Select Room
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Policies */}
            <div className="mt-5 p-3.5 bg-blue-50/60 rounded-xl border border-blue-100 text-xs text-slate-700 space-y-1">
              <div className="font-bold text-blue-950 flex items-center space-x-1">
                <ShieldCheck className="w-4 h-4 text-blue-700" />
                <span>GoDigha Stay Policies & Assurance</span>
              </div>
              <p>Check-In: <strong>{activeHotelModal.policies.checkIn}</strong> · Check-Out: <strong>{activeHotelModal.policies.checkOut}</strong></p>
              <p>Cancellation: {activeHotelModal.policies.cancellation}</p>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Direct Hotline: <strong>{BUSINESS_INFO.phoneFormatted}</strong></span>
              <button
                onClick={() => setActiveHotelModal(null)}
                className="px-4 py-1.5 rounded-md bg-slate-200 hover:bg-slate-300 font-semibold text-slate-800"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};
