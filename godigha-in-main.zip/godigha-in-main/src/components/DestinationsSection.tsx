import React from 'react';
import { Destination } from '../types';
import { MapPin, Calendar, ArrowRight, Compass } from 'lucide-react';

interface DestinationsSectionProps {
  destinations: Destination[];
  onSelectDestination: (destName: string) => void;
}

export const DestinationsSection: React.FC<DestinationsSectionProps> = ({
  destinations,
  onSelectDestination
}) => {
  return (
    <div className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-blue-100 text-blue-900 text-xs font-bold uppercase tracking-wider mb-2">
          <Compass className="w-3.5 h-3.5" />
          <span>Where2Go Travel Guide</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 font-heading">
          Explore Popular Destinations
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 mt-1">
          From tranquil coastal beaches of Digha and Mandarmani to towering Himalayan peaks & mangrove boat safaris.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {destinations.map((dest) => (
          <div
            key={dest.id}
            onClick={() => onSelectDestination(dest.name)}
            className="group cursor-pointer bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between hover:-translate-y-1"
          >
            <div>
              <div className="relative aspect-16/10 overflow-hidden bg-slate-100">
                <img
                  src={dest.image}
                  alt={dest.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-xs text-white text-[11px] font-semibold px-2.5 py-1 rounded-md flex items-center space-x-1">
                  <MapPin className="w-3 h-3 text-amber-400" />
                  <span>{dest.state}, {dest.country}</span>
                </div>
              </div>

              <div className="p-5">
                <h3 className="font-extrabold text-slate-900 text-lg font-heading group-hover:text-blue-900 transition-colors">
                  {dest.name}
                </h3>
                <p className="text-xs font-semibold text-amber-600 mt-0.5">{dest.tagline}</p>
                <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                  {dest.description}
                </p>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {dest.popularFor.map((item, i) => (
                    <span key={i} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-medium">
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-5 pt-0 flex items-center justify-between border-t border-slate-100 pt-3.5">
              <div>
                <span className="text-[10px] text-slate-400 block">Trips from</span>
                <span className="text-base font-black text-slate-900 font-heading">₹{dest.startingPrice}</span>
              </div>

              <button
                type="button"
                className="inline-flex items-center space-x-1 text-xs font-bold text-blue-900 group-hover:text-amber-600 transition-colors"
              >
                <span>View Packages</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
