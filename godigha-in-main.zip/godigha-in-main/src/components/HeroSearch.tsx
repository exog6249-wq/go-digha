import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Calendar,
  Users,
  MapPin,
  CheckCircle2,
  Zap,
  Headphones,
  ShieldCheck,
  Hotel,
  Car,
  Compass,
  Waves,
  Bike,
  ChevronDown,
  ArrowRight,
  Sparkles,
  Clock,
  Repeat,
  History,
  TrendingUp,
  X,
  Layers,
  Map
} from 'lucide-react';
import heroBg from '../assets/images/digha_coastal_hero_1790504628498.jpg';
import { DESTINATIONS } from '../data/mockData';
import { StorageService } from '../services/storage';
import {
  ServiceCategory,
  UnifiedSearchParams,
  RecentSearchItem,
  User
} from '../types';
import {
  detectCategoryFromQuery,
  getLiveSuggestions,
  POPULAR_SEARCH_TERMS,
  TOP_DESTINATIONS,
  SearchSuggestionItem
} from '../services/searchEngine';

interface HeroSearchProps {
  onSearch: (params: UnifiedSearchParams) => void;
  onExploreClick: () => void;
  onQuickPlanClick: () => void;
  initialParams?: Partial<UnifiedSearchParams>;
  currentUser?: User | null;
}

export const HeroSearch: React.FC<HeroSearchProps> = ({
  onSearch,
  onExploreClick,
  onQuickPlanClick,
  initialParams,
  currentUser
}) => {
  // Active Category Tab: 'hotel' | 'cab' | 'tour' | 'activity' | 'bike' (Section 1)
  const [activeTab, setActiveTab] = useState<ServiceCategory>(initialParams?.category || 'hotel');

  // Common Search / Query input state (Section 9 & 11)
  const [searchQuery, setSearchQuery] = useState(initialParams?.query || '');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [recentSearches, setRecentSearches] = useState<RecentSearchItem[]>([]);
  const suggestionsRef = useRef<HTMLDivElement>(null);

  // 1. Hotel fields (Section 2)
  const [destination, setDestination] = useState(initialParams?.destination || 'Digha, Mandarmani');
  const [checkInDate, setCheckInDate] = useState('2026-10-15');
  const [checkOutDate, setCheckOutDate] = useState('2026-10-18');
  const [guests, setGuests] = useState('2 Guests');
  const [showGuestsDropdown, setShowGuestsDropdown] = useState(false);

  // 2. Cab fields (Section 3)
  const [cabTripMode, setCabTripMode] = useState<'oneway' | 'roundtrip'>('oneway');
  const [cabFrom, setCabFrom] = useState('Digha');
  const [cabTo, setCabTo] = useState('Mandarmani');
  const [cabDate, setCabDate] = useState('2026-10-15');
  const [cabTime, setCabTime] = useState('10:00 AM');
  const [cabPassengers, setCabPassengers] = useState('2');
  const [showCabPassengersDropdown, setShowCabPassengersDropdown] = useState(false);
  const [showCabTimeDropdown, setShowCabTimeDropdown] = useState(false);

  // 3. Tour fields (Section 4)
  const [tourDestination, setTourDestination] = useState('Digha');
  const [tourDate, setTourDate] = useState('2026-10-15');
  const [tourDuration, setTourDuration] = useState('2 Nights / 3 Days');
  const [tourTravellers, setTourTravellers] = useState('2 Travellers');
  const [showTourDurationDropdown, setShowTourDurationDropdown] = useState(false);
  const [showTourTravellersDropdown, setShowTourTravellersDropdown] = useState(false);

  // 4. Activity fields (Section 5)
  const [activityDestination, setActivityDestination] = useState('Mandarmani');
  const [activityType, setActivityType] = useState('Water Sports');
  const [activityDate, setActivityDate] = useState('2026-10-15');
  const [activityGuests, setActivityGuests] = useState('2 Guests');
  const [showActivityTypeDropdown, setShowActivityTypeDropdown] = useState(false);
  const [showActivityGuestsDropdown, setShowActivityGuestsDropdown] = useState(false);

  // 5. Bike fields (Section 6)
  const [bikePickup, setBikePickup] = useState('Old Digha Station');
  const [bikePickupDate, setBikePickupDate] = useState('2026-10-15');
  const [bikeReturnDate, setBikeReturnDate] = useState('2026-10-17');
  const [bikeType, setBikeType] = useState('Scooter');
  const [showBikeTypeDropdown, setShowBikeTypeDropdown] = useState(false);

  // Load Recent Searches on mount and when storage updates (Section 12, 13, 14)
  const loadRecentSearches = () => {
    setRecentSearches(StorageService.getRecentSearches(currentUser?.id));
  };

  useEffect(() => {
    loadRecentSearches();
    const handleUpdate = () => loadRecentSearches();
    window.addEventListener('godigha_storage_updated', handleUpdate);
    return () => window.removeEventListener('godigha_storage_updated', handleUpdate);
  }, [currentUser]);

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (suggestionsRef.current && !suggestionsRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Category Tab Definitions
  const tabs: { id: ServiceCategory; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'hotel', label: 'Hotel', icon: Hotel },
    { id: 'cab', label: 'Cab', icon: Car },
    { id: 'tour', label: 'Tour', icon: Compass },
    { id: 'activity', label: 'Activity', icon: Waves },
    { id: 'bike', label: 'Bike', icon: Bike },
  ];

  // Options
  const destinationOptions = [
    'Digha, Mandarmani',
    'Old Digha Sea Beach',
    'New Digha Sea Beach',
    'Mandarmani Beach Resort',
    'Tajpur Beach',
    'Shankarpur Fishing Harbor',
    'Bakkhali Coastal Strip',
    'Darjeeling',
    'Sundarban'
  ];

  const cabFromOptions = ['Digha', 'Old Digha Station', 'New Digha', 'Mandarmani', 'Kolkata', 'Howrah Station', 'Kharagpur'];
  const cabToOptions = ['Mandarmani', 'Digha', 'Tajpur Beach', 'Bakkhali', 'Kolkata Airport', 'Old Digha'];
  const cabTimeOptions = ['06:00 AM', '08:00 AM', '10:00 AM', '12:00 PM', '02:00 PM', '04:00 PM', '06:00 PM', '08:00 PM'];

  const tourDurationOptions = ['All Durations', '2 Nights / 3 Days', '3 Nights / 4 Days', '4+ Nights'];
  const activityTypeOptions = ['All Activities', 'Water Sports', 'Jet Ski', 'Banana Boat Ride', 'Parasailing', 'Deep Sea Speed Boat', 'Beach Quad Bike (ATV)', 'Photography Experiences'];
  const bikeTypeOptions = ['All Types', 'Scooter', 'Cruiser', 'Sports'];

  // Live Suggestions list based on input (Section 10 & 11)
  const currentSearchText = activeTab === 'hotel' ? destination : searchQuery;
  const liveSuggestions = getLiveSuggestions(currentSearchText, recentSearches);

  // Recent Search Management Handlers (Section 14)
  const handleRemoveRecentSearch = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    StorageService.removeRecentSearch(id, currentUser?.id);
    loadRecentSearches();
  };

  const handleClearAllRecentSearches = (e: React.MouseEvent) => {
    e.stopPropagation();
    StorageService.clearRecentSearches(currentUser?.id);
    loadRecentSearches();
  };

  // Select suggestion item
  const handleSelectSuggestion = (item: SearchSuggestionItem) => {
    setShowSuggestions(false);
    setActiveTab(item.category);

    if (item.destination) {
      setDestination(item.destination);
      setTourDestination(item.destination);
      setActivityDestination(item.destination);
    }
    setSearchQuery(item.query);

    // Save to recent searches
    StorageService.addRecentSearch(
      {
        query: item.query,
        category: item.category,
        destination: item.destination || 'Digha',
        label: item.title,
        subtitle: item.subtitle
      },
      currentUser?.id
    );

    // Execute search immediately
    executeSearchForCategory(item.category, item.query, item.destination);
  };

  // Search execution router
  const executeSearchForCategory = (cat: ServiceCategory, query?: string, overrideDest?: string) => {
    const dest = overrideDest || (cat === 'hotel' ? destination.split(',')[0].trim() : cat === 'cab' ? `${cabFrom} to ${cabTo}` : cat === 'tour' ? tourDestination : cat === 'activity' ? activityDestination : bikePickup);

    let unifiedParams: UnifiedSearchParams = {
      category: cat,
      query: query || searchQuery || undefined,
      destination: dest
    };

    switch (cat) {
      case 'hotel':
        unifiedParams.hotelParams = {
          destination: dest,
          checkIn: checkInDate,
          checkOut: checkOutDate,
          guests: guests
        };
        break;
      case 'cab':
        unifiedParams.cabParams = {
          tripMode: cabTripMode,
          from: cabFrom,
          to: cabTo,
          date: cabDate,
          time: cabTime,
          passengers: cabPassengers
        };
        break;
      case 'tour':
        unifiedParams.tourParams = {
          destination: dest,
          travelDate: tourDate,
          duration: tourDuration,
          travellers: tourTravellers
        };
        break;
      case 'activity':
        unifiedParams.activityParams = {
          destination: dest,
          activityType: activityType,
          date: activityDate,
          guests: activityGuests
        };
        break;
      case 'bike':
        unifiedParams.bikeParams = {
          pickupLocation: bikePickup,
          pickupDate: bikePickupDate,
          returnDate: bikeReturnDate,
          bikeType: bikeType
        };
        break;
    }

    // Save search to Recent Searches (Section 12)
    const searchLabel = query || `${cat.toUpperCase()}: ${dest}`;
    StorageService.addRecentSearch(
      {
        query: searchLabel,
        category: cat,
        destination: dest,
        params: unifiedParams,
        label: searchLabel,
        subtitle: `${cat.charAt(0).toUpperCase() + cat.slice(1)} • ${dest}`
      },
      currentUser?.id
    );

    onSearch(unifiedParams);
  };

  // Main Submit Handler (Section 7)
  const handleSearchSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setShowSuggestions(false);

    // If user typed a global query like "digha hotels" or "bike rental", auto-detect category (Section 9)
    if (searchQuery.trim()) {
      const detectedCat = detectCategoryFromQuery(searchQuery);
      if (detectedCat && detectedCat !== activeTab) {
        setActiveTab(detectedCat);
        executeSearchForCategory(detectedCat, searchQuery);
        return;
      }
    }

    executeSearchForCategory(activeTab, searchQuery);
  };

  // Popular search pill click
  const handlePopularSearchClick = (tag: string) => {
    const detected = detectCategoryFromQuery(tag) || 'hotel';
    setActiveTab(detected);
    const cleanDest = tag.replace(' Hotels', '').replace(' Resort', '');
    setDestination(cleanDest);
    setSearchQuery(tag);

    StorageService.addRecentSearch(
      {
        query: tag,
        category: detected,
        destination: cleanDest,
        label: tag,
        subtitle: `${detected.toUpperCase()} • ${cleanDest}`
      },
      currentUser?.id
    );

    executeSearchForCategory(detected, tag, cleanDest);
  };

  return (
    <section className="relative bg-[#07192d] text-white overflow-hidden">
      {/* 1. Cinematic Panoramic Coastal Background */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <img
          src={heroBg}
          alt="Digha Coastal Beach & Ocean Waves"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-[center_35%] md:object-center transform scale-100 md:hover:scale-105 transition-transform duration-1000 ease-out"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#06182c]/95 via-[#06182c]/75 to-[#06182c]/40 md:to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#061527]/90 via-transparent to-[#07192d]/95" />
      </div>

      {/* 2. Main Hero Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-12 md:pt-14 md:pb-16 lg:pt-16 lg:pb-20">
        
        {/* Top Hero Layout: Tagline, Title, Subtitle, Trust Badges */}
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6 mb-8 md:mb-10">
          
          <div className="max-w-3xl space-y-4">
            
            <div className="inline-flex items-center space-x-2 text-xs md:text-sm tracking-[0.25em] uppercase font-semibold text-slate-200/90 drop-shadow-sm">
              <span>TRAVEL</span>
              <span className="text-amber-400 font-bold">•</span>
              <span>EXPLORE</span>
              <span className="text-amber-400 font-bold">•</span>
              <span>EXPERIENCE</span>
            </div>

            <h1 className="text-3xl sm:text-5xl md:text-6xl font-black text-white tracking-tight leading-none drop-shadow-md font-heading">
              Digha{' '}
              <span className="bg-gradient-to-r from-[#FF7A00] via-[#FFA033] to-[#FF8A00] bg-clip-text text-transparent">
                Awaits You
              </span>
            </h1>

            <p className="text-sm sm:text-base md:text-lg text-slate-100/90 font-medium max-w-2xl leading-relaxed drop-shadow-sm">
              Hotels • Cabs • Tours • Activities • Bike Rentals • Everything for Your Trip
            </p>

            <div className="flex flex-wrap items-center gap-x-5 gap-y-2.5 pt-1 text-xs md:text-sm font-medium text-white/95">
              <div className="flex items-center space-x-1.5 drop-shadow-sm">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 fill-emerald-500/20" />
                <span>Best Price Guarantee</span>
              </div>
              <div className="flex items-center space-x-1.5 drop-shadow-sm">
                <Zap className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span>Instant Confirmation</span>
              </div>
              <div className="flex items-center space-x-1.5 drop-shadow-sm">
                <Headphones className="w-4 h-4 text-sky-400" />
                <span>24/7 Local Support</span>
              </div>
              <div className="flex items-center space-x-1.5 drop-shadow-sm">
                <ShieldCheck className="w-4 h-4 text-blue-300" />
                <span>Verified Coastal Partners</span>
              </div>
            </div>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={onExploreClick}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-orange-500/25 active:scale-95 flex items-center space-x-2"
              >
                <span>Explore Packages</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              
              <button
                onClick={onQuickPlanClick}
                className="px-5 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white font-semibold text-xs sm:text-sm backdrop-blur-md border border-white/20 transition-all active:scale-95 flex items-center space-x-2"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Plan My Trip</span>
              </button>
            </div>

          </div>

          <div className="hidden lg:flex flex-col items-end justify-center pr-4 select-none">
            <div className="relative transform -rotate-3 text-right">
              <div
                className="text-4xl md:text-5xl lg:text-6xl text-white font-bold leading-tight tracking-wide drop-shadow-[0_4px_16px_rgba(0,0,0,0.6)]"
                style={{ fontFamily: "'Caveat', cursive, sans-serif" }}
              >
                <span className="block transform hover:translate-x-1 transition-transform">Sea</span>
                <span className="block text-amber-300 transform hover:translate-x-1 transition-transform delay-75">Stay</span>
                <span className="block transform hover:translate-x-1 transition-transform delay-100">Explore</span>
                <span className="block text-orange-400 transform hover:translate-x-1 transition-transform delay-150">Repeat</span>
              </div>
            </div>
          </div>

        </div>

        {/* 3. Floating Premium Search Card (Upgraded Functional Widget) */}
        <div className="relative z-20 bg-white rounded-2xl md:rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.3)] p-4 sm:p-5 md:p-6 text-slate-800 border border-slate-100 transition-all">
          
          {/* Tab Selector Row (Section 1) */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-3 mb-4 border-b border-slate-100 scrollbar-none">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(tab.id);
                    setShowSuggestions(false);
                  }}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs md:text-sm font-bold transition-all shrink-0 active:scale-95 cursor-pointer ${
                    isActive
                      ? 'bg-[#FF6E00] text-white shadow-md shadow-orange-500/30'
                      : 'bg-slate-50 text-slate-600 hover:bg-slate-100 hover:text-slate-900 border border-slate-200/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Search Inputs Form Row (Section 2, 3, 4, 5, 6, 7) */}
          <form onSubmit={handleSearchSubmit} className="relative">
            
            {/* Live Search Suggestion Panel Container */}
            <div ref={suggestionsRef} className="relative">
              
              {/* CATEGORY: HOTEL (Section 2) */}
              {activeTab === 'hotel' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 md:gap-4 items-center">
                  
                  {/* Field 1: Destination with suggestions */}
                  <div className="relative lg:col-span-3">
                    <div
                      onClick={() => setShowSuggestions(!showSuggestions)}
                      className="w-full flex items-center space-x-3 p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 cursor-pointer transition-colors"
                    >
                      <div className="p-2 rounded-lg bg-blue-50 text-blue-900">
                        <MapPin className="w-5 h-5 text-blue-900" />
                      </div>
                      <div className="flex-1 text-left min-w-0">
                        <span className="block text-[10px] md:text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                          Destination / Hotel
                        </span>
                        <input
                          type="text"
                          value={destination}
                          onChange={(e) => {
                            setDestination(e.target.value);
                            setSearchQuery(e.target.value);
                            setShowSuggestions(true);
                          }}
                          onFocus={() => setShowSuggestions(true)}
                          className="w-full bg-transparent text-xs md:text-sm font-bold text-slate-800 truncate focus:outline-none"
                          placeholder="Digha, Mandarmani..."
                        />
                      </div>
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                    </div>
                  </div>

                  {/* Field 2: Check In */}
                  <div className="relative lg:col-span-2">
                    <div className="w-full flex items-center space-x-2.5 p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 cursor-pointer transition-colors relative">
                      <div className="p-2 rounded-lg bg-orange-50 text-orange-600 shrink-0">
                        <Calendar className="w-4 h-4 md:w-5 md:h-5 text-orange-600" />
                      </div>
                      <div className="flex-1 text-left min-w-0">
                        <span className="block text-[10px] md:text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                          Check In
                        </span>
                        <span className="block text-xs md:text-sm font-bold text-slate-800 truncate">
                          {checkInDate ? new Date(checkInDate + 'T00:00:00').toLocaleDateString('en-US', { day: 'numeric', month: 'short' }) : 'Select Date'}
                        </span>
                      </div>
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                      <input
                        type="date"
                        value={checkInDate}
                        onChange={(e) => setCheckInDate(e.target.value)}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      />
                    </div>
                  </div>

                  {/* Field 3: Check Out */}
                  <div className="relative lg:col-span-2">
                    <div className="w-full flex items-center space-x-2.5 p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 cursor-pointer transition-colors relative">
                      <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 shrink-0">
                        <Calendar className="w-4 h-4 md:w-5 md:h-5 text-emerald-600" />
                      </div>
                      <div className="flex-1 text-left min-w-0">
                        <span className="block text-[10px] md:text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                          Check Out
                        </span>
                        <span className="block text-xs md:text-sm font-bold text-slate-800 truncate">
                          {checkOutDate ? new Date(checkOutDate + 'T00:00:00').toLocaleDateString('en-US', { day: 'numeric', month: 'short' }) : 'Select Date'}
                        </span>
                      </div>
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                      <input
                        type="date"
                        value={checkOutDate}
                        onChange={(e) => setCheckOutDate(e.target.value)}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      />
                    </div>
                  </div>

                  {/* Field 4: Guests */}
                  <div className="relative lg:col-span-2">
                    <div
                      onClick={() => {
                        setShowGuestsDropdown(!showGuestsDropdown);
                        setShowSuggestions(false);
                      }}
                      className="w-full flex items-center space-x-2.5 p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 cursor-pointer transition-colors"
                    >
                      <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600 shrink-0">
                        <Users className="w-4 h-4 md:w-5 md:h-5 text-indigo-600" />
                      </div>
                      <div className="flex-1 text-left min-w-0">
                        <span className="block text-[10px] md:text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                          Guests
                        </span>
                        <span className="block text-xs md:text-sm font-bold text-slate-800 truncate">
                          {guests}
                        </span>
                      </div>
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                    </div>

                    {showGuestsDropdown && (
                      <div className="absolute top-full left-0 mt-2 w-full sm:w-52 bg-white rounded-xl shadow-2xl border border-slate-200 py-1.5 z-50">
                        <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100">
                          Select Travellers
                        </div>
                        {['1 Guest', '2 Guests', '3 Guests', '4 Guests', '5+ Guests', '10+ Group'].map((g) => (
                          <button
                            key={g}
                            type="button"
                            onClick={() => {
                              setGuests(g);
                              setShowGuestsDropdown(false);
                            }}
                            className={`w-full text-left px-3 py-2 text-xs font-medium hover:bg-orange-50 hover:text-orange-600 transition-colors flex items-center justify-between ${
                              guests === g ? 'bg-orange-50 text-orange-600 font-bold' : 'text-slate-700'
                            }`}
                          >
                            <span>{g}</span>
                            {guests === g && <span className="text-orange-600 text-xs">✓</span>}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Search Button */}
                  <div className="lg:col-span-3 flex items-center">
                    <button
                      type="submit"
                      className="w-full h-[52px] bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold rounded-xl flex items-center justify-center space-x-2 shadow-lg shadow-orange-500/30 transition-all active:scale-95 cursor-pointer text-sm md:text-base"
                    >
                      <Search className="w-5 h-5 text-white" />
                      <span className="font-bold tracking-wide">Search</span>
                    </button>
                  </div>

                </div>
              )}

              {/* CATEGORY: CAB (Section 3) */}
              {activeTab === 'cab' && (
                <div className="space-y-3">
                  {/* Optional One Way / Round Trip Toggle */}
                  <div className="flex items-center space-x-4 text-xs font-bold text-slate-600 pb-1">
                    <label className="flex items-center space-x-1.5 cursor-pointer">
                      <input
                        type="radio"
                        name="cabTripMode"
                        checked={cabTripMode === 'oneway'}
                        onChange={() => setCabTripMode('oneway')}
                        className="text-orange-600 focus:ring-orange-500"
                      />
                      <span className={cabTripMode === 'oneway' ? 'text-orange-600 font-black' : ''}>One Way</span>
                    </label>
                    <label className="flex items-center space-x-1.5 cursor-pointer">
                      <input
                        type="radio"
                        name="cabTripMode"
                        checked={cabTripMode === 'roundtrip'}
                        onChange={() => setCabTripMode('roundtrip')}
                        className="text-orange-600 focus:ring-orange-500"
                      />
                      <span className={cabTripMode === 'roundtrip' ? 'text-orange-600 font-black' : ''}>Round Trip</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 md:gap-4 items-center">
                    {/* FROM */}
                    <div className="lg:col-span-3">
                      <div className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2.5">
                        <MapPin className="w-4 h-4 text-orange-600 shrink-0" />
                        <div className="flex-1 min-w-0">
                          <span className="block text-[10px] md:text-[11px] font-semibold uppercase tracking-wider text-slate-500">From</span>
                          <input
                            type="text"
                            value={cabFrom}
                            onChange={(e) => setCabFrom(e.target.value)}
                            className="w-full bg-transparent text-xs md:text-sm font-bold text-slate-800 truncate focus:outline-none"
                            placeholder="Digha, Station..."
                          />
                        </div>
                      </div>
                    </div>

                    {/* TO */}
                    <div className="lg:col-span-3">
                      <div className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2.5">
                        <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
                        <div className="flex-1 min-w-0">
                          <span className="block text-[10px] md:text-[11px] font-semibold uppercase tracking-wider text-slate-500">To</span>
                          <input
                            type="text"
                            value={cabTo}
                            onChange={(e) => setCabTo(e.target.value)}
                            className="w-full bg-transparent text-xs md:text-sm font-bold text-slate-800 truncate focus:outline-none"
                            placeholder="Mandarmani..."
                          />
                        </div>
                      </div>
                    </div>

                    {/* DATE */}
                    <div className="lg:col-span-2 relative">
                      <div className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2 relative cursor-pointer">
                        <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
                        <div className="flex-1 min-w-0">
                          <span className="block text-[10px] uppercase font-semibold text-slate-500">Date</span>
                          <span className="block text-xs font-bold text-slate-800 truncate">
                            {new Date(cabDate + 'T00:00:00').toLocaleDateString('en-US', { day: 'numeric', month: 'short' })}
                          </span>
                        </div>
                        <input
                          type="date"
                          value={cabDate}
                          onChange={(e) => setCabDate(e.target.value)}
                          className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                        />
                      </div>
                    </div>

                    {/* TIME */}
                    <div className="lg:col-span-2 relative">
                      <div
                        onClick={() => setShowCabTimeDropdown(!showCabTimeDropdown)}
                        className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2 cursor-pointer"
                      >
                        <Clock className="w-4 h-4 text-indigo-600 shrink-0" />
                        <div className="flex-1 min-w-0">
                          <span className="block text-[10px] uppercase font-semibold text-slate-500">Pickup Time</span>
                          <span className="block text-xs font-bold text-slate-800 truncate">{cabTime}</span>
                        </div>
                        <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      </div>

                      {showCabTimeDropdown && (
                        <div className="absolute top-full left-0 mt-2 w-36 bg-white rounded-xl shadow-xl border border-slate-200 py-1 z-50">
                          {cabTimeOptions.map(t => (
                            <button
                              key={t}
                              type="button"
                              onClick={() => {
                                setCabTime(t);
                                setShowCabTimeDropdown(false);
                              }}
                              className="w-full text-left px-3 py-1.5 text-xs hover:bg-orange-50 hover:text-orange-600 font-semibold"
                            >
                              {t}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* SEARCH CABS BUTTON */}
                    <div className="lg:col-span-2">
                      <button
                        type="submit"
                        className="w-full h-[52px] bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold rounded-xl flex items-center justify-center space-x-1.5 shadow-lg shadow-orange-500/30 transition-all active:scale-95 cursor-pointer text-xs md:text-sm"
                      >
                        <Search className="w-4 h-4 text-white" />
                        <span>Search Cabs</span>
                      </button>
                    </div>

                  </div>
                </div>
              )}

              {/* CATEGORY: TOUR (Section 4) */}
              {activeTab === 'tour' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 md:gap-4 items-center">
                  
                  {/* Destination */}
                  <div className="lg:col-span-3">
                    <div className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2.5">
                      <Compass className="w-5 h-5 text-orange-600 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="block text-[10px] md:text-[11px] font-semibold uppercase tracking-wider text-slate-500">Destination</span>
                        <input
                          type="text"
                          value={tourDestination}
                          onChange={(e) => setTourDestination(e.target.value)}
                          className="w-full bg-transparent text-xs md:text-sm font-bold text-slate-800 truncate focus:outline-none"
                          placeholder="Digha, Mandarmani..."
                        />
                      </div>
                    </div>
                  </div>

                  {/* Travel Date */}
                  <div className="lg:col-span-2 relative">
                    <div className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2 relative cursor-pointer">
                      <Calendar className="w-4 h-4 text-orange-600 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="block text-[10px] uppercase font-semibold text-slate-500">Travel Date</span>
                        <span className="block text-xs font-bold text-slate-800 truncate">
                          {new Date(tourDate + 'T00:00:00').toLocaleDateString('en-US', { day: 'numeric', month: 'short' })}
                        </span>
                      </div>
                      <input
                        type="date"
                        value={tourDate}
                        onChange={(e) => setTourDate(e.target.value)}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      />
                    </div>
                  </div>

                  {/* Duration */}
                  <div className="lg:col-span-2 relative">
                    <div
                      onClick={() => setShowTourDurationDropdown(!showTourDurationDropdown)}
                      className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2 cursor-pointer"
                    >
                      <Clock className="w-4 h-4 text-emerald-600 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="block text-[10px] uppercase font-semibold text-slate-500">Duration</span>
                        <span className="block text-xs font-bold text-slate-800 truncate">{tourDuration}</span>
                      </div>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    </div>

                    {showTourDurationDropdown && (
                      <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50">
                        {tourDurationOptions.map(d => (
                          <button
                            key={d}
                            type="button"
                            onClick={() => {
                              setTourDuration(d);
                              setShowTourDurationDropdown(false);
                            }}
                            className="w-full text-left px-3 py-1.5 text-xs hover:bg-orange-50 hover:text-orange-600 font-semibold"
                          >
                            {d}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Travellers */}
                  <div className="lg:col-span-2 relative">
                    <div
                      onClick={() => setShowTourTravellersDropdown(!showTourTravellersDropdown)}
                      className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2 cursor-pointer"
                    >
                      <Users className="w-4 h-4 text-indigo-600 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="block text-[10px] uppercase font-semibold text-slate-500">Travellers</span>
                        <span className="block text-xs font-bold text-slate-800 truncate">{tourTravellers}</span>
                      </div>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    </div>

                    {showTourTravellersDropdown && (
                      <div className="absolute top-full left-0 mt-2 w-44 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50">
                        {['1 Traveller', '2 Travellers', '3 Travellers', '4 Travellers', '5+ Family', '10+ Group'].map(t => (
                          <button
                            key={t}
                            type="button"
                            onClick={() => {
                              setTourTravellers(t);
                              setShowTourTravellersDropdown(false);
                            }}
                            className="w-full text-left px-3 py-1.5 text-xs hover:bg-orange-50 hover:text-orange-600 font-semibold"
                          >
                            {t}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Search Tours Button */}
                  <div className="lg:col-span-3">
                    <button
                      type="submit"
                      className="w-full h-[52px] bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold rounded-xl flex items-center justify-center space-x-2 shadow-lg shadow-orange-500/30 transition-all active:scale-95 cursor-pointer text-sm"
                    >
                      <Search className="w-4 h-4 text-white" />
                      <span>Search Tours</span>
                    </button>
                  </div>

                </div>
              )}

              {/* CATEGORY: ACTIVITY (Section 5) */}
              {activeTab === 'activity' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 md:gap-4 items-center">
                  
                  {/* Destination / Beach */}
                  <div className="lg:col-span-3">
                    <div className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2.5">
                      <Waves className="w-5 h-5 text-sky-600 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="block text-[10px] md:text-[11px] font-semibold uppercase tracking-wider text-slate-500">Beach Location</span>
                        <input
                          type="text"
                          value={activityDestination}
                          onChange={(e) => setActivityDestination(e.target.value)}
                          className="w-full bg-transparent text-xs md:text-sm font-bold text-slate-800 truncate focus:outline-none"
                          placeholder="Mandarmani, Old Digha..."
                        />
                      </div>
                    </div>
                  </div>

                  {/* Activity Type */}
                  <div className="lg:col-span-3 relative">
                    <div
                      onClick={() => setShowActivityTypeDropdown(!showActivityTypeDropdown)}
                      className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2 cursor-pointer"
                    >
                      <div className="flex-1 min-w-0">
                        <span className="block text-[10px] uppercase font-semibold text-slate-500">Activity Type</span>
                        <span className="block text-xs font-bold text-slate-800 truncate">{activityType}</span>
                      </div>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    </div>

                    {showActivityTypeDropdown && (
                      <div className="absolute top-full left-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 max-h-60 overflow-y-auto">
                        {activityTypeOptions.map(at => (
                          <button
                            key={at}
                            type="button"
                            onClick={() => {
                              setActivityType(at);
                              setShowActivityTypeDropdown(false);
                            }}
                            className="w-full text-left px-3 py-1.5 text-xs hover:bg-orange-50 hover:text-orange-600 font-semibold"
                          >
                            {at}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Date */}
                  <div className="lg:col-span-2 relative">
                    <div className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2 relative cursor-pointer">
                      <Calendar className="w-4 h-4 text-orange-600 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="block text-[10px] uppercase font-semibold text-slate-500">Date</span>
                        <span className="block text-xs font-bold text-slate-800 truncate">
                          {new Date(activityDate + 'T00:00:00').toLocaleDateString('en-US', { day: 'numeric', month: 'short' })}
                        </span>
                      </div>
                      <input
                        type="date"
                        value={activityDate}
                        onChange={(e) => setActivityDate(e.target.value)}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      />
                    </div>
                  </div>

                  {/* Guests */}
                  <div className="lg:col-span-2 relative">
                    <div
                      onClick={() => setShowActivityGuestsDropdown(!showActivityGuestsDropdown)}
                      className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2 cursor-pointer"
                    >
                      <Users className="w-4 h-4 text-indigo-600 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="block text-[10px] uppercase font-semibold text-slate-500">Guests</span>
                        <span className="block text-xs font-bold text-slate-800 truncate">{activityGuests}</span>
                      </div>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    </div>

                    {showActivityGuestsDropdown && (
                      <div className="absolute top-full left-0 mt-2 w-44 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50">
                        {['1 Guest', '2 Guests', '4 Guests', '6+ Group'].map(g => (
                          <button
                            key={g}
                            type="button"
                            onClick={() => {
                              setActivityGuests(g);
                              setShowActivityGuestsDropdown(false);
                            }}
                            className="w-full text-left px-3 py-1.5 text-xs hover:bg-orange-50 hover:text-orange-600 font-semibold"
                          >
                            {g}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Search Activities Button */}
                  <div className="lg:col-span-2">
                    <button
                      type="submit"
                      className="w-full h-[52px] bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold rounded-xl flex items-center justify-center space-x-1.5 shadow-lg shadow-orange-500/30 transition-all active:scale-95 cursor-pointer text-xs md:text-sm"
                    >
                      <Search className="w-4 h-4 text-white" />
                      <span>Search</span>
                    </button>
                  </div>

                </div>
              )}

              {/* CATEGORY: BIKE (Section 6) */}
              {activeTab === 'bike' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 md:gap-4 items-center">
                  
                  {/* Pickup Location */}
                  <div className="lg:col-span-3">
                    <div className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2.5">
                      <Bike className="w-5 h-5 text-orange-600 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="block text-[10px] md:text-[11px] font-semibold uppercase tracking-wider text-slate-500">Pickup Location</span>
                        <input
                          type="text"
                          value={bikePickup}
                          onChange={(e) => setBikePickup(e.target.value)}
                          className="w-full bg-transparent text-xs md:text-sm font-bold text-slate-800 truncate focus:outline-none"
                          placeholder="Old Digha Station..."
                        />
                      </div>
                    </div>
                  </div>

                  {/* Pickup Date */}
                  <div className="lg:col-span-2 relative">
                    <div className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2 relative cursor-pointer">
                      <Calendar className="w-4 h-4 text-orange-600 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="block text-[10px] uppercase font-semibold text-slate-500">Pickup Date</span>
                        <span className="block text-xs font-bold text-slate-800 truncate">
                          {new Date(bikePickupDate + 'T00:00:00').toLocaleDateString('en-US', { day: 'numeric', month: 'short' })}
                        </span>
                      </div>
                      <input
                        type="date"
                        value={bikePickupDate}
                        onChange={(e) => setBikePickupDate(e.target.value)}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      />
                    </div>
                  </div>

                  {/* Return Date */}
                  <div className="lg:col-span-2 relative">
                    <div className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2 relative cursor-pointer">
                      <Calendar className="w-4 h-4 text-emerald-600 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <span className="block text-[10px] uppercase font-semibold text-slate-500">Return Date</span>
                        <span className="block text-xs font-bold text-slate-800 truncate">
                          {new Date(bikeReturnDate + 'T00:00:00').toLocaleDateString('en-US', { day: 'numeric', month: 'short' })}
                        </span>
                      </div>
                      <input
                        type="date"
                        value={bikeReturnDate}
                        onChange={(e) => setBikeReturnDate(e.target.value)}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      />
                    </div>
                  </div>

                  {/* Bike Type */}
                  <div className="lg:col-span-2 relative">
                    <div
                      onClick={() => setShowBikeTypeDropdown(!showBikeTypeDropdown)}
                      className="w-full p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 flex items-center space-x-2 cursor-pointer"
                    >
                      <div className="flex-1 min-w-0">
                        <span className="block text-[10px] uppercase font-semibold text-slate-500">Bike Type</span>
                        <span className="block text-xs font-bold text-slate-800 truncate">{bikeType}</span>
                      </div>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    </div>

                    {showBikeTypeDropdown && (
                      <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50">
                        {bikeTypeOptions.map(bt => (
                          <button
                            key={bt}
                            type="button"
                            onClick={() => {
                              setBikeType(bt);
                              setShowBikeTypeDropdown(false);
                            }}
                            className="w-full text-left px-3 py-1.5 text-xs hover:bg-orange-50 hover:text-orange-600 font-semibold"
                          >
                            {bt}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Search Bikes Button */}
                  <div className="lg:col-span-3">
                    <button
                      type="submit"
                      className="w-full h-[52px] bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold rounded-xl flex items-center justify-center space-x-2 shadow-lg shadow-orange-500/30 transition-all active:scale-95 cursor-pointer text-sm"
                    >
                      <Search className="w-4 h-4 text-white" />
                      <span>Search Bikes</span>
                    </button>
                  </div>

                </div>
              )}

              {/* LIVE SEARCH SUGGESTIONS PANEL (Sections 10, 11, 14) */}
              {showSuggestions && (
                <div className="absolute top-full left-0 right-0 mt-3 bg-white rounded-2xl shadow-2xl border border-slate-200/90 overflow-hidden z-50 p-4 sm:p-5 text-slate-800 max-h-[85vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
                  
                  {/* Dynamic suggestions header if typing */}
                  {currentSearchText.trim() && liveSuggestions.length > 0 && (
                    <div className="mb-4">
                      <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center space-x-1.5">
                        <Search className="w-3.5 h-3.5 text-orange-600" />
                        <span>Matching Suggestions</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                        {liveSuggestions.map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => handleSelectSuggestion(item)}
                            className="w-full text-left p-2.5 rounded-xl hover:bg-orange-50/80 transition-colors flex items-center justify-between group border border-transparent hover:border-orange-100"
                          >
                            <div className="min-w-0 pr-2">
                              <span className="block text-xs font-bold text-slate-800 group-hover:text-orange-600 truncate">
                                {item.title}
                              </span>
                              {item.subtitle && (
                                <span className="block text-[10px] text-slate-400 truncate">
                                  {item.subtitle}
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] font-bold text-orange-600 uppercase px-2 py-0.5 rounded bg-orange-100/60 shrink-0">
                              {item.category}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Section A: Recent Searches (Sections 12, 14) */}
                  {recentSearches.length > 0 && (
                    <div className="mb-4">
                      <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                        <div className="flex items-center space-x-1.5">
                          <History className="w-3.5 h-3.5 text-slate-500" />
                          <span>Recent Searches</span>
                        </div>
                        <button
                          type="button"
                          onClick={handleClearAllRecentSearches}
                          className="text-orange-600 hover:text-orange-700 text-[11px] lowercase first-letter:uppercase font-bold"
                        >
                          Clear All
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                        {recentSearches.map((rs) => (
                          <div
                            key={rs.id}
                            onClick={() => {
                              setShowSuggestions(false);
                              setActiveTab(rs.category);
                              if (rs.destination) setDestination(rs.destination);
                              onSearch(rs.params as UnifiedSearchParams);
                            }}
                            className="p-2.5 rounded-xl bg-slate-50 hover:bg-orange-50 border border-slate-200/60 hover:border-orange-200 transition-all flex items-center justify-between cursor-pointer group"
                          >
                            <div className="min-w-0 flex-1">
                              <span className="block text-xs font-bold text-slate-800 group-hover:text-orange-600 truncate">
                                {rs.label}
                              </span>
                              <span className="block text-[10px] text-slate-400 truncate">
                                {rs.subtitle || `${rs.category.toUpperCase()} • ${rs.destination || 'Digha'}`}
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={(e) => handleRemoveRecentSearch(e, rs.id)}
                              className="w-6 h-6 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-700 flex items-center justify-center shrink-0 ml-2 text-xs"
                              aria-label="Remove search"
                            >
                              ✕
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Section B: Top Destinations */}
                  <div className="mb-4">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center space-x-1.5">
                      <Map className="w-3.5 h-3.5 text-blue-900" />
                      <span>Destinations</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {TOP_DESTINATIONS.map(dest => (
                        <button
                          key={dest.name}
                          type="button"
                          onClick={() => {
                            setDestination(dest.label);
                            setTourDestination(dest.name);
                            setActivityDestination(dest.name);
                            setShowSuggestions(false);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-orange-50 hover:text-orange-600 text-slate-700 text-xs font-semibold transition-colors flex items-center space-x-1"
                        >
                          <MapPin className="w-3 h-3 text-slate-400" />
                          <span>{dest.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Section C: Categories */}
                  <div>
                    <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center space-x-1.5">
                      <Layers className="w-3.5 h-3.5 text-slate-500" />
                      <span>Categories</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                      {tabs.map(t => {
                        const Icon = t.icon;
                        return (
                          <button
                            key={t.id}
                            type="button"
                            onClick={() => {
                              setActiveTab(t.id);
                              setShowSuggestions(false);
                            }}
                            className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center justify-center space-y-1 ${
                              activeTab === t.id
                                ? 'bg-orange-50 border-orange-300 text-orange-600 font-bold'
                                : 'bg-slate-50 border-slate-200/60 text-slate-700 hover:bg-slate-100'
                            }`}
                          >
                            <Icon className="w-4 h-4" />
                            <span className="text-xs">{t.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                </div>
              )}

            </div>

          </form>

          {/* Popular Searches Row (Exact Replica of Reference - Section 10) */}
          <div className="mt-4 pt-3.5 border-t border-slate-100 flex flex-wrap items-center gap-2 text-xs">
            <span className="font-semibold text-slate-500 mr-1 shrink-0 flex items-center space-x-1">
              <TrendingUp className="w-3.5 h-3.5 text-orange-600" />
              <span>Popular Searches:</span>
            </span>
            <div className="flex flex-wrap items-center gap-1.5">
              {POPULAR_SEARCH_TERMS.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => handlePopularSearchClick(tag)}
                  className="px-3 py-1 rounded-full bg-slate-100 hover:bg-orange-50 hover:text-orange-600 text-slate-600 font-medium text-xs transition-colors border border-transparent hover:border-orange-200 cursor-pointer"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
