import React, { useState } from 'react';
import {
  ArrowLeft,
  Headphones,
  Phone,
  Mail,
  HelpCircle,
  Clock,
  MapPin,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Send,
  MessageSquare,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { BUSINESS_INFO } from '../data/mockData';
import { StorageService } from '../services/storage';

interface SupportViewProps {
  onBackToHome: () => void;
  onExplorePackages: () => void;
}

export const SupportView: React.FC<SupportViewProps> = ({
  onBackToHome,
  onExplorePackages
}) => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [enquirySuccess, setEnquirySuccess] = useState(false);

  const faqs = [
    {
      q: 'How do I book a hotel or tour package with GoDigha?',
      a: 'You can easily browse hotels, cabs, holiday packages, and watersports on our platform. Select your preferred dates and room/vehicle option, tap "Book Now", and complete instant confirmation with zero hidden fees.'
    },
    {
      q: 'What is the check-in and check-out time for hotels?',
      a: 'Standard hotel check-in across partner hotels in Old Digha, New Digha, and Mandarmani is 11:00 AM, and check-out is 10:00 AM. Early check-in or late check-out is subject to room availability upon request.'
    },
    {
      q: 'Can I cancel or reschedule my booking?',
      a: 'Yes, most hotels and packages offer free cancellation up to 48 to 72 hours before arrival. You can request a cancellation directly from your Trips/Account dashboard or contact our 24/7 helpdesk.'
    },
    {
      q: 'Where do the cabs pick up passengers?',
      a: 'Our AC cabs provide doorstep pickup and drop from Digha Railway Station, Contai, Old/New Digha hotel lobbies, Mandarmani resorts, or direct outstation pickups from Kolkata/Howrah.'
    },
    {
      q: 'Are water sports and beach bike rentals safe in Mandarmani & Digha?',
      a: 'All our water sports (Jet Ski, Banana boat, Parasailing) are supervised by certified marine instructors with mandated life vests and coast guard safety compliance. Rental bikes include two verified helmets.'
    }
  ];

  const handleEnquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !message.trim()) return;

    StorageService.saveEnquiry({
      id: `enq_${Date.now()}`,
      name,
      phone,
      email: `${name.toLowerCase().replace(/\s+/g, '')}@customer.com`,
      type: 'GENERAL',
      destination: 'Digha / Mandarmani',
      travelDates: 'Upcoming Trip',
      travellersCount: 2,
      budgetRange: 'Standard',
      transportRequired: false,
      hotelRequired: false,
      foodRequired: false,
      activitiesRequired: false,
      message,
      status: 'NEW',
      createdAt: new Date().toISOString()
    });

    setEnquirySuccess(true);
    setName('');
    setPhone('');
    setMessage('');
    setTimeout(() => setEnquirySuccess(false), 6000);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-24 md:pb-16">
      
      {/* Top Header Bar */}
      <div className="bg-white border-b border-slate-200 sticky top-16 md:top-18 lg:top-20 z-30 shadow-xs">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between">
          <button
            onClick={onBackToHome}
            className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm transition-colors active:scale-95"
          >
            <ArrowLeft className="w-4 h-4 text-slate-600" />
            <span>Back to Home</span>
          </button>
          
          <div className="text-right">
            <span className="text-xs font-black text-slate-900 uppercase tracking-wider block">Customer Support</span>
            <span className="text-[10px] text-emerald-600 font-bold flex items-center justify-end space-x-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping inline-block" />
              <span>Agents Live & Available</span>
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8 space-y-6">
        
        {/* Hero Card */}
        <div className="bg-gradient-to-br from-[#061527] to-[#0c2a4d] rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-xl">
          <div className="relative z-10 max-w-xl space-y-3">
            <div className="inline-flex items-center space-x-2 text-xs font-bold text-amber-400 uppercase tracking-widest bg-white/10 px-3 py-1 rounded-full backdrop-blur-xs">
              <Headphones className="w-3.5 h-3.5" />
              <span>GoDigha 24x7 Help Center</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight font-heading">
              How can we help you today?
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Whether you need hotel room assistance, emergency cab dispatch, trip rescheduling, or watersports guidance in Digha and Mandarmani, our local team is ready to assist.
            </p>
          </div>
          <div className="absolute -right-12 -bottom-12 w-48 h-48 rounded-full bg-orange-500/10 blur-2xl" />
        </div>

        {/* Quick Contact Grid (Section 4) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
          
          {/* Option 1: WhatsApp Support */}
          <a
            href={BUSINESS_INFO.whatsappDirectLink}
            target="_blank"
            rel="noreferrer"
            className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-emerald-400 hover:shadow-lg transition-all group flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.77-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86.173.086.275.072.376-.044.101-.116.433-.506.549-.68.116-.173.231-.145.39-.086s1.011.477 1.184.564.289.13.332.203c.044.072.044.419-.1.824z" />
                </svg>
              </div>
              <h3 className="font-bold text-slate-900 text-sm">WhatsApp Support</h3>
              <p className="text-xs text-slate-500 mt-1">Chat directly with local concierge for instant quotes & bookings.</p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-bold text-emerald-600 flex items-center justify-between">
              <span>Chat on WhatsApp</span>
              <span>→</span>
            </div>
          </a>

          {/* Option 2: Call GoDigha */}
          <a
            href={`tel:${BUSINESS_INFO.phone}`}
            className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-orange-400 hover:shadow-lg transition-all group flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                <Phone className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 text-sm">Call GoDigha</h3>
              <p className="text-xs text-slate-500 mt-1">24x7 phone helpline with direct Bengali, Hindi & English support.</p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-bold text-orange-600 flex items-center justify-between">
              <span>{BUSINESS_INFO.phoneFormatted}</span>
              <span>→</span>
            </div>
          </a>

          {/* Option 3: Email Support */}
          <a
            href={`mailto:${BUSINESS_INFO.officialSupportEmail}`}
            className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-blue-400 hover:shadow-lg transition-all group flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-900 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                <Mail className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 text-sm">Email Support</h3>
              <p className="text-xs text-slate-500 mt-1">For corporate bookings, invoices, official quotes & refunds.</p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-bold text-blue-900 flex items-center justify-between">
              <span>{BUSINESS_INFO.officialSupportEmail}</span>
              <span>→</span>
            </div>
          </a>

        </div>

        {/* Quick Message / Enquiry Form */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-xs">
          <div className="flex items-center space-x-2 text-xs font-bold text-blue-900 uppercase tracking-wider mb-1">
            <MessageSquare className="w-4 h-4" />
            <span>Send a Message</span>
          </div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900 font-heading">
            Contact GoDigha Desk
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Leave your question and our operations team will call or reply on WhatsApp within 15 minutes.
          </p>

          {enquirySuccess && (
            <div className="mt-4 p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-bold flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Thank you! Your message has been received. Our coordinator will contact you shortly.</span>
            </div>
          )}

          <form onSubmit={handleEnquirySubmit} className="mt-4 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">Your Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Samir Roy"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium focus:outline-none focus:border-orange-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">Mobile / WhatsApp Number</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. +91 98301 24567"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">How can we assist you?</label>
              <textarea
                required
                rows={3}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Ask about hotels, cabs from Digha station, Mandarmani resorts, or special holiday requests..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium focus:outline-none focus:border-orange-500"
              />
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-xs sm:text-sm shadow-md shadow-orange-500/25 active:scale-95 transition-all flex items-center space-x-2"
            >
              <Send className="w-4 h-4" />
              <span>Send Message</span>
            </button>
          </form>
        </div>

        {/* Frequently Asked Questions */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-xs space-y-4">
          <div className="flex items-center space-x-2 text-xs font-bold text-blue-900 uppercase tracking-wider">
            <HelpCircle className="w-4 h-4" />
            <span>Frequently Asked Questions</span>
          </div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900 font-heading">
            Common Travel Queries
          </h2>

          <div className="space-y-2.5 pt-1">
            {faqs.map((faq, index) => {
              const isOpen = openFaq === index;
              return (
                <div
                  key={index}
                  className="rounded-2xl border border-slate-200/80 overflow-hidden transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => setOpenFaq(isOpen ? null : index)}
                    className="w-full text-left p-4 bg-slate-50/70 hover:bg-slate-100 flex items-center justify-between gap-3 text-xs sm:text-sm font-bold text-slate-800"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? (
                      <ChevronUp className="w-4 h-4 text-orange-600 shrink-0" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="p-4 bg-white text-xs text-slate-600 leading-relaxed border-t border-slate-100">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Official Office Details */}
        <div className="p-5 rounded-2xl bg-slate-100/80 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-600">
          <div className="space-y-0.5">
            <div className="font-bold text-slate-900 flex items-center space-x-1.5">
              <MapPin className="w-3.5 h-3.5 text-orange-600" />
              <span>{BUSINESS_INFO.address}</span>
            </div>
            <div className="text-[11px] text-slate-500">
              Hours: {BUSINESS_INFO.businessHours} • Google Rating: ⭐ 5.0 (22+ Verified Reviews)
            </div>
          </div>
          <button
            onClick={onExplorePackages}
            className="self-start sm:self-auto px-4 py-2 rounded-xl bg-[#0f2847] hover:bg-blue-900 text-amber-300 font-bold text-xs shrink-0 shadow-xs"
          >
            Explore Packages
          </button>
        </div>

      </div>
    </div>
  );
};
