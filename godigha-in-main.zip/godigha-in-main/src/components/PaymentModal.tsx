import React, { useState, useEffect } from 'react';
import { Booking, PaymentTransaction } from '../types';
import { StorageService } from '../services/storage';
import {
  ShieldCheck,
  Lock,
  QrCode,
  Smartphone,
  CreditCard,
  Building,
  CheckCircle2,
  Printer,
  Download,
  AlertCircle,
  Clock,
  ArrowRight,
  X,
  Sparkles,
  MapPin,
  Calendar,
  Users,
  RotateCcw,
  Check,
  ChevronRight
} from 'lucide-react';
import { BUSINESS_INFO } from '../data/mockData';
import { InvoiceModal } from './InvoiceModal';

interface PaymentModalProps {
  bookingData: Partial<Booking>;
  onClose: () => void;
  onBookingSuccess: (confirmedBooking: Booking) => void;
  onViewBookingInAccount?: (bookingId: string) => void;
}

type PaymentMethodType = 'UPI' | 'CARD' | 'NETBANKING' | 'WALLET';
type PaymentFlowState =
  | 'SUMMARY'
  | 'INITIALIZING_ORDER'
  | 'CHECKOUT_SELECTION'
  | 'PROCESSING_GATEWAY'
  | 'SUCCESS_CONFIRMED'
  | 'FAILED'
  | 'CANCELLED';

export const PaymentModal: React.FC<PaymentModalProps> = ({
  bookingData,
  onClose,
  onBookingSuccess,
  onViewBookingInAccount
}) => {
  const [step, setStep] = useState<PaymentFlowState>('SUMMARY');
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethodType>('UPI');
  const [orderData, setOrderData] = useState<any>(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);

  // Form Details for Payment Methods
  const [upiOption, setUpiOption] = useState<'GPAY' | 'PHONEPE' | 'PAYTM' | 'CUSTOM'>('GPAY');
  const [customUpiId, setCustomUpiId] = useState('');

  const [cardNumber, setCardNumber] = useState('4532 8901 2345 6789');
  const [cardExpiry, setCardExpiry] = useState('08/28');
  const [cardCvv, setCardCvv] = useState('829');
  const [cardName, setCardName] = useState(bookingData.customerName || 'Rahul Banerjee');

  const [selectedBank, setSelectedBank] = useState('HDFC Bank');
  const [selectedWallet, setSelectedWallet] = useState('Paytm');

  const finalAmount = bookingData.totalAmount || 3499;

  // Initialize payment order on backend
  const handleProceedToPayment = async () => {
    setStep('INITIALIZING_ORDER');
    setErrorMessage('');

    try {
      const response = await fetch('/api/payments/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: finalAmount,
          currency: 'INR',
          bookingId: bookingData.id || `GD-BK-${Date.now()}`,
          customerId: bookingData.customerId,
          vendorId: bookingData.vendorId,
          notes: {
            itemTitle: bookingData.itemTitle,
            travelDate: bookingData.travelDate,
            customerEmail: bookingData.customerEmail
          }
        })
      });

      const data = await response.json();
      if (data.success && data.order) {
        setOrderData(data.order);
        setStep('CHECKOUT_SELECTION');
      } else {
        // Fallback local order structure
        setOrderData({
          id: `order_${Date.now()}`,
          amount: finalAmount * 100,
          currency: 'INR',
          status: 'created'
        });
        setStep('CHECKOUT_SELECTION');
      }
    } catch (err) {
      console.warn('Backend order init fallback:', err);
      setOrderData({
        id: `order_${Date.now()}`,
        amount: finalAmount * 100,
        currency: 'INR',
        status: 'created'
      });
      setStep('CHECKOUT_SELECTION');
    }
  };

  // Execute payment & verify server-side
  const handleExecutePayment = async () => {
    setStep('PROCESSING_GATEWAY');
    setErrorMessage('');

    const orderId = orderData?.id || `order_${Date.now()}`;
    const paymentId = `pay_rzp_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 6)}`;
    const mockSignature = `sig_test_${Date.now()}_verified`;

    // Simulate bank authorization delay
    setTimeout(async () => {
      try {
        const verifyRes = await fetch('/api/payments/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            razorpay_order_id: orderId,
            razorpay_payment_id: paymentId,
            razorpay_signature: mockSignature,
            bookingId: bookingData.id || `GD-BK-${Date.now()}`,
            method: selectedMethod
          })
        });

        const verifyData = await verifyRes.json();

        if (verifyData.success) {
          // Construct finalized Booking
          const fullBooking: Booking = {
            id: bookingData.id || `GD-BK-2026-${Math.floor(1000 + Math.random() * 9000)}`,
            customerId: bookingData.customerId || 'user_cust_01',
            customerName: bookingData.customerName || 'Rahul Banerjee',
            customerEmail: bookingData.customerEmail || 'rahul.b@example.com',
            customerPhone: bookingData.customerPhone || '+91 88491 25029',
            bookingType: bookingData.bookingType || 'PACKAGE',
            itemId: bookingData.itemId || 'pkg_digha',
            itemTitle: bookingData.itemTitle || 'Digha Coastal Beach Holiday',
            itemSubtitle: bookingData.itemSubtitle || 'AC Accommodation Included',
            itemImage: bookingData.itemImage,
            vendorId: bookingData.vendorId,
            travelDate: bookingData.travelDate || '2026-10-15',
            returnDate: bookingData.returnDate,
            travellers: bookingData.travellers || 2,
            guests: bookingData.guests || [],
            baseAmount: bookingData.baseAmount || finalAmount - 350,
            taxAmount: bookingData.taxAmount || 350,
            discountAmount: bookingData.discountAmount || 0,
            goCashUsed: bookingData.goCashUsed || 0,
            totalAmount: finalAmount,
            paymentStatus: 'PAID',
            bookingStatus: 'CONFIRMED',
            paymentId,
            orderId,
            createdAt: new Date().toISOString()
          };

          // Save confirmed booking in storage
          StorageService.saveBooking(fullBooking);

          // Save payment transaction record
          const tx: PaymentTransaction = {
            id: `tx_${Date.now()}`,
            paymentId,
            orderId,
            bookingId: fullBooking.id,
            userId: fullBooking.customerId,
            amount: fullBooking.totalAmount,
            currency: 'INR',
            method: selectedMethod,
            status: 'PAID',
            date: new Date().toISOString(),
            itemTitle: fullBooking.itemTitle,
            refundStatus: 'NONE'
          };
          StorageService.savePaymentTransaction(tx);

          // Add notification
          const cashbackEarned = Math.round(fullBooking.totalAmount * 0.05);
          StorageService.addNotification({
            userId: fullBooking.customerId,
            title: 'Payment Successful & Booking Confirmed!',
            message: `Payment of ₹${fullBooking.totalAmount} for ${fullBooking.itemTitle} was captured. ₹${cashbackEarned} GoCash has been credited to your wallet.`,
            type: 'PAYMENT',
            read: false,
            linkTab: 'bookings'
          });

          setConfirmedBooking(fullBooking);
          setStep('SUCCESS_CONFIRMED');
          onBookingSuccess(fullBooking);
        } else {
          setErrorMessage('Bank signature verification failed. Please try again.');
          setStep('FAILED');
        }
      } catch (err) {
        console.error('Payment verification error:', err);
        setErrorMessage('Connection error during payment verification. Please try again.');
        setStep('FAILED');
      }
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative animate-in fade-in zoom-in-95 duration-200 text-slate-800 my-8">
        
        {/* Close Button */}
        {step !== 'PROCESSING_GATEWAY' && (
          <button
            onClick={() => {
              if (step === 'SUCCESS_CONFIRMED') {
                onClose();
              } else if (step === 'CHECKOUT_SELECTION') {
                setStep('SUMMARY');
              } else {
                onClose();
              }
            }}
            className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-sm transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* ----------------------------------------------------------- */}
        {/* STEP 1: BOOKING SUMMARY & PRICE BREAKDOWN */}
        {/* ----------------------------------------------------------- */}
        {step === 'SUMMARY' && (
          <div className="space-y-6">
            <div>
              <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-orange-600 mb-1">
                <ShieldCheck className="w-4 h-4 text-orange-600" />
                <span>Secure Checkout</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-heading">
                Booking Summary
              </h2>
              <p className="text-xs text-slate-500">
                Please review your travel details before proceeding to payment.
              </p>
            </div>

            {/* Service & Traveller Details Card */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 text-xs">
              <div className="font-bold text-sm text-slate-900 font-heading">
                {bookingData.itemTitle || 'GoDigha Tour Package'}
              </div>

              <div className="grid grid-cols-2 gap-2 text-slate-600">
                <div className="flex items-center space-x-1.5">
                  <Calendar className="w-3.5 h-3.5 text-orange-600" />
                  <span>Dates: <strong>{bookingData.travelDate}</strong></span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <Users className="w-3.5 h-3.5 text-blue-600" />
                  <span>Travellers: <strong>{bookingData.travellers} Guests</strong></span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200/80 text-[11px] text-slate-500 space-y-0.5">
                <div>Lead Guest: <span className="font-semibold text-slate-800">{bookingData.customerName}</span></div>
                <div>Contact: <span className="font-semibold text-slate-800">{bookingData.customerPhone}</span> • <span>{bookingData.customerEmail}</span></div>
              </div>
            </div>

            {/* Itemized Price Breakdown */}
            <div className="border border-slate-200 rounded-2xl p-4 space-y-2.5 text-xs">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                Price Breakdown
              </div>

              <div className="flex justify-between text-slate-600">
                <span>Base Package / Room Price</span>
                <span className="font-semibold">
                  ₹{(bookingData.baseAmount || finalAmount - 350).toLocaleString('en-IN')}
                </span>
              </div>

              <div className="flex justify-between text-slate-600">
                <span>GST (18% Tourism / Hospitality)</span>
                <span className="font-semibold">
                  ₹{(bookingData.taxAmount || 350).toLocaleString('en-IN')}
                </span>
              </div>

              {(bookingData.discountAmount || 0) > 0 && (
                <div className="flex justify-between text-emerald-600 font-semibold">
                  <span>Special Discount</span>
                  <span>-₹{(bookingData.discountAmount || 0).toLocaleString('en-IN')}</span>
                </div>
              )}

              {(bookingData.goCashUsed || 0) > 0 && (
                <div className="flex justify-between text-amber-600 font-semibold">
                  <span>GoCash Redeemed</span>
                  <span>-₹{(bookingData.goCashUsed || 0).toLocaleString('en-IN')}</span>
                </div>
              )}

              <div className="pt-2 border-t border-slate-200 flex justify-between items-center text-sm font-black text-slate-900">
                <span>Final Payable Amount</span>
                <span className="text-xl font-black text-orange-600 font-heading">
                  ₹{finalAmount.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            {/* Proceed to Payment Action */}
            <button
              onClick={handleProceedToPayment}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-sm shadow-lg shadow-orange-500/25 transition-all active:scale-98 flex items-center justify-center space-x-2 cursor-pointer"
            >
              <span>Proceed to Payment (₹{finalAmount.toLocaleString('en-IN')})</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center space-x-2 text-[11px] text-slate-400">
              <Lock className="w-3 h-3 text-emerald-600" />
              <span>256-bit SSL encrypted • Authorized Gateway Partner</span>
            </div>
          </div>
        )}

        {/* ----------------------------------------------------------- */}
        {/* STEP 2: INITIALIZING ORDER SPINNER */}
        {/* ----------------------------------------------------------- */}
        {step === 'INITIALIZING_ORDER' && (
          <div className="py-12 text-center space-y-4">
            <div className="w-12 h-12 border-3 border-orange-600 border-t-transparent rounded-full animate-spin mx-auto" />
            <div>
              <h3 className="text-base font-bold text-slate-900">Creating Secure Payment Session...</h3>
              <p className="text-xs text-slate-500 mt-1">Connecting to banking gateway</p>
            </div>
          </div>
        )}

        {/* ----------------------------------------------------------- */}
        {/* STEP 3: CHECKOUT GATEWAY SELECTION (UPI, CARDS, NETBANKING) */}
        {/* ----------------------------------------------------------- */}
        {step === 'CHECKOUT_SELECTION' && (
          <div className="space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-black text-slate-900 font-heading">
                  Select Payment Method
                </h3>
                <span className="text-xs text-slate-500">Order ID: {orderData?.id}</span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-400 block uppercase font-bold">Payable</span>
                <span className="text-base font-black text-orange-600 font-heading">
                  ₹{finalAmount.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            {/* Payment Method Selector Tabs */}
            <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 rounded-xl text-xs font-bold text-slate-600">
              <button
                type="button"
                onClick={() => setSelectedMethod('UPI')}
                className={`py-2 rounded-lg transition-all flex flex-col items-center justify-center space-y-1 ${
                  selectedMethod === 'UPI' ? 'bg-white text-orange-600 shadow-xs' : ''
                }`}
              >
                <Smartphone className="w-4 h-4" />
                <span className="text-[10px]">UPI</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedMethod('CARD')}
                className={`py-2 rounded-lg transition-all flex flex-col items-center justify-center space-y-1 ${
                  selectedMethod === 'CARD' ? 'bg-white text-orange-600 shadow-xs' : ''
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span className="text-[10px]">Card</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedMethod('NETBANKING')}
                className={`py-2 rounded-lg transition-all flex flex-col items-center justify-center space-y-1 ${
                  selectedMethod === 'NETBANKING' ? 'bg-white text-orange-600 shadow-xs' : ''
                }`}
              >
                <Building className="w-4 h-4" />
                <span className="text-[10px]">NetBanking</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedMethod('WALLET')}
                className={`py-2 rounded-lg transition-all flex flex-col items-center justify-center space-y-1 ${
                  selectedMethod === 'WALLET' ? 'bg-white text-orange-600 shadow-xs' : ''
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span className="text-[10px]">Wallets</span>
              </button>
            </div>

            {/* UPI Section */}
            {selectedMethod === 'UPI' && (
              <div className="space-y-3.5">
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setUpiOption('GPAY')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      upiOption === 'GPAY'
                        ? 'border-orange-500 bg-orange-50/50 text-orange-950 font-bold'
                        : 'border-slate-200 text-slate-700'
                    }`}
                  >
                    <span className="block text-xs font-bold">Google Pay</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setUpiOption('PHONEPE')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      upiOption === 'PHONEPE'
                        ? 'border-orange-500 bg-orange-50/50 text-orange-950 font-bold'
                        : 'border-slate-200 text-slate-700'
                    }`}
                  >
                    <span className="block text-xs font-bold">PhonePe</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setUpiOption('PAYTM')}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      upiOption === 'PAYTM'
                        ? 'border-orange-500 bg-orange-50/50 text-orange-950 font-bold'
                        : 'border-slate-200 text-slate-700'
                    }`}
                  >
                    <span className="block text-xs font-bold">Paytm UPI</span>
                  </button>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    Or Enter Custom UPI ID / VPA
                  </label>
                  <div className="flex">
                    <input
                      type="text"
                      value={customUpiId}
                      onChange={(e) => setCustomUpiId(e.target.value)}
                      placeholder="e.g. mobile@okhdfcbank"
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-l-xl text-xs font-medium focus:outline-none focus:ring-1 focus:ring-orange-500"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (customUpiId.includes('@')) setUpiOption('CUSTOM');
                        else alert('Please enter a valid UPI ID (e.g. yourname@okaxis)');
                      }}
                      className="px-3 bg-slate-800 text-white font-bold text-xs rounded-r-xl"
                    >
                      Verify
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Cards Section */}
            {selectedMethod === 'CARD' && (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Card Number</label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-slate-900 font-bold"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Valid Thru</label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      placeholder="MM/YY"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-slate-900 font-bold"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">CVV</label>
                    <input
                      type="password"
                      maxLength={4}
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                      placeholder="•••"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-slate-900 font-bold"
                    />
                  </div>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Name on Card</label>
                  <input
                    type="text"
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900"
                  />
                </div>
              </div>
            )}

            {/* Net Banking Section */}
            {selectedMethod === 'NETBANKING' && (
              <div className="space-y-2 text-xs">
                <label className="font-bold text-slate-700 block mb-1">Select Bank</label>
                {['HDFC Bank', 'State Bank of India', 'ICICI Bank', 'Axis Bank', 'Kotak Mahindra Bank', 'Punjab National Bank'].map((bank) => (
                  <button
                    key={bank}
                    type="button"
                    onClick={() => setSelectedBank(bank)}
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                      selectedBank === bank
                        ? 'border-orange-500 bg-orange-50/50 font-bold text-orange-950'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>{bank}</span>
                    {selectedBank === bank && <Check className="w-4 h-4 text-orange-600" />}
                  </button>
                ))}
              </div>
            )}

            {/* Wallets Section */}
            {selectedMethod === 'WALLET' && (
              <div className="space-y-2 text-xs">
                <label className="font-bold text-slate-700 block mb-1">Select Wallet</label>
                {['Paytm Wallet', 'PhonePe Wallet', 'Amazon Pay', 'MobiKwik'].map((wallet) => (
                  <button
                    key={wallet}
                    type="button"
                    onClick={() => setSelectedWallet(wallet)}
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                      selectedWallet === wallet
                        ? 'border-orange-500 bg-orange-50/50 font-bold text-orange-950'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>{wallet}</span>
                    {selectedWallet === wallet && <Check className="w-4 h-4 text-orange-600" />}
                  </button>
                ))}
              </div>
            )}

            {/* Submit Action Button */}
            <button
              onClick={handleExecutePayment}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-sm shadow-lg shadow-orange-500/25 transition-all active:scale-98 flex items-center justify-center space-x-2 cursor-pointer"
            >
              <Lock className="w-4 h-4" />
              <span>Pay ₹{finalAmount.toLocaleString('en-IN')} Securely</span>
            </button>

            <button
              type="button"
              onClick={() => setStep('SUMMARY')}
              className="w-full text-center text-xs font-semibold text-slate-400 hover:text-slate-600"
            >
              Back to Booking Summary
            </button>
          </div>
        )}

        {/* ----------------------------------------------------------- */}
        {/* STEP 4: PROCESSING BANK GATEWAY DIALOG */}
        {/* ----------------------------------------------------------- */}
        {step === 'PROCESSING_GATEWAY' && (
          <div className="py-12 text-center space-y-4">
            <div className="relative w-16 h-16 mx-auto">
              <div className="w-16 h-16 border-4 border-slate-200 border-t-orange-600 rounded-full animate-spin" />
              <ShieldCheck className="w-7 h-7 text-orange-600 absolute inset-0 m-auto" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900 font-heading">
                Processing Payment...
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                Authorizing with payment gateway. Please do not refresh or press back.
              </p>
            </div>
            <div className="text-[11px] font-mono text-slate-400">
              Verifying cryptographic HMAC signature...
            </div>
          </div>
        )}

        {/* ----------------------------------------------------------- */}
        {/* STEP 5: SUCCESS CONFIRMATION SCREEN (Section 17) */}
        {/* ----------------------------------------------------------- */}
        {step === 'SUCCESS_CONFIRMED' && confirmedBooking && (
          <div className="text-center space-y-5">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md ring-8 ring-emerald-50 animate-in zoom-in duration-300">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <h2 className="text-2xl font-black text-slate-900 font-heading">
                Payment Successful!
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Your GoDigha booking has been confirmed.
              </p>
            </div>

            {/* Booking Details Card */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-left space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Booking ID:</span>
                <span className="font-bold text-slate-900 font-mono">{confirmedBooking.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Destination / Package:</span>
                <span className="font-bold text-slate-900 text-right">{confirmedBooking.itemTitle}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Travel Dates:</span>
                <span className="font-semibold text-slate-800">{confirmedBooking.travelDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Travellers:</span>
                <span className="font-semibold text-slate-800">{confirmedBooking.travellers} Guests</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Amount Paid:</span>
                <span className="font-black text-emerald-600 text-sm font-heading">
                  ₹{confirmedBooking.totalAmount.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-200/80 text-[11px]">
                <span className="text-slate-400">Payment ID:</span>
                <span className="font-mono text-slate-600">{confirmedBooking.paymentId}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2.5">
              <button
                onClick={() => setShowInvoiceModal(true)}
                className="w-full py-2.5 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center space-x-2 transition-colors shadow-md shadow-orange-500/20"
              >
                <Download className="w-4 h-4" />
                <span>Download Invoice</span>
              </button>

              <button
                onClick={() => {
                  onClose();
                  if (onViewBookingInAccount) {
                    onViewBookingInAccount(confirmedBooking.id);
                  }
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs sm:text-sm transition-colors"
              >
                View My Booking in Account
              </button>

              <button
                onClick={onClose}
                className="w-full py-2 text-xs font-semibold text-slate-400 hover:text-slate-600"
              >
                Back to Dashboard
              </button>
            </div>
          </div>
        )}

        {/* ----------------------------------------------------------- */}
        {/* STEP 6: FAILED SCREEN (Section 18) */}
        {/* ----------------------------------------------------------- */}
        {step === 'FAILED' && (
          <div className="text-center space-y-5">
            <div className="w-16 h-16 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto shadow-md ring-8 ring-red-50">
              <AlertCircle className="w-10 h-10" />
            </div>

            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-heading">
                Payment Could Not Be Completed
              </h2>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Your payment was not completed. No booking will be marked as confirmed unless payment verification succeeds.
              </p>
            </div>

            {errorMessage && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
                {errorMessage}
              </div>
            )}

            <div className="space-y-2.5">
              <button
                onClick={() => setStep('CHECKOUT_SELECTION')}
                className="w-full py-3 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm shadow-md transition-colors"
              >
                Try Payment Again
              </button>

              <button
                onClick={() => setStep('SUMMARY')}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
              >
                Return to Booking Summary
              </button>
            </div>
          </div>
        )}

      </div>

      {/* Invoice Modal Preview */}
      {showInvoiceModal && confirmedBooking && (
        <InvoiceModal
          booking={confirmedBooking}
          onClose={() => setShowInvoiceModal(false)}
        />
      )}

    </div>
  );
};
