import React from 'react';
import { Phone, MessageSquare } from 'lucide-react';
import { BUSINESS_INFO } from '../data/mockData';

export const WhatsAppRibbon: React.FC = () => {
  return (
    <div className="sticky top-16 md:top-18 z-30 bg-gradient-to-r from-orange-600 via-orange-500 to-amber-600 text-white shadow-md border-b border-orange-700/30">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-2">
        
        {/* WhatsApp & Contact Demo Info */}
        <a
          href={BUSINESS_INFO.whatsappDirectLink}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center space-x-2 text-white hover:text-amber-100 transition-transform active:scale-95 group"
        >
          {/* Green WhatsApp Icon Emblem */}
          <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-emerald-500 flex items-center justify-center shadow-md group-hover:scale-110 transition-transform">
            <svg
              className="w-4 h-4 sm:w-5 sm:h-5 fill-current text-white"
              viewBox="0 0 24 24"
            >
              <path d="M12.031 2C6.495 2 2 6.495 2 12.031c0 1.97.57 3.81 1.558 5.373L2 22l4.757-1.523A9.97 9.97 0 0012.03 22c5.536 0 10.031-4.495 10.031-10.031C22.062 6.495 17.567 2 12.031 2zm5.748 14.338c-.244.686-1.42 1.31-1.973 1.365-.515.05-1.18.077-3.79-1.002-3.153-1.303-5.166-4.526-5.324-4.737-.158-.211-1.282-1.706-1.282-3.254 0-1.548.813-2.31 1.103-2.627.29-.317.633-.396.844-.396.211 0 .422.002.607.012.196.01.458-.074.717.548.264.633.9 2.195.979 2.353.079.158.132.343.026.554-.105.211-.158.343-.317.528-.158.185-.333.413-.475.554-.158.158-.323.33-.139.647.185.317.822 1.347 1.764 2.186 1.213 1.08 2.235 1.415 2.552 1.573.317.158.502.132.686-.079.185-.211.792-.924 1.003-1.241.211-.317.422-.264.712-.158.29.105 1.848.871 2.165 1.029.317.158.528.238.607.369.079.132.079.766-.165 1.452z" />
            </svg>
          </div>

          <span className="font-semibold text-xs sm:text-sm tracking-tight">
            <span className="opacity-90 font-medium">WhatsApp / Call :</span>{' '}
            <span className="underline decoration-white/40 font-bold">{BUSINESS_INFO.phoneFormatted}</span>
            <span className="hidden md:inline text-amber-200 ml-2 font-normal">
              ( 24x7 Assistance )
            </span>
          </span>
        </a>

        {/* Quick CTA Actions */}
        <div className="flex items-center space-x-2 text-xs font-medium">
          <a
            href={BUSINESS_INFO.whatsappDirectLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-1 bg-white text-orange-700 hover:bg-orange-50 px-2.5 py-1 rounded-full font-bold shadow-sm transition-all"
          >
            <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
            <span>Chat with Expert</span>
          </a>

          <a
            href={`tel:${BUSINESS_INFO.phone}`}
            className="hidden sm:inline-flex items-center space-x-1 bg-black/20 hover:bg-black/30 text-white px-2.5 py-1 rounded-full transition-colors"
          >
            <Phone className="w-3.5 h-3.5 text-amber-300" />
            <span>Instant Call</span>
          </a>
        </div>

      </div>
    </div>
  );
};
