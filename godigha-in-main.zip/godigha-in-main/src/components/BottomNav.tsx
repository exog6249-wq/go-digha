import React from 'react';
import { Home, Bed, Map, Headset, User as UserIcon } from 'lucide-react';
import { User } from '../types';

interface BottomNavProps {
  currentView: string;
  currentUser: User | null;
  onNavigate: (view: string) => void;
  onOpenLogin: () => void;
  customerActiveTab?: string;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentView,
  currentUser,
  onNavigate,
  onOpenLogin,
  customerActiveTab
}) => {
  // Determine active tab according to the current view / route (Route-Aware Active State)
  const isHomeActive = currentView === 'home' || currentView === '';
  const isHotelsActive = currentView === 'hotels';
  const isTripsActive = currentView === 'trips' || (currentView === 'customer' && customerActiveTab === 'trips');
  const isSupportActive = currentView === 'support';
  const isAccountActive = (currentView === 'customer' && customerActiveTab !== 'trips') || currentView === 'account';

  const handleAccountClick = () => {
    if (currentUser) {
      onNavigate('customer');
    } else {
      onOpenLogin();
    }
  };

  const navItems = [
    {
      id: 'home',
      label: 'Home',
      icon: Home,
      isActive: isHomeActive,
      onClick: () => onNavigate('home')
    },
    {
      id: 'hotels',
      label: 'Hotels',
      icon: Bed,
      isActive: isHotelsActive,
      onClick: () => onNavigate('hotels')
    },
    {
      id: 'trips',
      label: 'Trips',
      icon: Map,
      isActive: isTripsActive,
      onClick: () => onNavigate('trips')
    },
    {
      id: 'support',
      label: 'Support',
      icon: Headset,
      isActive: isSupportActive,
      onClick: () => onNavigate('support')
    },
    {
      id: 'account',
      label: 'Account',
      icon: UserIcon,
      isActive: isAccountActive,
      onClick: handleAccountClick
    }
  ];

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 bg-white/98 backdrop-blur-md border-t border-slate-200/90 shadow-[0_-4px_20px_rgba(0,0,0,0.06)] rounded-t-2xl sm:rounded-t-3xl lg:hidden select-none"
      style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 6px)' }}
      aria-label="Mobile Navigation"
    >
      <div className="max-w-md mx-auto px-2 pt-2 pb-1 flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = item.isActive;

          return (
            <button
              key={item.id}
              type="button"
              onClick={item.onClick}
              className="flex flex-col items-center justify-center flex-1 py-1 focus:outline-none transition-transform active:scale-95 group relative"
              aria-label={item.label}
              aria-current={active ? 'page' : undefined}
            >
              {/* Icon */}
              <div
                className={`transition-colors duration-200 flex items-center justify-center ${
                  active ? 'text-[#FF6E00]' : 'text-slate-600 group-hover:text-slate-900'
                }`}
              >
                <Icon
                  className="w-5 h-5 sm:w-[22px] sm:h-[22px] transition-transform duration-200"
                  strokeWidth={active ? 2.3 : 1.9}
                />
              </div>

              {/* Label underneath icon */}
              <span
                className={`text-[10px] sm:text-[11px] tracking-tight mt-1 transition-colors duration-200 leading-none ${
                  active
                    ? 'text-[#FF6E00] font-bold'
                    : 'text-slate-500 font-medium group-hover:text-slate-700'
                }`}
              >
                {item.label}
              </span>

              {/* Small orange active indicator bar/underline directly matching reference image */}
              <div
                className={`h-[2.5px] rounded-full mt-1 transition-all duration-300 ${
                  active ? 'w-5 sm:w-6 bg-[#FF6E00] opacity-100 scale-100' : 'w-2 bg-transparent opacity-0 scale-50'
                }`}
              />
            </button>
          );
        })}
      </div>
    </nav>
  );
};
