import React, { useState } from 'react';
import { User, Booking, Enquiry, TravelPackage, AccountNotification, PaymentTransaction } from '../types';
import { StorageService } from '../services/storage';
import {
  LayoutDashboard,
  Compass,
  Briefcase,
  HelpCircle,
  Heart,
  Bell,
  CreditCard,
  User as UserIcon,
  Settings,
  LogOut,
  Calendar,
  Sparkles,
  MapPin,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  Printer,
  ChevronRight,
  ArrowRight,
  ShieldCheck,
  Phone,
  Mail,
  Eye,
  RotateCcw,
  Check,
  Trash2,
  Camera,
  ExternalLink
} from 'lucide-react';
import { BUSINESS_INFO } from '../data/mockData';
import { InvoiceModal } from './InvoiceModal';

interface CustomerDashboardProps {
  currentUser: User;
  initialTab?: string;
  onExplorePackages: () => void;
  onViewPackage: (pkg: TravelPackage) => void;
  onBookPackage?: (pkg: TravelPackage) => void;
  onLogout?: () => void;
}

type AccountTab =
  | 'dashboard'
  | 'trips'
  | 'bookings'
  | 'enquiries'
  | 'saved'
  | 'notifications'
  | 'payments'
  | 'profile'
  | 'settings';

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({
  currentUser,
  initialTab = 'dashboard',
  onExplorePackages,
  onViewPackage,
  onBookPackage,
  onLogout
}) => {
  const [activeTab, setActiveTab] = useState<AccountTab>(
    (initialTab as AccountTab) || 'dashboard'
  );

  // Sub-tab for Bookings
  const [bookingFilter, setBookingFilter] = useState<'UPCOMING' | 'COMPLETED' | 'CANCELLED'>('UPCOMING');

  // Selected Booking for Invoice View
  const [invoiceBooking, setInvoiceBooking] = useState<Booking | null>(null);

  // Selected Enquiry for Details Modal
  const [selectedEnquiry, setSelectedEnquiry] = useState<Enquiry | null>(null);

  // Selected Booking for Itinerary Modal
  const [selectedTripBooking, setSelectedTripBooking] = useState<Booking | null>(null);

  // Profile Edit State
  const [editFirstName, setEditFirstName] = useState(currentUser.firstName || currentUser.name.split(' ')[0] || '');
  const [editLastName, setEditLastName] = useState(currentUser.lastName || currentUser.name.split(' ').slice(1).join(' ') || '');
  const [editEmail, setEditEmail] = useState(currentUser.email);
  const [editPhone, setEditPhone] = useState(currentUser.phone);
  const [editCity, setEditCity] = useState(currentUser.city || 'Kolkata, WB');
  const [profileSuccessMsg, setProfileSuccessMsg] = useState('');

  // Password Change State
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmNewPass, setConfirmNewPass] = useState('');
  const [passwordMsg, setPasswordMsg] = useState('');

  // Dynamic storage queries
  const allBookings = StorageService.getBookings();
  const customerBookings = allBookings.filter(b => b.customerId === currentUser.id);

  const upcomingBookings = customerBookings.filter(
    b => b.bookingStatus === 'CONFIRMED' || b.bookingStatus === 'PROCESSING'
  );
  const completedBookings = customerBookings.filter(b => b.bookingStatus === 'COMPLETED');
  const cancelledBookings = customerBookings.filter(b => b.bookingStatus === 'CANCELLED');

  const customerEnquiries = StorageService.getEnquiries().filter(
    e => e.customerId === currentUser.id || e.phone === currentUser.phone
  );

  const savedPackageIds = StorageService.getSavedPackageIds();
  const savedPackages = StorageService.getPackages().filter(p => savedPackageIds.includes(p.id));

  const notifications = StorageService.getNotifications(currentUser.id);
  const unreadNotifications = notifications.filter(n => !n.read);

  const paymentTransactions = StorageService.getPaymentTransactions(currentUser.id);

  // Navigation Items
  const navItems: { id: AccountTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'trips', label: 'My Trips', icon: Compass, badge: upcomingBookings.length },
    { id: 'bookings', label: 'My Bookings', icon: Briefcase, badge: customerBookings.length },
    { id: 'enquiries', label: 'My Enquiries', icon: HelpCircle, badge: customerEnquiries.length },
    { id: 'saved', label: 'Saved Packages', icon: Heart, badge: savedPackages.length },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: unreadNotifications.length },
    { id: 'payments', label: 'Payments', icon: CreditCard },
    { id: 'profile', label: 'My Profile', icon: UserIcon },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  // Handle Profile Save
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    StorageService.updateUserProfile(currentUser.id, {
      firstName: editFirstName,
      lastName: editLastName,
      email: editEmail,
      phone: editPhone,
      city: editCity
    });
    setProfileSuccessMsg('Profile updated successfully!');
    setTimeout(() => setProfileSuccessMsg(''), 3000);
  };

  // Handle Password Change
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPass || newPass.length < 6) {
      setPasswordMsg('New password must be at least 6 characters.');
      return;
    }
    if (newPass !== confirmNewPass) {
      setPasswordMsg('Passwords do not match.');
      return;
    }
    setPasswordMsg('Password changed successfully.');
    setCurrentPass('');
    setNewPass('');
    setConfirmNewPass('');
    setTimeout(() => setPasswordMsg(''), 3500);
  };

  // Handle Refund Request
  const handleRequestRefund = (bookingId: string) => {
    if (window.confirm('Are you sure you want to request a cancellation and refund for this booking?')) {
      const result = StorageService.requestRefund(bookingId);
      alert(result.message);
    }
  };

  return (
    <div className="py-6 sm:py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* 1. Header Profile Banner */}
      <div className="bg-[#0b213b] text-white rounded-3xl p-6 sm:p-8 shadow-xl mb-8 flex flex-col md:flex-row md:items-center justify-between gap-6 border border-[#1b3d63]">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-amber-400 via-orange-500 to-amber-600 text-slate-950 font-black text-2xl sm:text-3xl flex items-center justify-center shadow-lg font-heading shrink-0 overflow-hidden">
            {currentUser.avatar ? (
              <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
            ) : (
              currentUser.name.charAt(0).toUpperCase()
            )}
          </div>
          <div>
            <div className="text-[11px] sm:text-xs text-amber-300 font-bold uppercase tracking-wider flex items-center space-x-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>GoDigha Verified Traveller</span>
            </div>
            <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-white font-heading mt-0.5">
              {currentUser.name}
            </h1>
            <div className="text-xs text-slate-300 mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
              <span>{currentUser.email}</span>
              <span>•</span>
              <span>{currentUser.phone}</span>
              {currentUser.city && (
                <>
                  <span>•</span>
                  <span>{currentUser.city}</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* GoCash Wallet Balance Card */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 sm:p-5 border border-white/15 flex items-center space-x-4 self-start md:self-auto shadow-md">
          <div className="w-11 h-11 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-amber-300 animate-pulse" />
          </div>
          <div>
            <span className="text-[11px] text-slate-300 font-semibold uppercase tracking-wider block">
              GoCash Balance
            </span>
            <div className="text-xl sm:text-2xl font-black text-amber-300 font-heading">
              ₹{currentUser.goCashBalance.toLocaleString('en-IN')}
            </div>
            <span className="text-[10px] text-emerald-300">5% Cashback on All Bookings</span>
          </div>
        </div>
      </div>

      {/* 2. Main Portal Grid Layout: Desktop Sidebar Nav + Content View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Account Navigation Menu */}
        <div className="lg:col-span-3 bg-white rounded-3xl p-3 shadow-md border border-slate-100 space-y-1">
          <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 mb-1">
            Customer Account
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all text-left ${
                  isActive
                    ? 'bg-orange-600 text-white shadow-md shadow-orange-500/25'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <div className="flex items-center space-x-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && item.badge > 0 && (
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      isActive ? 'bg-white/20 text-white' : 'bg-orange-100 text-orange-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          <div className="pt-2 border-t border-slate-100 mt-2">
            <button
              onClick={() => {
                if (onLogout) onLogout();
                else StorageService.logout();
              }}
              className="w-full flex items-center space-x-2.5 px-3.5 py-2.5 rounded-xl text-xs font-bold text-red-600 hover:bg-red-50 transition-colors text-left"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>

        {/* Right Column: Active View Canvas */}
        <div className="lg:col-span-9 bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-slate-100 min-h-[500px]">
          
          {/* ======================================================== */}
          {/* TAB 1: DASHBOARD OVERVIEW */}
          {/* ======================================================== */}
          {activeTab === 'dashboard' && (
            <div className="space-y-8">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-heading">
                  Welcome back, {currentUser.name}!
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Manage your journeys, bookings and travel plans from one place.
                </p>
              </div>

              {/* 6 Metric Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5 sm:gap-4">
                
                <div
                  onClick={() => setActiveTab('trips')}
                  className="p-4 rounded-2xl bg-orange-50/70 hover:bg-orange-100/70 border border-orange-100 cursor-pointer transition-all hover:-translate-y-0.5 shadow-xs"
                >
                  <div className="flex items-center justify-between text-orange-600 mb-2">
                    <Compass className="w-5 h-5" />
                    <span className="text-2xl font-black font-heading">{upcomingBookings.length}</span>
                  </div>
                  <div className="text-xs font-bold text-slate-800">Upcoming Trips</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">Confirmed itineraries</div>
                </div>

                <div
                  onClick={() => setActiveTab('bookings')}
                  className="p-4 rounded-2xl bg-blue-50/70 hover:bg-blue-100/70 border border-blue-100 cursor-pointer transition-all hover:-translate-y-0.5 shadow-xs"
                >
                  <div className="flex items-center justify-between text-blue-600 mb-2">
                    <Briefcase className="w-5 h-5" />
                    <span className="text-2xl font-black font-heading">{customerBookings.length}</span>
                  </div>
                  <div className="text-xs font-bold text-slate-800">My Bookings</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">All reservations</div>
                </div>

                <div
                  onClick={() => setActiveTab('enquiries')}
                  className="p-4 rounded-2xl bg-amber-50/70 hover:bg-amber-100/70 border border-amber-100 cursor-pointer transition-all hover:-translate-y-0.5 shadow-xs"
                >
                  <div className="flex items-center justify-between text-amber-600 mb-2">
                    <HelpCircle className="w-5 h-5" />
                    <span className="text-2xl font-black font-heading">{customerEnquiries.length}</span>
                  </div>
                  <div className="text-xs font-bold text-slate-800">Active Enquiries</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">Corporate & custom quotes</div>
                </div>

                <div
                  onClick={() => setActiveTab('saved')}
                  className="p-4 rounded-2xl bg-rose-50/70 hover:bg-rose-100/70 border border-rose-100 cursor-pointer transition-all hover:-translate-y-0.5 shadow-xs"
                >
                  <div className="flex items-center justify-between text-rose-600 mb-2">
                    <Heart className="w-5 h-5" />
                    <span className="text-2xl font-black font-heading">{savedPackages.length}</span>
                  </div>
                  <div className="text-xs font-bold text-slate-800">Saved Packages</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">Shortlisted holidays</div>
                </div>

                <div
                  onClick={() => setActiveTab('payments')}
                  className="p-4 rounded-2xl bg-emerald-50/70 hover:bg-emerald-100/70 border border-emerald-100 cursor-pointer transition-all hover:-translate-y-0.5 shadow-xs"
                >
                  <div className="flex items-center justify-between text-emerald-600 mb-2">
                    <CreditCard className="w-5 h-5" />
                    <span className="text-2xl font-black font-heading">
                      {customerBookings.filter(b => b.paymentStatus === 'PENDING').length}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-slate-800">Pending Payments</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">Instant checkout available</div>
                </div>

                <div
                  onClick={() => setActiveTab('notifications')}
                  className="p-4 rounded-2xl bg-indigo-50/70 hover:bg-indigo-100/70 border border-indigo-100 cursor-pointer transition-all hover:-translate-y-0.5 shadow-xs"
                >
                  <div className="flex items-center justify-between text-indigo-600 mb-2">
                    <Bell className="w-5 h-5" />
                    <span className="text-2xl font-black font-heading">{unreadNotifications.length}</span>
                  </div>
                  <div className="text-xs font-bold text-slate-800">Notifications</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">Booking alerts & offers</div>
                </div>

              </div>

              {/* Next Upcoming Journey Feature Card */}
              {upcomingBookings.length > 0 ? (
                <div className="p-5 rounded-2xl bg-gradient-to-r from-[#0b213b] to-[#153a63] text-white shadow-lg space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-full bg-amber-400/20 text-amber-300 font-bold text-[10px] uppercase tracking-wider">
                      Next Confirmed Trip
                    </span>
                    <span className="text-xs font-mono text-slate-300">
                      ID: {upcomingBookings[0].id}
                    </span>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-lg font-black text-white font-heading">
                        {upcomingBookings[0].itemTitle}
                      </h3>
                      <div className="flex items-center space-x-2 text-xs text-slate-300 mt-1">
                        <Calendar className="w-4 h-4 text-amber-400" />
                        <span>Travel Date: {upcomingBookings[0].travelDate}</span>
                        <span>•</span>
                        <span>{upcomingBookings[0].travellers} Travellers</span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setInvoiceBooking(upcomingBookings[0])}
                        className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center space-x-1.5 transition-colors border border-white/20"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Invoice</span>
                      </button>
                      <button
                        onClick={() => setSelectedTripBooking(upcomingBookings[0])}
                        className="px-4 py-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs flex items-center space-x-1.5 transition-colors shadow-md"
                      >
                        <span>View Itinerary</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-6 rounded-2xl bg-slate-50 border border-dashed border-slate-200 text-center space-y-3">
                  <Compass className="w-10 h-10 text-slate-300 mx-auto" />
                  <div>
                    <h4 className="font-bold text-slate-800 text-sm">No upcoming trips planned yet</h4>
                    <p className="text-xs text-slate-500">Discover pristine beach resorts in Digha & Mandarmani.</p>
                  </div>
                  <button
                    onClick={onExplorePackages}
                    className="px-4 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs shadow-md transition-colors"
                  >
                    Explore Holiday Packages
                  </button>
                </div>
              )}

            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 2: MY TRIPS (TRAVEL ITINERARY WITH TIMELINE) */}
          {/* ======================================================== */}
          {activeTab === 'trips' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-heading">
                  My Trips
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Live itinerary tracking and confirmed journey timeline for Digha & beyond.
                </p>
              </div>

              {upcomingBookings.length === 0 ? (
                <div className="p-8 rounded-2xl bg-slate-50 text-center space-y-3">
                  <Compass className="w-12 h-12 text-slate-300 mx-auto" />
                  <div className="font-bold text-slate-700">No active itineraries</div>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    When you book a holiday package, hotel, or sightseeing tour, your day-by-day travel timeline will appear here.
                  </p>
                  <button
                    onClick={onExplorePackages}
                    className="px-4 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs"
                  >
                    Plan a Trip Now
                  </button>
                </div>
              ) : (
                upcomingBookings.map((trip) => (
                  <div key={trip.id} className="p-5 sm:p-6 rounded-3xl border border-slate-200 bg-slate-50/50 space-y-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
                      <div>
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          {trip.bookingStatus}
                        </span>
                        <h3 className="text-lg font-black text-slate-900 mt-1 font-heading">
                          {trip.itemTitle}
                        </h3>
                        <div className="text-xs text-slate-500 flex items-center space-x-2 mt-0.5">
                          <span>Travel Date: <strong className="text-slate-700">{trip.travelDate}</strong></span>
                          <span>•</span>
                          <span>{trip.travellers} Travellers</span>
                          <span>•</span>
                          <span>ID: {trip.id}</span>
                        </div>
                      </div>

                      <button
                        onClick={() => setInvoiceBooking(trip)}
                        className="self-start sm:self-auto px-3.5 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs border border-slate-200 flex items-center space-x-1.5 shadow-xs"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Download Invoice</span>
                      </button>
                    </div>

                    {/* Timeline Stages */}
                    <div>
                      <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">
                        Trip Progress & Voucher Milestones
                      </div>

                      <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-emerald-500">
                        
                        <div className="relative">
                          <div className="absolute -left-6 top-0.5 w-4 h-4 rounded-full bg-emerald-500 ring-4 ring-emerald-100 flex items-center justify-center text-white text-[9px] font-bold">
                            ✓
                          </div>
                          <div className="text-xs font-bold text-slate-900">Booking Confirmed</div>
                          <div className="text-[11px] text-slate-500">
                            Reservation payment verified and assigned to GoDigha desk.
                          </div>
                        </div>

                        <div className="relative">
                          <div className="absolute -left-6 top-0.5 w-4 h-4 rounded-full bg-emerald-500 ring-4 ring-emerald-100 flex items-center justify-center text-white text-[9px] font-bold">
                            ✓
                          </div>
                          <div className="text-xs font-bold text-slate-900">Hotel Voucher Allocated</div>
                          <div className="text-[11px] text-slate-500">
                            Sea-facing room blocked. Instant digital check-in voucher ready.
                          </div>
                        </div>

                        <div className="relative">
                          <div className="absolute -left-6 top-0.5 w-4 h-4 rounded-full bg-amber-500 ring-4 ring-amber-100 flex items-center justify-center text-white text-[9px] font-bold">
                            •
                          </div>
                          <div className="text-xs font-bold text-slate-900">Chauffeur & Pickup Assigned</div>
                          <div className="text-[11px] text-slate-500">
                            AC vehicle driver details will be shared 12 hours before pickup via WhatsApp.
                          </div>
                        </div>

                        <div className="relative">
                          <div className="absolute -left-6 top-0.5 w-4 h-4 rounded-full bg-slate-300 ring-4 ring-slate-100 flex items-center justify-center text-white text-[9px] font-bold">
                            •
                          </div>
                          <div className="text-xs font-bold text-slate-400">Sightseeing & Watersports Vouchers</div>
                          <div className="text-[11px] text-slate-400">
                            Marine drive pass and activity tickets activated at resort front desk.
                          </div>
                        </div>

                      </div>
                    </div>

                  </div>
                ))
              )}

            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 3: MY BOOKINGS */}
          {/* ======================================================== */}
          {activeTab === 'bookings' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-heading">
                    My Bookings
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    View upcoming, past, and cancelled reservations.
                  </p>
                </div>

                {/* Sub-tabs: Upcoming / Completed / Cancelled */}
                <div className="flex p-1 bg-slate-100 rounded-2xl text-xs font-bold">
                  <button
                    onClick={() => setBookingFilter('UPCOMING')}
                    className={`px-3 py-1.5 rounded-xl transition-all ${
                      bookingFilter === 'UPCOMING' ? 'bg-white text-orange-600 shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Upcoming ({upcomingBookings.length})
                  </button>
                  <button
                    onClick={() => setBookingFilter('COMPLETED')}
                    className={`px-3 py-1.5 rounded-xl transition-all ${
                      bookingFilter === 'COMPLETED' ? 'bg-white text-orange-600 shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Completed ({completedBookings.length})
                  </button>
                  <button
                    onClick={() => setBookingFilter('CANCELLED')}
                    className={`px-3 py-1.5 rounded-xl transition-all ${
                      bookingFilter === 'CANCELLED' ? 'bg-white text-orange-600 shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Cancelled ({cancelledBookings.length})
                  </button>
                </div>
              </div>

              {/* Bookings List */}
              <div className="space-y-4">
                {((bookingFilter === 'UPCOMING'
                  ? upcomingBookings
                  : bookingFilter === 'COMPLETED'
                  ? completedBookings
                  : cancelledBookings
                ).length === 0) ? (
                  <div className="p-8 text-center text-slate-400 bg-slate-50 rounded-2xl">
                    No {bookingFilter.toLowerCase()} bookings found.
                  </div>
                ) : (
                  (bookingFilter === 'UPCOMING'
                    ? upcomingBookings
                    : bookingFilter === 'COMPLETED'
                    ? completedBookings
                    : cancelledBookings
                  ).map((b) => (
                    <div
                      key={b.id}
                      className="p-5 rounded-2xl border border-slate-200 hover:border-slate-300 transition-all bg-white shadow-xs space-y-4"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                        <div>
                          <div className="text-[11px] font-mono font-bold text-slate-500">
                            Booking ID: <span className="text-slate-900">{b.id}</span>
                          </div>
                          <h3 className="text-base font-black text-slate-900 font-heading mt-0.5">
                            {b.itemTitle}
                          </h3>
                        </div>

                        <div className="flex items-center space-x-2">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              b.paymentStatus === 'PAID'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            Payment: {b.paymentStatus}
                          </span>
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              b.bookingStatus === 'CONFIRMED'
                                ? 'bg-blue-100 text-blue-800'
                                : b.bookingStatus === 'CANCELLED'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-slate-100 text-slate-800'
                            }`}
                          >
                            Booking: {b.bookingStatus}
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase font-bold">Travel Date</span>
                          <span className="font-bold text-slate-800">{b.travelDate}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase font-bold">Travellers</span>
                          <span className="font-bold text-slate-800">{b.travellers} Guests</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Paid</span>
                          <span className="font-black text-orange-600 font-heading">
                            ₹{b.totalAmount.toLocaleString('en-IN')}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase font-bold">Booked On</span>
                          <span className="text-slate-600">{new Date(b.createdAt).toLocaleDateString('en-IN')}</span>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => setInvoiceBooking(b)}
                            className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center space-x-1.5 transition-colors"
                          >
                            <FileText className="w-3.5 h-3.5 text-slate-500" />
                            <span>Download Invoice</span>
                          </button>

                          <a
                            href={`tel:${BUSINESS_INFO.phone}`}
                            className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center space-x-1.5 transition-colors"
                          >
                            <Phone className="w-3.5 h-3.5 text-slate-500" />
                            <span>Contact GoDigha</span>
                          </a>
                        </div>

                        {b.bookingStatus !== 'CANCELLED' && (
                          <button
                            onClick={() => handleRequestRefund(b.id)}
                            className="text-xs text-red-600 hover:text-red-700 font-semibold hover:underline"
                          >
                            Cancel & Refund
                          </button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>

            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 4: MY ENQUIRIES */}
          {/* ======================================================== */}
          {activeTab === 'enquiries' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-heading">
                  My Travel Enquiries
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Track custom travel quotes, corporate retreats, conferences and banquet event requests.
                </p>
              </div>

              {customerEnquiries.length === 0 ? (
                <div className="p-8 text-center text-slate-400 bg-slate-50 rounded-2xl">
                  No active travel enquiries.
                </div>
              ) : (
                <div className="space-y-4">
                  {customerEnquiries.map((enq) => (
                    <div
                      key={enq.id}
                      className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-200">
                        <div>
                          <div className="text-[11px] font-mono font-bold text-slate-500">
                            Enquiry ID: <span className="text-slate-800">{enq.id}</span>
                          </div>
                          <h4 className="text-base font-bold text-slate-900">
                            {enq.type} Retreat — {enq.destination}
                          </h4>
                        </div>

                        <span
                          className={`self-start sm:self-auto px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            enq.status === 'QUOTED'
                              ? 'bg-amber-100 text-amber-900 font-extrabold'
                              : enq.status === 'CONVERTED'
                              ? 'bg-emerald-100 text-emerald-900'
                              : 'bg-blue-100 text-blue-900'
                          }`}
                        >
                          Status: {enq.status === 'QUOTED' ? 'Quote Ready' : enq.status}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase font-bold">Travel Dates</span>
                          <span className="font-semibold text-slate-700">{enq.travelDates}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase font-bold">Group Size</span>
                          <span className="font-semibold text-slate-700">{enq.travellersCount} Members</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase font-bold">Budget</span>
                          <span className="font-semibold text-slate-700">{enq.budgetRange}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase font-bold">Submitted</span>
                          <span className="text-slate-500">{new Date(enq.createdAt).toLocaleDateString('en-IN')}</span>
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 bg-white p-3 rounded-xl border border-slate-100">
                        "{enq.message}"
                      </p>

                      {enq.adminNotes && (
                        <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
                          <strong className="block text-[11px] uppercase tracking-wider text-amber-700">GoDigha Desk Note:</strong>
                          <span>{enq.adminNotes}</span>
                        </div>
                      )}

                      <div className="flex justify-end pt-1">
                        <a
                          href={`https://wa.me/918849125029?text=Hello%20GoDigha%2C%20regarding%20my%20enquiry%20${enq.id}`}
                          target="_blank"
                          rel="noreferrer"
                          className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center space-x-1.5 transition-colors shadow-xs"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>Chat with Agent on WhatsApp</span>
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 5: SAVED PACKAGES */}
          {/* ======================================================== */}
          {activeTab === 'saved' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-heading">
                  Saved Packages
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Holiday packages you’ve shortlisted for your next coastal getaway.
                </p>
              </div>

              {savedPackages.length === 0 ? (
                <div className="p-8 text-center text-slate-400 bg-slate-50 rounded-2xl space-y-3">
                  <Heart className="w-10 h-10 text-slate-300 mx-auto" />
                  <div className="font-bold text-slate-700 text-sm">No saved packages yet</div>
                  <p className="text-xs text-slate-500">
                    Click the heart icon on any package to save it to your wishlist.
                  </p>
                  <button
                    onClick={onExplorePackages}
                    className="px-4 py-2 rounded-xl bg-orange-600 text-white font-bold text-xs"
                  >
                    Browse Holiday Packages
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {savedPackages.map((pkg) => (
                    <div
                      key={pkg.id}
                      className="rounded-2xl border border-slate-200 overflow-hidden bg-white shadow-xs hover:shadow-md transition-all group flex flex-col"
                    >
                      <div className="relative h-44 overflow-hidden">
                        <img
                          src={pkg.coverImage}
                          alt={pkg.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <button
                          onClick={() => StorageService.toggleSavedPackage(pkg.id)}
                          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 text-rose-600 flex items-center justify-center shadow-md hover:bg-white transition-colors"
                          title="Unsave Package"
                        >
                          <Heart className="w-4 h-4 fill-rose-600" />
                        </button>
                        <span className="absolute bottom-3 left-3 px-2.5 py-1 rounded-full bg-black/60 text-white text-[11px] font-bold backdrop-blur-xs">
                          {pkg.duration}
                        </span>
                      </div>

                      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                        <div>
                          <div className="text-[11px] font-bold text-orange-600 uppercase tracking-wider">
                            {pkg.destination}
                          </div>
                          <h4 className="font-bold text-slate-900 text-sm mt-0.5 line-clamp-1">
                            {pkg.name}
                          </h4>
                          <div className="text-xs text-slate-500 mt-1 flex items-center space-x-1">
                            <span>Starting from</span>
                            <span className="text-sm font-black text-slate-900">
                              ₹{(pkg.discountedPrice || pkg.startingPrice).toLocaleString('en-IN')}
                            </span>
                            <span className="text-[10px]">/ person</span>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 pt-2 border-t border-slate-100">
                          <button
                            onClick={() => onViewPackage(pkg)}
                            className="flex-1 py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors text-center"
                          >
                            View Details
                          </button>
                          {onBookPackage && (
                            <button
                              onClick={() => onBookPackage(pkg)}
                              className="flex-1 py-2 px-3 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs transition-colors text-center shadow-sm"
                            >
                              Book Now
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 6: NOTIFICATIONS */}
          {/* ======================================================== */}
          {activeTab === 'notifications' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-heading">
                    Notifications
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Live updates on bookings, quotes, cashback credits and travel alerts.
                  </p>
                </div>

                {unreadNotifications.length > 0 && (
                  <button
                    onClick={() => StorageService.markAllNotificationsAsRead(currentUser.id)}
                    className="self-start sm:self-auto text-xs font-bold text-orange-600 hover:text-orange-700 hover:underline flex items-center space-x-1"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Mark all as read</span>
                  </button>
                )}
              </div>

              {notifications.length === 0 ? (
                <div className="p-8 text-center text-slate-400 bg-slate-50 rounded-2xl">
                  No notifications yet.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {notifications.map((notif) => (
                    <div
                      key={notif.id}
                      onClick={() => {
                        StorageService.markNotificationAsRead(notif.id);
                        if (notif.linkTab) setActiveTab(notif.linkTab as AccountTab);
                      }}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start space-x-3.5 ${
                        notif.read
                          ? 'bg-white border-slate-200/80 text-slate-600 hover:bg-slate-50'
                          : 'bg-orange-50/60 border-orange-200 text-slate-900 shadow-xs'
                      }`}
                    >
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                          notif.type === 'BOOKING'
                            ? 'bg-blue-100 text-blue-700'
                            : notif.type === 'PAYMENT'
                            ? 'bg-emerald-100 text-emerald-700'
                            : notif.type === 'ENQUIRY'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-purple-100 text-purple-700'
                        }`}
                      >
                        <Bell className="w-4 h-4" />
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                            {notif.title}
                          </h4>
                          <span className="text-[10px] text-slate-400 shrink-0 ml-2">
                            {new Date(notif.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                          {notif.message}
                        </p>
                      </div>

                      {!notif.read && (
                        <span className="w-2 h-2 rounded-full bg-orange-600 shrink-0 mt-1.5" />
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 7: PAYMENTS & INVOICES */}
          {/* ======================================================== */}
          {activeTab === 'payments' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-heading">
                  Payment History & Invoices
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Verified gateway transactions, downloadable invoices, and refund tracking.
                </p>
              </div>

              {/* Transactions Table */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                <div className="bg-slate-100/80 px-4 py-3 font-bold text-slate-700 grid grid-cols-12 uppercase tracking-wider text-[11px]">
                  <span className="col-span-4">Transaction / Service</span>
                  <span className="col-span-3">Payment ID / Date</span>
                  <span className="col-span-2 text-center">Status</span>
                  <span className="col-span-3 text-right">Actions</span>
                </div>

                <div className="divide-y divide-slate-100 text-xs">
                  {paymentTransactions.length === 0 ? (
                    <div className="p-6 text-center text-slate-400">No payment records found.</div>
                  ) : (
                    paymentTransactions.map((tx) => (
                      <div key={tx.id} className="p-4 grid grid-cols-12 items-center hover:bg-slate-50 transition-colors">
                        <div className="col-span-4 pr-2">
                          <div className="font-bold text-slate-900 line-clamp-1">{tx.itemTitle}</div>
                          <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                            Booking: {tx.bookingId}
                          </div>
                          <div className="text-sm font-black text-slate-900 mt-1 font-heading">
                            ₹{tx.amount.toLocaleString('en-IN')}
                          </div>
                        </div>

                        <div className="col-span-3">
                          <div className="font-mono text-slate-700 text-[11px] truncate">{tx.paymentId}</div>
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            {new Date(tx.date).toLocaleDateString('en-IN')} via {tx.method}
                          </div>
                        </div>

                        <div className="col-span-2 text-center">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              tx.status === 'PAID'
                                ? 'bg-emerald-100 text-emerald-800'
                                : tx.status === 'REFUNDED'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {tx.status}
                          </span>
                          {tx.refundStatus && tx.refundStatus !== 'NONE' && (
                            <span className="block text-[9px] text-amber-600 mt-0.5 font-semibold">
                              Refund: {tx.refundStatus}
                            </span>
                          )}
                        </div>

                        <div className="col-span-3 text-right">
                          <button
                            onClick={() => {
                              const relatedBooking = allBookings.find(b => b.id === tx.bookingId);
                              if (relatedBooking) {
                                setInvoiceBooking(relatedBooking);
                              } else {
                                // Synthetic booking for invoice
                                setInvoiceBooking({
                                  id: tx.bookingId,
                                  customerId: currentUser.id,
                                  customerName: currentUser.name,
                                  customerEmail: currentUser.email,
                                  customerPhone: currentUser.phone,
                                  bookingType: 'PACKAGE',
                                  itemId: 'pkg_digha',
                                  itemTitle: tx.itemTitle,
                                  travelDate: '2026-10-15',
                                  travellers: 2,
                                  guests: [],
                                  baseAmount: tx.amount - 300,
                                  taxAmount: 300,
                                  discountAmount: 0,
                                  goCashUsed: 0,
                                  totalAmount: tx.amount,
                                  paymentStatus: 'PAID',
                                  bookingStatus: 'CONFIRMED',
                                  paymentId: tx.paymentId,
                                  createdAt: tx.date
                                });
                              }
                            }}
                            className="px-3 py-1.5 rounded-xl bg-orange-50 hover:bg-orange-100 text-orange-700 font-bold text-xs inline-flex items-center space-x-1 transition-colors"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Invoice</span>
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 8: MY PROFILE */}
          {/* ======================================================== */}
          {activeTab === 'profile' && (
            <div className="space-y-8">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-heading">
                  My Profile
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Update your contact details, city, and account password.
                </p>
              </div>

              {profileSuccessMsg && (
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 font-bold flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>{profileSuccessMsg}</span>
                </div>
              )}

              {/* Profile Details Form */}
              <form onSubmit={handleSaveProfile} className="space-y-4 max-w-xl">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">First Name</label>
                    <input
                      type="text"
                      required
                      value={editFirstName}
                      onChange={(e) => setEditFirstName(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Last Name</label>
                    <input
                      type="text"
                      required
                      value={editLastName}
                      onChange={(e) => setEditLastName(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Mobile Number</label>
                    <input
                      type="tel"
                      required
                      value={editPhone}
                      onChange={(e) => setEditPhone(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">City / Origin</label>
                    <input
                      type="text"
                      value={editCity}
                      onChange={(e) => setEditCity(e.target.value)}
                      placeholder="e.g. Kolkata, WB"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95"
                >
                  Save Profile Changes
                </button>
              </form>

              {/* Change Password Section */}
              <div className="pt-6 border-t border-slate-100 max-w-xl">
                <h3 className="text-base font-bold text-slate-900 mb-3">Change Password</h3>

                {passwordMsg && (
                  <div className="mb-4 p-3 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-800 font-semibold">
                    {passwordMsg}
                  </div>
                )}

                <form onSubmit={handleChangePassword} className="space-y-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Current Password</label>
                    <input
                      type="password"
                      value={currentPass}
                      onChange={(e) => setCurrentPass(e.target.value)}
                      placeholder="Enter current password"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">New Password</label>
                      <input
                        type="password"
                        value={newPass}
                        onChange={(e) => setNewPass(e.target.value)}
                        placeholder="Min 6 characters"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">Confirm New Password</label>
                      <input
                        type="password"
                        value={confirmNewPass}
                        onChange={(e) => setConfirmNewPass(e.target.value)}
                        placeholder="Repeat new password"
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/30"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs transition-colors"
                  >
                    Update Password
                  </button>
                </form>
              </div>

            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 9: SETTINGS */}
          {/* ======================================================== */}
          {activeTab === 'settings' && (
            <div className="space-y-6 max-w-xl">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-heading">
                  Account Settings
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Configure alerts, notification channels, and privacy preferences.
                </p>
              </div>

              <div className="space-y-4">
                <div className="p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">WhatsApp Trip Alerts</h4>
                    <p className="text-[11px] text-slate-500">Receive driver contact details and voucher updates on WhatsApp.</p>
                  </div>
                  <input type="checkbox" defaultChecked className="w-4 h-4 text-orange-600 rounded border-slate-300" />
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">SMS Booking Verification</h4>
                    <p className="text-[11px] text-slate-500">Receive OTP and payment confirmations via instant SMS.</p>
                  </div>
                  <input type="checkbox" defaultChecked className="w-4 h-4 text-orange-600 rounded border-slate-300" />
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Festive Offers & Secret Deals</h4>
                    <p className="text-[11px] text-slate-500">Email alerts about discounted sea facing resort weekend sales.</p>
                  </div>
                  <input type="checkbox" defaultChecked className="w-4 h-4 text-orange-600 rounded border-slate-300" />
                </div>
              </div>

              <div className="pt-6 border-t border-slate-100">
                <h4 className="text-xs font-bold text-red-600 mb-1">Danger Zone</h4>
                <p className="text-[11px] text-slate-500 mb-3">
                  Deleting your account will erase your GoCash balance and booking history permanently.
                </p>
                <button
                  onClick={() => alert('For security reasons, please contact GoDigha support at support@godigha.com to process permanent account deletion.')}
                  className="px-4 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs border border-red-200 transition-colors"
                >
                  Request Account Deletion
                </button>
              </div>

            </div>
          )}

        </div>

      </div>

      {/* Invoice Modal Overlay */}
      {invoiceBooking && (
        <InvoiceModal
          booking={invoiceBooking}
          onClose={() => setInvoiceBooking(null)}
        />
      )}

    </div>
  );
};
