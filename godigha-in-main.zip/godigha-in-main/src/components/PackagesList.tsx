import React, { useState } from 'react';
import { TravelPackage } from '../types';
import { Search, Filter, Clock, MapPin, Star, ArrowRight, Heart } from 'lucide-react';
import { StorageService } from '../services/storage';

interface PackagesListProps {
  packages: TravelPackage[];
  onSelectPackage: (pkg: TravelPackage) => void;
  initialDestinationFilter?: string;
}

export const PackagesList: React.FC<PackagesListProps> = ({
  packages,
  onSelectPackage,
  initialDestinationFilter
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedDestination, setSelectedDestination] = useState<string>(initialDestinationFilter || 'ALL');
  const [savedIds, setSavedIds] = useState<string[]>(StorageService.getSavedPackageIds());

  const categories = [
    { id: 'ALL', label: 'All Packages' },
    { id: 'BEACH', label: 'Beach & Coastal' },
    { id: 'HILL_STATION', label: 'Himalayan Hills' },
    { id: 'WILDLIFE', label: 'Wildlife & Safari' },
    { id: 'PILGRIMAGE', label: 'Pilgrimage & Sacred' },
    { id: 'HERITAGE', label: 'Heritage & International' }
  ];

  const filtered = packages.filter((pkg) => {
    const matchesSearch = pkg.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pkg.destination.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'ALL' || pkg.category === selectedCategory;
    const matchesDest = selectedDestination === 'ALL' || pkg.destination.toLowerCase().includes(selectedDestination.toLowerCase());
    return matchesSearch && matchesCat && matchesDest;
  });

  const handleToggleSave = (pkgId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = StorageService.toggleSavedPackage(pkgId);
    setSavedIds(StorageService.getSavedPackageIds());
  };

  return (
    <div className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
        <div>
          <div className="text-xs font-bold uppercase tracking-wider text-amber-600 mb-1">
            Complete Holiday Packages
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 font-heading">
            Curated Travel Packages & Tours
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-xl">
            All-inclusive trips with verified hotel stays, dedicated mountain & coastal chauffeur cabs, sightseeing, and 24/7 on-ground assistance.
          </p>
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by tour or city..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-slate-300 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-900 shadow-2xs"
          />
        </div>
      </div>

      {/* Category Pills Filter */}
      <div className="flex flex-wrap gap-2 mb-8">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${
              selectedCategory === cat.id
                ? 'bg-[#0f2847] text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Package Cards Grid */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-3xl border border-slate-200">
          <p className="text-sm font-semibold text-slate-600">No packages found matching your criteria.</p>
          <button
            onClick={() => { setSearchQuery(''); setSelectedCategory('ALL'); setSelectedDestination('ALL'); }}
            className="mt-3 px-4 py-1.5 bg-blue-900 text-amber-300 text-xs font-bold rounded-lg"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((pkg) => {
            const isSaved = savedIds.includes(pkg.id);
            return (
              <div
                key={pkg.id}
                onClick={() => onSelectPackage(pkg)}
                className="group cursor-pointer bg-white rounded-3xl overflow-hidden border border-slate-200/90 shadow-2xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between hover:-translate-y-1"
              >
                <div>
                  <div className="relative aspect-16/10 overflow-hidden bg-slate-100">
                    <img
                      src={pkg.coverImage}
                      alt={pkg.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
                    />

                    {/* Badge */}
                    {pkg.badge && (
                      <div className="absolute top-3 left-3 bg-amber-500 text-slate-950 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase shadow-xs">
                        {pkg.badge}
                      </div>
                    )}

                    {/* Wishlist Heart */}
                    <button
                      onClick={(e) => handleToggleSave(pkg.id, e)}
                      className="absolute top-3 right-3 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-xs transition-colors"
                      aria-label="Save to Wishlist"
                    >
                      <Heart className={`w-3.5 h-3.5 ${isSaved ? 'fill-red-500 text-red-500' : ''}`} />
                    </button>
                  </div>

                  <div className="p-5">
                    <div className="text-xs text-blue-900 font-bold flex items-center space-x-1.5">
                      <MapPin className="w-3.5 h-3.5 text-amber-500" />
                      <span>{pkg.destination}</span>
                      <span>·</span>
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>{pkg.duration}</span>
                    </div>

                    <h3 className="font-extrabold text-slate-900 text-base font-heading mt-1 group-hover:text-blue-900 transition-colors line-clamp-1">
                      {pkg.name}
                    </h3>

                    <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                      {pkg.overview}
                    </p>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                      <span>Stay + Cab + Meals</span>
                      <span className="flex items-center text-amber-500 font-bold">
                        <Star className="w-3.5 h-3.5 fill-current mr-1" />
                        <span>{pkg.rating} ({pkg.reviewsCount})</span>
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-5 pt-0 flex items-center justify-between border-t border-slate-100 pt-3">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Starting from</span>
                    <div className="flex items-baseline space-x-1.5">
                      <span className="text-xl font-black text-slate-900 font-heading">
                        ₹{pkg.discountedPrice || pkg.startingPrice}
                      </span>
                      {pkg.discountedPrice && (
                        <span className="text-xs text-slate-400 line-through">₹{pkg.startingPrice}</span>
                      )}
                    </div>
                  </div>

                  <button
                    type="button"
                    className="px-4 py-2 rounded-xl bg-[#0f2847] group-hover:bg-blue-900 text-amber-300 font-bold text-xs flex items-center space-x-1 transition-colors shadow-xs"
                  >
                    <span>View Tour</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
