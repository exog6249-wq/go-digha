import React, { useState, useEffect } from 'react';
import {
  Hotel,
  HotelRoom,
  TransportService,
  TravelPackage,
  WaterActivity,
  BikeRental,
  SightseeingTour,
  ServiceCategory,
  UnifiedSearchParams
} from '../types';
import {
  ArrowLeft,
  Search,
  Filter,
  SlidersHorizontal,
  Star,
  MapPin,
  Calendar,
  Users,
  ShieldCheck,
  CheckCircle2,
  Car,
  Hotel as HotelIcon,
  Compass,
  Waves,
  Bike as BikeIcon,
  Clock,
  Sparkles,
  ArrowRight,
  Eye,
  Check,
  X,
  Phone,
  RefreshCw
} from 'lucide-react';
import { BUSINESS_INFO } from '../data/mockData';
import {
  searchHotels,
  searchCabs,
  searchTours,
  searchActivities,
  searchBikes
} from '../services/searchEngine';

interface SearchResultsViewProps {
  searchParams: UnifiedSearchParams;
  hotels: Hotel[];
  transports: TransportService[];
  packages: TravelPackage[];
  activities: WaterActivity[];
  bikes: BikeRental[];
  sightseeing: SightseeingTour[];
  onBackToSearch: () => void;
  onBookHotelRoom: (hotel: Hotel, room: HotelRoom) => void;
  onBookTransport: (transport: TransportService) => void;
  onSelectPackage: (pkg: TravelPackage) => void;
  onBookPackage: (pkg: TravelPackage) => void;
  onBookActivity: (activity: WaterActivity) => void;
  onBookBike: (bike: BikeRental) => void;
  onBookSightseeing: (tour: SightseeingTour) => void;
  onCategoryChange: (category: ServiceCategory) => void;
  onPopularSearchClick: (term: string) => void;
}

export const SearchResultsView: React.FC<SearchResultsViewProps> = ({
  searchParams,
  hotels,
  transports,
  packages,
  activities,
  bikes,
  sightseeing,
  onBackToSearch,
  onBookHotelRoom,
  onBookTransport,
  onSelectPackage,
  onBookPackage,
  onBookActivity,
  onBookBike,
  onBookSightseeing,
  onCategoryChange,
  onPopularSearchClick
}) => {
  const [activeCategory, setActiveCategory] = useState<ServiceCategory>(searchParams.category || 'hotel');
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'recommended' | 'price_low' | 'price_high' | 'rating'>('recommended');
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);

  // Category specific filter states
  const [hotelPropertyType, setHotelPropertyType] = useState<string>('ALL');
  const [hotelMaxPrice, setHotelMaxPrice] = useState<number>(5000);
  const [hotelMinRating, setHotelMinRating] = useState<number>(0);

  const [cabType, setCabType] = useState<string>('ALL');
  const [cabAcOnly, setCabAcOnly] = useState<boolean>(false);

  const [tourDuration, setTourDuration] = useState<string>('ALL');
  const [tourMaxPrice, setTourMaxPrice] = useState<number>(30000);

  const [activityType, setActivityType] = useState<string>('ALL');
  const [activityMaxPrice, setActivityMaxPrice] = useState<number>(2000);

  const [bikeType, setBikeType] = useState<string>('ALL');
  const [bikeMaxPrice, setBikeMaxPrice] = useState<number>(2000);

  // Hotel View Modal
  const [activeHotelModal, setActiveHotelModal] = useState<Hotel | null>(null);
  // Cab View Modal
  const [activeCabModal, setActiveCabModal] = useState<TransportService | null>(null);
  // Bike View Modal
  const [activeBikeModal, setActiveBikeModal] = useState<BikeRental | null>(null);
  // Activity View Modal
  const [activeActivityModal, setActiveActivityModal] = useState<WaterActivity | null>(null);

  // Sync category when parent changes
  useEffect(() => {
    setActiveCategory(searchParams.category);
  }, [searchParams.category]);

  // Realistic smooth loading state (Section 17)
  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      setLoading(false);
    }, 450);
    return () => clearTimeout(timer);
  }, [activeCategory, searchParams]);

  const handleTabSwitch = (cat: ServiceCategory) => {
    setActiveCategory(cat);
    onCategoryChange(cat);
  };

  // 1. Process Hotels
  let matchedHotels = searchHotels(
    hotels,
    {
      ...searchParams.hotelParams,
      destination: searchParams.destination || searchParams.hotelParams?.destination,
      propertyType: hotelPropertyType,
      minRating: hotelMinRating
    },
    searchParams.query
  ).filter(h => h.startingPrice <= hotelMaxPrice);

  if (sortBy === 'price_low') matchedHotels.sort((a, b) => a.startingPrice - b.startingPrice);
  else if (sortBy === 'price_high') matchedHotels.sort((a, b) => b.startingPrice - a.startingPrice);
  else if (sortBy === 'rating') matchedHotels.sort((a, b) => b.rating - a.rating);

  // 2. Process Cabs
  let matchedCabs = searchCabs(
    transports,
    {
      ...searchParams.cabParams,
      vehicleType: cabType,
      acOnly: cabAcOnly
    },
    searchParams.query
  );
  if (sortBy === 'price_low') matchedCabs.sort((a, b) => a.basePrice - b.basePrice);
  else if (sortBy === 'price_high') matchedCabs.sort((a, b) => b.basePrice - a.basePrice);

  // 3. Process Tours
  let matchedTours = searchTours(
    packages,
    {
      ...searchParams.tourParams,
      destination: searchParams.destination || searchParams.tourParams?.destination,
      duration: tourDuration
    },
    searchParams.query
  ).filter(p => (p.discountedPrice || p.startingPrice) <= tourMaxPrice);

  if (sortBy === 'price_low') matchedTours.sort((a, b) => (a.discountedPrice || a.startingPrice) - (b.discountedPrice || b.startingPrice));
  else if (sortBy === 'price_high') matchedTours.sort((a, b) => (b.discountedPrice || b.startingPrice) - (a.discountedPrice || a.startingPrice));
  else if (sortBy === 'rating') matchedTours.sort((a, b) => b.rating - a.rating);

  // 4. Process Activities
  const { activities: matchedActs, sightseeing: matchedSight } = searchActivities(
    activities,
    sightseeing,
    {
      ...searchParams.activityParams,
      destination: searchParams.destination || searchParams.activityParams?.destination,
      activityType: activityType
    },
    searchParams.query
  );
  let filteredActs = matchedActs.filter(a => a.price <= activityMaxPrice);
  if (sortBy === 'price_low') filteredActs.sort((a, b) => a.price - b.price);
  else if (sortBy === 'price_high') filteredActs.sort((a, b) => b.price - a.price);

  // 5. Process Bikes
  let matchedBikes = searchBikes(
    bikes,
    {
      ...searchParams.bikeParams,
      bikeType: bikeType
    },
    searchParams.query
  ).filter(b => b.pricePerDay <= bikeMaxPrice);
  if (sortBy === 'price_low') matchedBikes.sort((a, b) => a.pricePerDay - b.pricePerDay);
  else if (sortBy === 'price_high') matchedBikes.sort((a, b) => b.pricePerDay - a.pricePerDay);

  const getResultsCount = () => {
    switch (activeCategory) {
      case 'hotel': return matchedHotels.length;
      case 'cab': return matchedCabs.length;
      case 'tour': return matchedTours.length;
      case 'activity': return filteredActs.length + matchedSight.length;
      case 'bike': return matchedBikes.length;
    }
  };

  const currentCount = getResultsCount();

  const resetAllFilters = () => {
    setHotelPropertyType('ALL');
    setHotelMaxPrice(5000);
    setHotelMinRating(0);
    setCabType('ALL');
    setCabAcOnly(false);
    setTourDuration('ALL');
    setTourMaxPrice(30000);
    setActivityType('ALL');
    setActivityMaxPrice(2000);
    setBikeType('ALL');
    setBikeMaxPrice(2000);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-16">
      
      {/* 1. Sticky Navigation & Breadcrumbs Bar */}
      <div className="bg-white border-b border-slate-200 sticky top-16 md:top-18 lg:top-20 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3">
          
          {/* Back button and current search summary */}
          <div className="flex items-center space-x-3">
            <button
              onClick={onBackToSearch}
              className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm transition-colors active:scale-95 shrink-0"
              aria-label="Back to Search"
            >
              <ArrowLeft className="w-4 h-4 text-slate-600" />
              <span>Back to Search</span>
            </button>

            <div className="h-5 w-px bg-slate-200 hidden sm:block" />

            <div className="min-w-0">
              <h1 className="text-sm sm:text-base font-black text-slate-900 truncate">
                {loading ? (
                  <span className="text-slate-400">Searching GoDigha verified database...</span>
                ) : (
                  <span>
                    {currentCount} {activeCategory === 'hotel' ? 'Hotels & Resorts' : activeCategory === 'cab' ? 'Cabs & Vehicles' : activeCategory === 'tour' ? 'Holiday Packages' : activeCategory === 'activity' ? 'Water Sports & Experiences' : 'Bikes & Scooters'} in {searchParams.destination || 'Digha Coast'}
                  </span>
                )}
              </h1>
              {searchParams.query && (
                <p className="text-[11px] text-slate-500 truncate">
                  Query: <span className="font-semibold text-orange-600">"{searchParams.query}"</span>
                </p>
              )}
            </div>
          </div>

          {/* Category Tabs in Results Bar */}
          <div className="flex items-center space-x-1.5 overflow-x-auto scrollbar-none pb-1 md:pb-0">
            {[
              { id: 'hotel' as const, label: 'Hotels', icon: HotelIcon },
              { id: 'cab' as const, label: 'Cabs', icon: Car },
              { id: 'tour' as const, label: 'Tours', icon: Compass },
              { id: 'activity' as const, label: 'Activities', icon: Waves },
              { id: 'bike' as const, label: 'Bikes', icon: BikeIcon }
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeCategory === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => handleTabSwitch(tab.id)}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all shrink-0 ${
                    isActive
                      ? 'bg-[#FF6E00] text-white shadow-sm'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

        </div>
      </div>

      {/* 2. Main Search Results Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        
        {/* Sort & Mobile Filter Toggle Row */}
        <div className="flex items-center justify-between gap-3 mb-6 bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center space-x-2 text-xs font-semibold text-slate-500">
            <span className="hidden sm:inline">Showing verified GoDigha options</span>
            <span className="sm:hidden">Results</span>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={() => setFilterDrawerOpen(!filterDrawerOpen)}
              className="lg:hidden flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold"
            >
              <Filter className="w-3.5 h-3.5 text-orange-600" />
              <span>Filters</span>
            </button>

            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold text-slate-600 hidden sm:inline">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="text-xs font-bold text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-orange-500 cursor-pointer"
              >
                <option value="recommended">Recommended</option>
                <option value="price_low">Price: Low to High</option>
                <option value="price_high">Price: High to Low</option>
                <option value="rating">Guest Rating</option>
              </select>
            </div>
          </div>
        </div>

        {/* Content Layout: Left Sidebar Filters (Desktop) + Right Result Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
          
          {/* Desktop Filter Sidebar */}
          <div className={`lg:block ${filterDrawerOpen ? 'block' : 'hidden'} bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-6 sticky top-36`}>
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center space-x-2">
                <SlidersHorizontal className="w-4 h-4 text-orange-600" />
                <span className="font-bold text-sm text-slate-900">Filter Results</span>
              </div>
              <button
                onClick={resetAllFilters}
                className="text-[11px] font-bold text-orange-600 hover:text-orange-700 transition-colors"
              >
                Reset All
              </button>
            </div>

            {/* Hotel Specific Filters */}
            {activeCategory === 'hotel' && (
              <>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                    Property Type
                  </label>
                  <div className="space-y-1.5">
                    {[
                      { id: 'ALL', label: 'All Stays' },
                      { id: 'sea facing', label: 'Sea Facing / Beachfront' },
                      { id: 'resort', label: 'Resorts & Pools' },
                      { id: 'budget', label: 'Budget Hotels (Under ₹2,000)' },
                      { id: 'family', label: 'Family Friendly' }
                    ].map(pt => (
                      <button
                        key={pt.id}
                        onClick={() => setHotelPropertyType(pt.id)}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center justify-between ${
                          hotelPropertyType === pt.id
                            ? 'bg-orange-50 text-orange-600 font-bold'
                            : 'text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span>{pt.label}</span>
                        {hotelPropertyType === pt.id && <Check className="w-3.5 h-3.5 text-orange-600" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs font-bold mb-2">
                    <span className="uppercase tracking-wider text-slate-500">Max Nightly Price</span>
                    <span className="text-orange-600">₹{hotelMaxPrice}</span>
                  </div>
                  <input
                    type="range"
                    min="1200"
                    max="6000"
                    step="200"
                    value={hotelMaxPrice}
                    onChange={(e) => setHotelMaxPrice(Number(e.target.value))}
                    className="w-full accent-[#FF6E00] cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                    <span>₹1,200</span>
                    <span>₹6,000+</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                    Guest Rating
                  </label>
                  <div className="flex gap-2">
                    {[0, 4.5, 4.8].map(r => (
                      <button
                        key={r}
                        onClick={() => setHotelMinRating(r)}
                        className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-colors flex items-center justify-center space-x-1 ${
                          hotelMinRating === r
                            ? 'bg-orange-50 text-orange-600 border-orange-300'
                            : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                        <span>{r === 0 ? 'Any' : `${r}+`}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* Cab Specific Filters */}
            {activeCategory === 'cab' && (
              <>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                    Vehicle Category
                  </label>
                  <div className="space-y-1.5">
                    {[
                      { id: 'ALL', label: 'All Vehicles' },
                      { id: 'SEDAN', label: 'Sedan (Swift Dzire 4 Pax)' },
                      { id: 'SUV', label: 'SUV (Innova Crysta / Ertiga 6-7 Pax)' },
                      { id: 'TEMPO', label: 'Tempo Traveller (17 Pax)' }
                    ].map(vt => (
                      <button
                        key={vt.id}
                        onClick={() => setCabType(vt.id)}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center justify-between ${
                          cabType === vt.id
                            ? 'bg-orange-50 text-orange-600 font-bold'
                            : 'text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span>{vt.label}</span>
                        {cabType === vt.id && <Check className="w-3.5 h-3.5 text-orange-600" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100">
                  <label className="flex items-center space-x-2 text-xs font-bold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={cabAcOnly}
                      onChange={(e) => setCabAcOnly(e.target.checked)}
                      className="rounded text-orange-600 focus:ring-orange-500 w-4 h-4"
                    />
                    <span>AC Vehicles Only</span>
                  </label>
                </div>
              </>
            )}

            {/* Tour Specific Filters */}
            {activeCategory === 'tour' && (
              <>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                    Trip Duration
                  </label>
                  <div className="space-y-1.5">
                    {[
                      { id: 'ALL', label: 'All Durations' },
                      { id: '2 Nights / 3 Days', label: '2 Nights / 3 Days (Weekend)' },
                      { id: '3 Nights / 4 Days', label: '3 Nights / 4 Days (Full Tour)' },
                      { id: '4+ Nights', label: '4+ Nights (Extended Holiday)' }
                    ].map(d => (
                      <button
                        key={d.id}
                        onClick={() => setTourDuration(d.id)}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center justify-between ${
                          tourDuration === d.id
                            ? 'bg-orange-50 text-orange-600 font-bold'
                            : 'text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span>{d.label}</span>
                        {tourDuration === d.id && <Check className="w-3.5 h-3.5 text-orange-600" />}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between text-xs font-bold mb-2">
                    <span className="uppercase tracking-wider text-slate-500">Max Budget</span>
                    <span className="text-orange-600">₹{tourMaxPrice}</span>
                  </div>
                  <input
                    type="range"
                    min="3000"
                    max="30000"
                    step="1000"
                    value={tourMaxPrice}
                    onChange={(e) => setTourMaxPrice(Number(e.target.value))}
                    className="w-full accent-[#FF6E00] cursor-pointer"
                  />
                </div>
              </>
            )}

            {/* Activity Specific Filters */}
            {activeCategory === 'activity' && (
              <>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                    Activity Type
                  </label>
                  <div className="space-y-1.5">
                    {[
                      { id: 'ALL', label: 'All Water & Beach Sports' },
                      { id: 'Jet Ski', label: 'Jet Ski Adventures' },
                      { id: 'Banana', label: 'Banana Boat Rides' },
                      { id: 'Parasailing', label: 'Parasailing' },
                      { id: 'Speed Boat', label: 'Speed Boat Safaris' },
                      { id: 'ATV', label: 'Quad Bike (ATV 4x4)' },
                      { id: 'Photo', label: 'Photography Sessions' }
                    ].map(act => (
                      <button
                        key={act.id}
                        onClick={() => setActivityType(act.id)}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center justify-between ${
                          activityType === act.id
                            ? 'bg-orange-50 text-orange-600 font-bold'
                            : 'text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span>{act.label}</span>
                        {activityType === act.id && <Check className="w-3.5 h-3.5 text-orange-600" />}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* Bike Specific Filters */}
            {activeCategory === 'bike' && (
              <>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                    Bike Type
                  </label>
                  <div className="space-y-1.5">
                    {[
                      { id: 'ALL', label: 'All Bikes & Scooters' },
                      { id: 'SCOOTER', label: 'Scooter (Activa / Jupiter)' },
                      { id: 'CRUISER', label: 'Cruiser (Royal Enfield Classic / Hunter)' },
                      { id: 'SPORTS', label: 'Sports / Gear Bike (Pulsar 150)' }
                    ].map(bt => (
                      <button
                        key={bt.id}
                        onClick={() => setBikeType(bt.id)}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center justify-between ${
                          bikeType === bt.id
                            ? 'bg-orange-50 text-orange-600 font-bold'
                            : 'text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span>{bt.label}</span>
                        {bikeType === bt.id && <Check className="w-3.5 h-3.5 text-orange-600" />}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* Trust note */}
            <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-100 text-[11px] text-blue-900 space-y-1">
              <div className="font-bold flex items-center space-x-1">
                <ShieldCheck className="w-4 h-4 text-blue-700" />
                <span>GoDigha Price Guarantee</span>
              </div>
              <p className="text-blue-800/80">Direct local vendor rates with zero hidden surge fees.</p>
            </div>

          </div>

          {/* Results Grid / List Column */}
          <div className="lg:col-span-3 space-y-6">
            
            {/* 3. Loading State (Section 17) */}
            {loading ? (
              <div className="space-y-4">
                <div className="flex items-center space-x-3 p-4 bg-orange-50/60 rounded-xl border border-orange-100 text-orange-800 text-xs font-bold animate-pulse">
                  <RefreshCw className="w-4 h-4 animate-spin text-orange-600" />
                  <span>Finding the best options for you in Digha & Mandarmani...</span>
                </div>
                {[1, 2, 3].map(n => (
                  <div key={n} className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 flex flex-col md:flex-row gap-4 animate-pulse">
                    <div className="w-full md:w-60 h-44 bg-slate-200 rounded-xl shrink-0" />
                    <div className="flex-1 space-y-3 py-1">
                      <div className="h-5 bg-slate-200 rounded w-3/4" />
                      <div className="h-3 bg-slate-100 rounded w-1/2" />
                      <div className="h-3 bg-slate-100 rounded w-full" />
                      <div className="flex gap-2 pt-4">
                        <div className="h-9 bg-slate-200 rounded-lg w-28" />
                        <div className="h-9 bg-slate-200 rounded-lg w-28" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <>
                {/* 4. No Results State (Section 16) */}
                {currentCount === 0 ? (
                  <div className="bg-white rounded-2xl border border-slate-200 p-8 sm:p-12 text-center shadow-xs">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-orange-50 flex items-center justify-center text-orange-600">
                      <Search className="w-8 h-8" />
                    </div>
                    <h3 className="text-xl font-black text-slate-900 font-heading">
                      No results found
                    </h3>
                    <p className="text-sm text-slate-600 mt-1 max-w-md mx-auto">
                      We couldn't find anything matching your exact search filters. Try clearing filters or explore our popular categories below.
                    </p>

                    {/* Popular Searches Buttons */}
                    <div className="mt-6 pt-6 border-t border-slate-100">
                      <span className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                        Popular Searches
                      </span>
                      <div className="flex flex-wrap justify-center gap-2">
                        {['Digha Hotels', 'Mandarmani Hotels', 'Holiday Packages', 'Digha Sightseeing', 'Activities', 'Bike Rental Digha'].map(tag => (
                          <button
                            key={tag}
                            onClick={() => onPopularSearchClick(tag)}
                            className="px-3.5 py-1.5 rounded-full bg-slate-100 hover:bg-orange-50 hover:text-orange-600 text-slate-700 text-xs font-semibold transition-colors border border-slate-200"
                          >
                            {tag}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="mt-6">
                      <button
                        onClick={resetAllFilters}
                        className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95"
                      >
                        Explore GoDigha
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    
                    {/* A. HOTEL CARDS (Section 2) */}
                    {activeCategory === 'hotel' && (
                      matchedHotels.map(hotel => (
                        <div
                          key={hotel.id}
                          className="bg-white rounded-2xl border border-slate-200 hover:border-orange-300 hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col md:flex-row group"
                        >
                          <div className="md:w-72 relative overflow-hidden bg-slate-100 shrink-0 aspect-16/10 md:aspect-auto">
                            <img
                              src={hotel.images[0]}
                              alt={hotel.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                            <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-xs text-white text-[11px] font-bold px-2 py-0.5 rounded flex items-center space-x-1">
                              <MapPin className="w-3 h-3 text-amber-400" />
                              <span>{hotel.distanceFromBeach}</span>
                            </div>
                            <div className="absolute top-3 right-3 bg-white/95 text-slate-900 text-xs font-black px-2 py-0.5 rounded shadow-sm flex items-center space-x-1">
                              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                              <span>{hotel.rating}</span>
                              <span className="text-[10px] text-slate-400">({hotel.reviewsCount})</span>
                            </div>
                          </div>

                          <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
                            <div>
                              <div className="text-[11px] font-bold text-blue-900 uppercase tracking-wider">
                                {hotel.location}
                              </div>
                              <h3 className="text-base sm:text-lg font-black text-slate-900 group-hover:text-orange-600 transition-colors mt-0.5 font-heading">
                                {hotel.name}
                              </h3>
                              <p className="text-xs text-slate-500 line-clamp-2 mt-1">
                                {hotel.description}
                              </p>

                              {/* Amenities pills */}
                              <div className="flex flex-wrap gap-1.5 mt-3">
                                {hotel.amenities.slice(0, 4).map((a, i) => (
                                  <span key={i} className="text-[10px] font-semibold bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-slate-200">
                                    {a}
                                  </span>
                                ))}
                                {hotel.amenities.length > 4 && (
                                  <span className="text-[10px] font-bold text-slate-400 px-1 py-0.5">
                                    +{hotel.amenities.length - 4} more
                                  </span>
                                )}
                              </div>
                            </div>

                            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                              <div>
                                <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Starting from</span>
                                <div className="flex items-baseline space-x-1">
                                  <span className="text-xl sm:text-2xl font-black text-slate-900">₹{hotel.startingPrice}</span>
                                  <span className="text-xs text-slate-500">/ night</span>
                                </div>
                              </div>

                              <div className="flex items-center space-x-2">
                                <button
                                  onClick={() => setActiveHotelModal(hotel)}
                                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition-colors flex items-center space-x-1"
                                >
                                  <Eye className="w-3.5 h-3.5 text-slate-600" />
                                  <span>View Hotel</span>
                                </button>
                                <button
                                  onClick={() => onBookHotelRoom(hotel, hotel.rooms[0])}
                                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-xs shadow-md shadow-orange-500/20 transition-all active:scale-95 flex items-center space-x-1.5"
                                >
                                  <span>Book Now</span>
                                  <ArrowRight className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    )}

                    {/* B. CAB CARDS (Section 3) */}
                    {activeCategory === 'cab' && (
                      matchedCabs.map(cab => (
                        <div
                          key={cab.id}
                          className="bg-white rounded-2xl border border-slate-200 hover:border-orange-300 hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col md:flex-row group"
                        >
                          <div className="md:w-64 relative overflow-hidden bg-slate-100 shrink-0 aspect-16/10 md:aspect-auto">
                            <img
                              src={cab.image}
                              alt={cab.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                            <div className="absolute top-3 left-3 bg-[#0f2847] text-amber-300 text-[11px] font-bold px-2.5 py-0.5 rounded flex items-center space-x-1">
                              <Car className="w-3 h-3" />
                              <span>{cab.category}</span>
                            </div>
                          </div>

                          <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
                            <div>
                              <div className="flex items-center space-x-2">
                                <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                                  AC Included
                                </span>
                                <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                                  {cab.seatingCapacity} Passengers
                                </span>
                              </div>

                              <h3 className="text-base sm:text-lg font-black text-slate-900 group-hover:text-orange-600 transition-colors mt-1 font-heading">
                                {cab.name}
                              </h3>

                              <div className="text-xs text-slate-500 space-y-1 mt-2">
                                <div className="flex items-center space-x-1 text-slate-600">
                                  <span>Luggage:</span>
                                  <span className="font-semibold text-slate-800">{cab.luggageCapacity}</span>
                                </div>
                                <div className="flex items-center space-x-1 text-slate-600">
                                  <span>Pickup:</span>
                                  <span className="font-semibold text-slate-800">Digha / Mandarmani / Station doorstep</span>
                                </div>
                              </div>

                              <div className="flex flex-wrap gap-1.5 mt-3">
                                {cab.features.map((f, i) => (
                                  <span key={i} className="text-[10px] font-semibold bg-blue-50 text-blue-900 px-2 py-0.5 rounded border border-blue-100">
                                    ✓ {f}
                                  </span>
                                ))}
                              </div>
                            </div>

                            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                              <div>
                                <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Estimated Fare</span>
                                <div className="flex items-baseline space-x-1">
                                  <span className="text-xl sm:text-2xl font-black text-slate-900">₹{cab.basePrice}</span>
                                  {cab.pricePerKm && <span className="text-xs text-slate-500">(₹{cab.pricePerKm}/km)</span>}
                                </div>
                              </div>

                              <div className="flex items-center space-x-2">
                                <button
                                  onClick={() => setActiveCabModal(cab)}
                                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition-colors flex items-center space-x-1"
                                >
                                  <Eye className="w-3.5 h-3.5 text-slate-600" />
                                  <span>View Details</span>
                                </button>
                                <button
                                  onClick={() => onBookTransport(cab)}
                                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-xs shadow-md shadow-orange-500/20 transition-all active:scale-95 flex items-center space-x-1.5"
                                >
                                  <span>Book Cab</span>
                                  <ArrowRight className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    )}

                    {/* C. TOUR CARDS (Section 4) */}
                    {activeCategory === 'tour' && (
                      matchedTours.map(pkg => (
                        <div
                          key={pkg.id}
                          className="bg-white rounded-2xl border border-slate-200 hover:border-orange-300 hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col md:flex-row group"
                        >
                          <div className="md:w-72 relative overflow-hidden bg-slate-100 shrink-0 aspect-16/10 md:aspect-auto">
                            <img
                              src={pkg.coverImage}
                              alt={pkg.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                            {pkg.badge && (
                              <div className="absolute top-3 left-3 bg-[#FF6E00] text-white text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded shadow-sm">
                                {pkg.badge}
                              </div>
                            )}
                            <div className="absolute top-3 right-3 bg-white/95 text-slate-900 text-xs font-black px-2 py-0.5 rounded shadow-sm flex items-center space-x-1">
                              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                              <span>{pkg.rating}</span>
                              <span className="text-[10px] text-slate-400">({pkg.reviewsCount})</span>
                            </div>
                          </div>

                          <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
                            <div>
                              <div className="flex items-center space-x-2 text-xs text-slate-500 font-semibold">
                                <span className="text-blue-900 font-bold uppercase">{pkg.destination}</span>
                                <span>•</span>
                                <span className="flex items-center space-x-1 text-slate-600">
                                  <Clock className="w-3 h-3 text-orange-500" />
                                  <span>{pkg.duration}</span>
                                </span>
                              </div>

                              <h3 className="text-base sm:text-lg font-black text-slate-900 group-hover:text-orange-600 transition-colors mt-1 font-heading">
                                {pkg.name}
                              </h3>

                              <p className="text-xs text-slate-500 line-clamp-2 mt-1">
                                {pkg.overview}
                              </p>

                              {/* Highlights pills */}
                              <div className="flex flex-wrap gap-1 mt-2.5">
                                {pkg.activities.slice(0, 3).map((act, i) => (
                                  <span key={i} className="text-[10px] font-semibold bg-orange-50 text-orange-800 px-2 py-0.5 rounded border border-orange-100">
                                    {act}
                                  </span>
                                ))}
                              </div>
                            </div>

                            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                              <div>
                                <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Package Price / Person</span>
                                <div className="flex items-baseline space-x-2">
                                  <span className="text-xl sm:text-2xl font-black text-slate-900">
                                    ₹{pkg.discountedPrice || pkg.startingPrice}
                                  </span>
                                  {pkg.discountedPrice && (
                                    <span className="text-xs text-slate-400 line-through">
                                      ₹{pkg.startingPrice}
                                    </span>
                                  )}
                                </div>
                              </div>

                              <div className="flex items-center space-x-2">
                                <button
                                  onClick={() => onSelectPackage(pkg)}
                                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition-colors flex items-center space-x-1"
                                >
                                  <Eye className="w-3.5 h-3.5 text-slate-600" />
                                  <span>View Package</span>
                                </button>
                                <button
                                  onClick={() => onBookPackage(pkg)}
                                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-xs shadow-md shadow-orange-500/20 transition-all active:scale-95 flex items-center space-x-1.5"
                                >
                                  <span>Book Now</span>
                                  <ArrowRight className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    )}

                    {/* D. ACTIVITY CARDS (Section 5) */}
                    {activeCategory === 'activity' && (
                      <div className="space-y-4">
                        {filteredActs.map(act => (
                          <div
                            key={act.id}
                            className="bg-white rounded-2xl border border-slate-200 hover:border-orange-300 hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col md:flex-row group"
                          >
                            <div className="md:w-64 relative overflow-hidden bg-slate-100 shrink-0 aspect-16/10 md:aspect-auto">
                              <img
                                src={act.image}
                                alt={act.name}
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                              />
                              <div className="absolute top-3 left-3 bg-sky-950/80 backdrop-blur-xs text-sky-200 text-[11px] font-bold px-2 py-0.5 rounded flex items-center space-x-1">
                                <Clock className="w-3 h-3 text-sky-400" />
                                <span>{act.duration}</span>
                              </div>
                            </div>

                            <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
                              <div>
                                <div className="text-[11px] font-bold text-blue-900 uppercase tracking-wider">
                                  {act.location}
                                </div>
                                <h3 className="text-base sm:text-lg font-black text-slate-900 group-hover:text-orange-600 transition-colors mt-0.5 font-heading">
                                  {act.name}
                                </h3>
                                <p className="text-xs text-slate-600 mt-1">
                                  {act.description}
                                </p>
                                <div className="mt-2.5 text-[11px] text-slate-500 space-y-0.5">
                                  <p><strong>Suitable for:</strong> {act.suitableFor}</p>
                                  <p className="text-emerald-700"><strong>Safety:</strong> {act.safetyBriefing}</p>
                                </div>
                              </div>

                              <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                <div>
                                  <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Price per Rider / Session</span>
                                  <span className="text-xl sm:text-2xl font-black text-slate-900">₹{act.price}</span>
                                </div>

                                <div className="flex items-center space-x-2">
                                  <button
                                    onClick={() => setActiveActivityModal(act)}
                                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition-colors flex items-center space-x-1"
                                  >
                                    <Eye className="w-3.5 h-3.5 text-slate-600" />
                                    <span>View Activity</span>
                                  </button>
                                  <button
                                    onClick={() => onBookActivity(act)}
                                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-xs shadow-md shadow-orange-500/20 transition-all active:scale-95 flex items-center space-x-1.5"
                                  >
                                    <span>Book Now</span>
                                    <ArrowRight className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* E. BIKE CARDS (Section 6) */}
                    {activeCategory === 'bike' && (
                      matchedBikes.map(bike => (
                        <div
                          key={bike.id}
                          className="bg-white rounded-2xl border border-slate-200 hover:border-orange-300 hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col md:flex-row group"
                        >
                          <div className="md:w-64 relative overflow-hidden bg-slate-100 shrink-0 aspect-16/10 md:aspect-auto">
                            <img
                              src={bike.image}
                              alt={bike.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                            <div className="absolute top-3 left-3 bg-[#061527] text-amber-300 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded shadow-sm">
                              {bike.type}
                            </div>
                            <div className="absolute top-3 right-3 bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-sm">
                              Available
                            </div>
                          </div>

                          <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
                            <div>
                              <div className="text-[11px] font-bold text-blue-900 uppercase tracking-wider">
                                {bike.pickupLocation}
                              </div>
                              <h3 className="text-base sm:text-lg font-black text-slate-900 group-hover:text-orange-600 transition-colors mt-0.5 font-heading">
                                {bike.name}
                              </h3>

                              <div className="text-xs text-slate-600 mt-2 space-y-1">
                                <p><strong>Helmets:</strong> {bike.helmetsIncluded} Helmets Included Free</p>
                                <p><strong>Fuel Policy:</strong> {bike.fuelType} (Customer Refill)</p>
                                <p><strong>Security Deposit:</strong> ₹{bike.securityDeposit} (Fully Refundable)</p>
                              </div>

                              <div className="flex flex-wrap gap-1.5 mt-2.5">
                                {bike.terms.map((t, i) => (
                                  <span key={i} className="text-[10px] font-semibold bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-slate-200">
                                    ✓ {t}
                                  </span>
                                ))}
                              </div>
                            </div>

                            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                              <div>
                                <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Daily Rental</span>
                                <div className="flex items-baseline space-x-1">
                                  <span className="text-xl sm:text-2xl font-black text-slate-900">₹{bike.pricePerDay}</span>
                                  <span className="text-xs text-slate-500">/ 24 hours</span>
                                </div>
                              </div>

                              <div className="flex items-center space-x-2">
                                <button
                                  onClick={() => setActiveBikeModal(bike)}
                                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition-colors flex items-center space-x-1"
                                >
                                  <Eye className="w-3.5 h-3.5 text-slate-600" />
                                  <span>View Details</span>
                                </button>
                                <button
                                  onClick={() => onBookBike(bike)}
                                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-xs shadow-md shadow-orange-500/20 transition-all active:scale-95 flex items-center space-x-1.5"
                                >
                                  <span>Rent Now</span>
                                  <ArrowRight className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    )}

                  </div>
                )}
              </>
            )}

          </div>

        </div>

      </div>

      {/* 5. Hotel Detail Modal with Room Selection */}
      {activeHotelModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-5 sm:p-7 relative animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setActiveHotelModal(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-lg"
            >
              ✕
            </button>

            <div className="text-xs font-bold text-blue-900 uppercase tracking-wider">
              {activeHotelModal.location}
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 mt-1 font-heading">
              {activeHotelModal.name}
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              {activeHotelModal.address} · {activeHotelModal.distanceFromBeach}
            </p>

            <div className="grid grid-cols-2 gap-2 mt-4 rounded-xl overflow-hidden">
              {activeHotelModal.images.map((img, idx) => (
                <img
                  key={idx}
                  src={img}
                  alt={`${activeHotelModal.name} view ${idx + 1}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-40 object-cover"
                />
              ))}
            </div>

            <div className="mt-6">
              <h4 className="text-sm font-bold uppercase tracking-wider text-slate-800 mb-3">
                Select Your Room Option
              </h4>
              <div className="space-y-3">
                {activeHotelModal.rooms.map((room) => (
                  <div
                    key={room.id}
                    className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <h5 className="font-bold text-slate-900 text-sm">{room.name}</h5>
                      <div className="text-xs text-slate-500 flex items-center space-x-2 mt-0.5">
                        <span>Max {room.capacity} Guests</span>
                        <span>·</span>
                        <span>{room.bedType}</span>
                        <span>·</span>
                        <span className="text-emerald-700 font-semibold">{room.availableRooms} rooms available</span>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {room.amenities.map((a, i) => (
                          <span key={i} className="text-[10px] bg-white text-slate-600 px-2 py-0.5 rounded border border-slate-200">
                            {a}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:flex-col sm:items-end gap-2 shrink-0">
                      <div className="text-right">
                        <span className="text-lg font-black text-slate-900">₹{room.pricePerNight}</span>
                        <span className="text-[11px] text-slate-500"> / night</span>
                      </div>
                      <button
                        onClick={() => {
                          const h = activeHotelModal;
                          setActiveHotelModal(null);
                          onBookHotelRoom(h, room);
                        }}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] hover:from-[#E65F00] hover:to-[#FF7A00] text-white font-bold text-xs shadow-md transition-all active:scale-95"
                      >
                        Book This Room
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-5 p-3.5 bg-blue-50/60 rounded-xl border border-blue-100 text-xs text-slate-700 space-y-1">
              <div className="font-bold text-blue-950 flex items-center space-x-1">
                <ShieldCheck className="w-4 h-4 text-blue-700" />
                <span>GoDigha Stay Policies & Assurance</span>
              </div>
              <p>Check-In: <strong>{activeHotelModal.policies.checkIn}</strong> · Check-Out: <strong>{activeHotelModal.policies.checkOut}</strong></p>
              <p>Cancellation: {activeHotelModal.policies.cancellation}</p>
            </div>
          </div>
        </div>
      )}

      {/* 6. Cab Detail Modal */}
      {activeCabModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl p-5 sm:p-6 relative animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setActiveCabModal(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-lg"
            >
              ✕
            </button>
            <div className="aspect-16/10 rounded-xl overflow-hidden bg-slate-100 mb-4">
              <img src={activeCabModal.image} alt={activeCabModal.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-orange-600 bg-orange-50 px-2 py-0.5 rounded">
              {activeCabModal.category}
            </span>
            <h3 className="text-xl font-black text-slate-900 mt-1 font-heading">{activeCabModal.name}</h3>
            <div className="mt-3 space-y-1.5 text-xs text-slate-600">
              <p>• <strong>Seating:</strong> Up to {activeCabModal.seatingCapacity} Passengers</p>
              <p>• <strong>Luggage:</strong> {activeCabModal.luggageCapacity}</p>
              <p>• <strong>AC Status:</strong> Chilled Air Conditioning Guaranteed</p>
              <p>• <strong>Driver:</strong> Professional licensed chauffeur with background verification</p>
            </div>
            <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Fare</span>
                <span className="text-2xl font-black text-slate-900">₹{activeCabModal.basePrice}</span>
              </div>
              <button
                onClick={() => {
                  const c = activeCabModal;
                  setActiveCabModal(null);
                  onBookTransport(c);
                }}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] text-white font-bold text-xs shadow-md transition-all active:scale-95"
              >
                Book This Cab
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7. Bike Detail Modal */}
      {activeBikeModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl p-5 sm:p-6 relative animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setActiveBikeModal(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-lg"
            >
              ✕
            </button>
            <div className="aspect-16/10 rounded-xl overflow-hidden bg-slate-100 mb-4">
              <img src={activeBikeModal.image} alt={activeBikeModal.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-orange-600 bg-orange-50 px-2 py-0.5 rounded">
              {activeBikeModal.type}
            </span>
            <h3 className="text-xl font-black text-slate-900 mt-1 font-heading">{activeBikeModal.name}</h3>
            <div className="mt-3 space-y-1.5 text-xs text-slate-600">
              <p>• <strong>Pickup Location:</strong> {activeBikeModal.pickupLocation}</p>
              <p>• <strong>Helmets:</strong> {activeBikeModal.helmetsIncluded} Helmets Included</p>
              <p>• <strong>Security Deposit:</strong> ₹{activeBikeModal.securityDeposit} (Refunded immediately on return)</p>
              <p>• <strong>Fuel:</strong> {activeBikeModal.fuelType} (Unlimited kilometers in Digha & Mandarmani)</p>
            </div>
            <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Rate / 24 Hours</span>
                <span className="text-2xl font-black text-slate-900">₹{activeBikeModal.pricePerDay}</span>
              </div>
              <button
                onClick={() => {
                  const b = activeBikeModal;
                  setActiveBikeModal(null);
                  onBookBike(b);
                }}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] text-white font-bold text-xs shadow-md transition-all active:scale-95"
              >
                Rent This Bike
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. Activity Detail Modal */}
      {activeActivityModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl p-5 sm:p-6 relative animate-in fade-in zoom-in-95 duration-200">
            <button
              onClick={() => setActiveActivityModal(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-lg"
            >
              ✕
            </button>
            <div className="aspect-16/10 rounded-xl overflow-hidden bg-slate-100 mb-4">
              <img src={activeActivityModal.image} alt={activeActivityModal.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-orange-600 bg-orange-50 px-2 py-0.5 rounded">
              {activeActivityModal.location}
            </span>
            <h3 className="text-xl font-black text-slate-900 mt-1 font-heading">{activeActivityModal.name}</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">{activeActivityModal.description}</p>
            <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-xs text-slate-600">
              <p>• <strong>Duration:</strong> {activeActivityModal.duration}</p>
              <p>• <strong>Suitable for:</strong> {activeActivityModal.suitableFor}</p>
              <p>• <strong>Safety Briefing:</strong> {activeActivityModal.safetyBriefing}</p>
            </div>
            <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Rate / Person</span>
                <span className="text-2xl font-black text-slate-900">₹{activeActivityModal.price}</span>
              </div>
              <button
                onClick={() => {
                  const a = activeActivityModal;
                  setActiveActivityModal(null);
                  onBookActivity(a);
                }}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#FF6E00] to-[#FF8A00] text-white font-bold text-xs shadow-md transition-all active:scale-95"
              >
                Book This Activity
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
