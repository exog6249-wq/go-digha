import {
  TravelPackage,
  Hotel,
  TransportService,
  SightseeingTour,
  WaterActivity,
  BikeRental,
  EventService,
  Review,
  Destination,
  User,
  Booking,
  Enquiry,
  AccountNotification,
  PaymentTransaction
} from '../types';

export const BUSINESS_INFO = {
  name: 'GoDigha Travel & Tourism Services',
  tagline: 'Your Trusted Travel & Tourism Partner for Digha, Mandarmani & Across India',
  address: 'Old Digha, West Bengal 721428, India',
  googlePlusCode: 'JGFG+39 Digha, West Bengal',
  phone: '088491 25029',
  phoneFormatted: '+91 88491 25029',
  whatsapp: '+91 88491 25029',
  whatsappDirectLink: 'https://wa.me/918849125029?text=Hello%20GoDigha%2C%20I%20would%20like%20to%20plan%20a%20trip%21',
  demoPhones: ['+91 88491 25029', '+91 89810 77115', '+91 91628 98477'],
  instagram: '@godigha.official',
  instagramLink: 'https://instagram.com/godigha.official',
  rating: 5.0,
  reviewsCount: 22,
  businessHours: 'Open 24 Hours / 7 Days a Week',
  officialSupportEmail: 'support@godigha.com'
};

export const INITIAL_USERS: User[] = [
  {
    id: 'user_cust_01',
    name: 'Rahul Banerjee',
    email: 'rahul.b@example.com',
    phone: '+91 98301 24567',
    role: 'CUSTOMER',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    goCashBalance: 1450
  },
  {
    id: 'user_vendor_01',
    name: 'Samir Mandal',
    email: 'samir.hotelier@godigha.com',
    phone: '+91 98450 11223',
    role: 'VENDOR',
    vendorId: 'vendor_sea_star',
    goCashBalance: 0
  },
  {
    id: 'user_admin_01',
    name: 'GoDigha Operations Admin',
    email: 'admin@godigha.com',
    phone: '088491 25029',
    role: 'ADMIN',
    goCashBalance: 50000
  }
];

export const DESTINATIONS: Destination[] = [
  {
    id: 'dest_digha',
    name: 'Digha',
    tagline: 'Bengal’s Favorite Pristine Coastal Getaway',
    state: 'West Bengal',
    country: 'India',
    image: '/src/assets/images/hero_digha_sea_1790324572880.jpg',
    description: 'Renowned for its flat, hard beach with casuarina trees, marine aquarium, Amarabati park and fresh seafood delicacies.',
    bestTimeToVisit: 'October to March',
    popularFor: ['Sea Beach', 'Marine Aquarium', 'Casuarina Groves', 'Fresh Seafood'],
    startingPrice: 3499,
    featured: true
  },
  {
    id: 'dest_mandarmani',
    name: 'Mandarmani',
    tagline: 'Long Driveable Shoreline & Seaside Resorts',
    state: 'West Bengal',
    country: 'India',
    image: '/src/assets/images/tour_mandarmani_resort_1790324605435.jpg',
    description: 'Famous for the longest motorable beach in India, secluded resort properties, water sports, and tranquil red crab coastlines.',
    bestTimeToVisit: 'All Year Round',
    popularFor: ['Drive-on Beach', 'Luxury Resorts', 'Jet Ski & Water Sports', 'Red Crabs'],
    startingPrice: 4999,
    featured: true
  },
  {
    id: 'dest_darjeeling',
    name: 'Darjeeling',
    tagline: 'Queen of the Hills & Toy Train Heritage',
    state: 'West Bengal',
    country: 'India',
    image: '/src/assets/images/tour_darjeeling_tea_1790324589896.jpg',
    description: 'Scenic hill station celebrated for its rolling tea plantations, UNESCO Himalayan Railway, Tiger Hill sunrise over Mt. Kanchenjunga.',
    bestTimeToVisit: 'March to May & Sept to Dec',
    popularFor: ['Toy Train', 'Tiger Hill', 'Tea Gardens', 'Batasia Loop'],
    startingPrice: 9499,
    featured: true
  },
  {
    id: 'dest_gangtok',
    name: 'Gangtok & Sikkim',
    tagline: 'Land of Monasteries & Majestic Glacial Lakes',
    state: 'Sikkim',
    country: 'India',
    image: '/src/assets/images/tour_gangtok_ropeway_1790324618130.jpg',
    description: 'Enchanting capital of Sikkim with vibrant Buddhist monasteries, alpine valleys, Tsomgo Lake, Baba Mandir, and cable car ropeways.',
    bestTimeToVisit: 'March to June & Oct to Dec',
    popularFor: ['Cable Car Ropeway', 'Rumtek Monastery', 'Tsomgo Lake', 'Nathula Pass'],
    startingPrice: 11999,
    featured: true
  },
  {
    id: 'dest_manali',
    name: 'Manali',
    tagline: 'Snow-Capped Peaks & Alpine Adventure',
    state: 'Himachal Pradesh',
    country: 'India',
    image: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&auto=format&fit=crop&q=80',
    description: 'Nestled in the Beas river valley, offering snow sports at Solang Valley, Rohtang Pass, apple orchards, and pine forests.',
    bestTimeToVisit: 'October to June',
    popularFor: ['Solang Valley', 'Rohtang Pass', 'Hadimba Temple', 'Paragliding'],
    startingPrice: 13499,
    featured: true
  },
  {
    id: 'dest_ladakh',
    name: 'Ladakh',
    tagline: 'High Mountain Passes & Crystal Blue Lakes',
    state: 'Ladakh',
    country: 'India',
    image: 'https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?w=800&auto=format&fit=crop&q=80',
    description: 'The rooftop of the world featuring Pangong Tso lake, dramatic cliffside gompas, Khardung La pass, and Nubra Valley dunes.',
    bestTimeToVisit: 'May to September',
    popularFor: ['Pangong Lake', 'Nubra Valley', 'Magnetic Hill', 'Ancient Gompas'],
    startingPrice: 22999,
    featured: true
  },
  {
    id: 'dest_bhutan',
    name: 'Bhutan',
    tagline: 'The Dragon Kingdom of Happiness',
    state: 'International',
    country: 'Bhutan',
    image: 'https://images.unsplash.com/photo-1578637387939-43c525550085?w=800&auto=format&fit=crop&q=80',
    description: 'Step into the tranquil Himalayan kingdom of ancient dzongs, pristine valleys, and the legendary cliffside Tiger’s Nest monastery.',
    bestTimeToVisit: 'March to May & Sept to Nov',
    popularFor: ['Tiger’s Nest', 'Punakha Dzong', 'Dochula Pass', 'Thimphu City'],
    startingPrice: 28999,
    featured: true
  },
  {
    id: 'dest_uttarakhand',
    name: 'Uttarakhand',
    tagline: 'Devbhoomi: Sacred Shrines & Himalayan Vistas',
    state: 'Uttarakhand',
    country: 'India',
    image: 'https://images.unsplash.com/photo-1596895111956-bf1cf0599ce5?w=800&auto=format&fit=crop&q=80',
    description: 'Sacred Himalayan temples including Kedarnath & Badrinath, serene lakes of Nainital, yoga capital Rishikesh, and Mussoorie ridges.',
    bestTimeToVisit: 'April to June & Sept to Nov',
    popularFor: ['Kedarnath', 'Rishikesh Rafting', 'Nainital Lake', 'Jim Corbett'],
    startingPrice: 12499,
    featured: true
  },
  {
    id: 'dest_sundarban',
    name: 'Sundarban',
    tagline: 'World’s Largest Mangrove Delta & Royal Tigers',
    state: 'West Bengal',
    country: 'India',
    image: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?w=800&auto=format&fit=crop&q=80',
    description: 'UNESCO World Heritage mangrove forest with motorboat safaris, Sajnekhali watch tower, estuarine crocodiles, and Royal Bengal Tigers.',
    bestTimeToVisit: 'September to March',
    popularFor: ['Tiger Boat Safari', 'Mangrove Forest', 'Watch Towers', 'Village Walks'],
    startingPrice: 4499,
    featured: true
  }
];

export const TRAVEL_PACKAGES: TravelPackage[] = [
  {
    id: 'pkg_digha_weekend_escape',
    name: 'Digha Weekend Escape',
    destination: 'Digha',
    duration: '2 Nights / 3 Days',
    durationDays: 3,
    startingPrice: 3499,
    discountedPrice: 2999,
    badge: 'Bestseller',
    coverImage: '/src/assets/images/hero_digha_sea_1790324572880.jpg',
    gallery: [
      '/src/assets/images/hero_digha_sea_1790324572880.jpg',
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80'
    ],
    overview: 'Perfect beach getaway to Old & New Digha with sea-view hotel stay, Marine Aquarium visit, Amarabati park boating, Udaipur beach sunset, and fresh seafood.',
    itinerary: [
      {
        day: 1,
        title: 'Arrival in Digha & Old Digha Beach Evening',
        description: 'Check in to sea-facing partner hotel. Relax by the casuarina trees, stroll along Old Digha sea wall, and taste fresh coastal delicacies.',
        mealsIncluded: ['Dinner'],
        activities: ['Beach Relaxation', 'Sunset Walk', 'Seafood Market'],
        stayHotel: 'Hotel Sea Star Grand Digha'
      },
      {
        day: 2,
        title: 'New Digha, Marine Aquarium & Udaipur Beach',
        description: 'Morning visit to Marine Aquarium and Science Centre. Afternoon excursion to Udaipur border beach with watersports. Evening park visit.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Marine Aquarium', 'Udaipur Beach', 'Amarabati Park Boating'],
        stayHotel: 'Hotel Sea Star Grand Digha'
      },
      {
        day: 3,
        title: 'Sunrise Beach Stroll & Departure',
        description: 'Catch the magical golden sunrise over the Bay of Bengal, fresh coconut water on beach, check-out with station drop.',
        mealsIncluded: ['Breakfast'],
        activities: ['Morning Sunrise Stroll', 'Station Transfer']
      }
    ],
    hotels: ['Hotel Sea Star Grand Digha (Sea View AC Deluxe)'],
    transportation: 'Dedicated AC Cab for all local sightseeing and station transfers',
    meals: 'Daily Breakfast & Multi-Course Bengali/North Indian Dinner',
    activities: ['Marine Aquarium Tour', 'Udaipur Beach Visit', 'Sunset Photography'],
    inclusions: ['2 Nights AC Deluxe Stay', 'Breakfast & Dinner', 'Private Cab for local tour', 'Digha Station Pickup & Drop'],
    exclusions: ['Train tickets', 'Personal shopping'],
    terms: ['Valid Govt ID required for hotel check-in'],
    groupSize: 'Min 2 travellers',
    category: 'BEACH',
    status: 'ACTIVE',
    featured: true,
    rating: 4.9,
    reviewsCount: 142
  },
  {
    id: 'pkg_mandarmani_beach_escape',
    name: 'Mandarmani Beach Escape',
    destination: 'Mandarmani',
    duration: '2 Nights / 3 Days',
    durationDays: 3,
    startingPrice: 4999,
    discountedPrice: 4299,
    badge: 'Popular',
    coverImage: '/src/assets/images/tour_mandarmani_resort_1790324605435.jpg',
    gallery: [
      '/src/assets/images/tour_mandarmani_resort_1790324605435.jpg',
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&auto=format&fit=crop&q=80'
    ],
    overview: 'Unwind at the longest motorable beach in India. Beachfront resort stay with private lawn, swimming pool, water sports, red crab beach walk, and seaside bonfire.',
    itinerary: [
      {
        day: 1,
        title: 'Check-in to Beach Resort & Sunset Bonfire',
        description: 'Arrive at Mandarmani seaside resort. Enjoy swimming pool, direct beach access, and evening beachside barbecue with bonfire.',
        mealsIncluded: ['Dinner'],
        activities: ['Resort Pool', 'Beach Walk', 'Evening Bonfire'],
        stayHotel: 'Coastal Bay Luxury Beach Resort'
      },
      {
        day: 2,
        title: 'Thrilling Water Sports & Red Crab Delta Exploration',
        description: 'High-speed jet ski and banana boat ride on the beach. Visit the tranquil Mohana delta estuary where millions of red ghost crabs live.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Jet Ski / Banana Ride', 'Mohana Delta Walk', 'Beach ATV Ride'],
        stayHotel: 'Coastal Bay Luxury Beach Resort'
      },
      {
        day: 3,
        title: 'Morning Beach Walk & Departure',
        description: 'Wake up to the sound of breaking waves, poolside breakfast, and return transfer to Digha/Kanthi station.',
        mealsIncluded: ['Breakfast'],
        activities: ['Beach Sunrise', 'Departure Transfer']
      }
    ],
    hotels: ['Coastal Bay Luxury Beach Resort Mandarmani'],
    transportation: 'AC Sedan / SUV for station transfer and estuary visit',
    meals: 'Daily Breakfast & Multi-Cuisine Dinner',
    activities: ['Water Sports Assistance', 'Mohana Estuary Tour', 'Beach Bonfire'],
    inclusions: ['2 Nights Beachfront Resort with Pool Access', 'Daily Breakfast & Dinner', 'Private Cab Transfers'],
    exclusions: ['Watersports fees (discount coupon included)'],
    terms: ['Driving on beach strictly per local administration guidelines'],
    groupSize: 'Min 2 travellers',
    category: 'BEACH',
    status: 'ACTIVE',
    featured: true,
    rating: 4.8,
    reviewsCount: 98
  },
  {
    id: 'pkg_digha_family_holiday',
    name: 'Digha Family Holiday',
    destination: 'Digha',
    duration: '3 Nights / 4 Days',
    durationDays: 4,
    startingPrice: 6999,
    discountedPrice: 5999,
    badge: 'Family Favorite',
    coverImage: '/src/assets/images/digha_coastal_hero_1790504628498.jpg',
    gallery: [
      '/src/assets/images/digha_coastal_hero_1790504628498.jpg'
    ],
    overview: 'Comprehensive family holiday covering Old Digha, New Digha, Amarabati toy train & park, Marine Aquarium, Chandaneswar historic temple, and Talsari scenic beach.',
    itinerary: [
      {
        day: 1,
        title: 'Family Arrival & Evening at Old Digha',
        description: 'Station pickup in comfortable AC vehicle. Check-in to family suite. Evening seaside stroll with hot fish fry and coconut water.',
        mealsIncluded: ['Dinner'],
        activities: ['Family Suite Check-in', 'Seaside Walk'],
        stayHotel: 'Hotel Sea Star Grand Digha'
      },
      {
        day: 2,
        title: 'Science City, Marine Aquarium & Amarabati Park',
        description: 'Fun educational day for kids and family: Marine life exhibits, ropeway cable car in Amarabati park, and paddle boating.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Marine Aquarium', 'Park Boating & Ropeway', 'New Digha Beach Fun'],
        stayHotel: 'Hotel Sea Star Grand Digha'
      },
      {
        day: 3,
        title: 'Chandaneswar Temple, Talsari & Udaipur Coastal Loop',
        description: 'Cross the scenic Odisha border to visit 400-year-old Chandaneswar Shiva Temple, quiet red-crab beaches of Talsari and serene Udaipur.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Historic Temple Darshan', 'Talsari Estuary Walk', 'Udaipur Beach'],
        stayHotel: 'Hotel Sea Star Grand Digha'
      },
      {
        day: 4,
        title: 'Souvenir Shopping & Homeward Journey',
        description: 'Morning shopping for local conch shells, cashews, handloom mats, and drop to Digha station.',
        mealsIncluded: ['Breakfast'],
        activities: ['Handloom Market Shopping', 'Station Drop']
      }
    ],
    hotels: ['Hotel Sea Star Grand Digha (Family 4-Bed Suite)'],
    transportation: 'Dedicated AC Ertiga / Innova for the entire family',
    meals: 'Daily Breakfast & Multi-Course Family Meals',
    activities: ['Temple Darshan', 'Aquarium Tickets Included', 'Park Rides'],
    inclusions: ['3 Nights Family Accommodation', 'Breakfast & Dinner', 'Private Cab for all 4 days', 'Station Transfers'],
    exclusions: ['Personal shopping & ride charges not specified'],
    terms: ['Ideal for families with children and senior citizens'],
    groupSize: 'Min 3 travellers',
    category: 'BEACH',
    status: 'ACTIVE',
    featured: true,
    rating: 5.0,
    reviewsCount: 76
  },
  {
    id: 'pkg_digha_mandarmani_combo',
    name: 'Digha + Mandarmani Combo',
    destination: 'Digha, Mandarmani',
    duration: '3 Nights / 4 Days',
    durationDays: 4,
    startingPrice: 7499,
    discountedPrice: 6499,
    badge: 'Best Value',
    coverImage: '/src/assets/images/tour_mandarmani_resort_1790324605435.jpg',
    gallery: [
      '/src/assets/images/tour_mandarmani_resort_1790324605435.jpg',
      '/src/assets/images/hero_digha_sea_1790324572880.jpg'
    ],
    overview: 'The ultimate twin coastal beach package! Spend 2 nights in buzzing Digha and 1 night in tranquil Mandarmani luxury beach resort with smooth private cab transfer.',
    itinerary: [
      {
        day: 1,
        title: 'Digha Arrival & Beach Promenade',
        description: 'Pickup from Digha station, hotel check-in, Old Digha sea beach walk, evening seafood tasting.',
        mealsIncluded: ['Dinner'],
        activities: ['Old Digha Promenade', 'Seafood Tasting'],
        stayHotel: 'Hotel Sea Star Grand Digha'
      },
      {
        day: 2,
        title: 'Full Day Digha & Udaipur Tour',
        description: 'Marine Aquarium, Amarabati park, and relaxing sunset at Udaipur border beach.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Aquarium Tour', 'Amarabati Park', 'Udaipur Beach'],
        stayHotel: 'Hotel Sea Star Grand Digha'
      },
      {
        day: 3,
        title: 'Transfer to Mandarmani Beach Resort',
        description: 'Scenic coastal highway drive to Mandarmani. Check-in to beachfront resort with pool, watersports, and seaside bonfire.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Coastal Scenic Drive', 'Resort Pool', 'Beach Bonfire'],
        stayHotel: 'Coastal Bay Luxury Beach Resort Mandarmani'
      },
      {
        day: 4,
        title: 'Mandarmani Beach & Departure Transfer',
        description: 'Morning red crab walk, breakfast by the beach, and return cab transfer to Digha or Contai.',
        mealsIncluded: ['Breakfast'],
        activities: ['Beach Walk', 'Departure Drop']
      }
    ],
    hotels: ['Hotel Sea Star Grand Digha (2 Nights) + Coastal Bay Beach Resort Mandarmani (1 Night)'],
    transportation: 'Dedicated AC Sedan / SUV for all transfers and inter-city tour',
    meals: 'Daily Breakfast & Dinner at both hotels',
    activities: ['Digha Sightseeing', 'Mandarmani Beach Access', 'Bonfire Evening'],
    inclusions: ['3 Nights Split Stay in Digha & Mandarmani', 'All Meals Included', 'Private Cab for the full duration'],
    exclusions: ['Watersports fees'],
    terms: ['Luggage transfer assistance included between hotels'],
    groupSize: 'Min 2 travellers',
    category: 'BEACH',
    status: 'ACTIVE',
    featured: true,
    rating: 4.9,
    reviewsCount: 115
  },
  {
    id: 'pkg_darjeeling_01',
    name: 'Darjeeling Himalayan Heritage Tour',
    destination: 'Darjeeling',
    duration: '3 Nights / 4 Days',
    durationDays: 4,
    startingPrice: 9499,
    discountedPrice: 8499,
    badge: 'Bestseller',
    coverImage: '/src/assets/images/tour_darjeeling_tea_1790324589896.jpg',
    gallery: [
      '/src/assets/images/tour_darjeeling_tea_1790324589896.jpg',
      'https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80'
    ],
    overview: 'Experience the romantic charm of Darjeeling with Tiger Hill sunrise overlooking Mt. Kanchenjunga, UNESCO heritage Himalayan Toy Train, tea estate walk, and Batasia Loop.',
    itinerary: [
      {
        day: 1,
        title: 'Arrival at NJP / Bagdogra & Transfer to Darjeeling',
        description: 'Warm welcome by GoDigha representative. Scenic 3-hour drive through lush tea gardens and winding pine-lined hills. Check-in to hotel and evening leisure at Mall Road.',
        mealsIncluded: ['Dinner'],
        activities: ['Scenic Hill Drive', 'Mall Road & Chowrasta Stroll'],
        stayHotel: 'Hotel Pine Ridge Heritage'
      },
      {
        day: 2,
        title: 'Early Morning Tiger Hill Sunrise & City Sightseeing',
        description: 'Witness the golden rays illuminate Mt. Kanchenjunga at 4:00 AM from Tiger Hill. Visit Ghoom Monastery, Batasia Loop, Himalayan Mountaineering Institute, and Padmaja Naidu Zoo.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Tiger Hill Sunrise', 'Batasia Loop', 'HMI Zoo Tour', 'Japanese Peace Pagoda'],
        stayHotel: 'Hotel Pine Ridge Heritage'
      },
      {
        day: 3,
        title: 'Happy Valley Tea Garden & Heritage Toy Train Ride',
        description: 'Guided walk through Happy Valley Tea Estate with artisanal tea tasting session. Board the historic Darjeeling Himalayan Toy Train for a nostalgic joy ride.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Tea Estate Walk', 'Toy Train Joy Ride', 'Souvenir Shopping'],
        stayHotel: 'Hotel Pine Ridge Heritage'
      },
      {
        day: 4,
        title: 'Departure Transfer to NJP / Bagdogra',
        description: 'Delicious breakfast with morning mountain view. Comfortable transfer back with unforgettable Himalayan memories.',
        mealsIncluded: ['Breakfast'],
        activities: ['Morning Views', 'Airport/Station Drop']
      }
    ],
    hotels: ['Hotel Pine Ridge Heritage (3-Star Deluxe)'],
    transportation: 'Dedicated AC Sedan / SUV with experienced mountain chauffeur',
    meals: 'Daily Breakfast & Multi-Course Dinner included',
    activities: ['Tiger Hill Sunrise', 'Toy Train Joy Ride', 'Tea Garden Tour', 'Monastery Sightseeing'],
    inclusions: [
      '3 Nights Deluxe Accommodation on Twin Sharing',
      'Pickup & Drop from NJP Railway Station or Bagdogra Airport',
      'All Sightseeing in private vehicle',
      'Daily Breakfast and Dinner',
      'Toy train tickets pre-booked',
      '24/7 GoDigha On-Call Chauffeur & Coordinator Assistance'
    ],
    exclusions: [
      'Train or flight fare to NJP/Bagdogra',
      'Camera / Video fees at monuments',
      'Personal expenses & laundry',
      'Any extra meals or beverages'
    ],
    terms: [
      'Booking confirmed with 30% advance deposit',
      'Free cancellation up to 7 days before departure',
      'Govt Photo ID required for all travellers'
    ],
    groupSize: 'Min 2, Max 20 travellers',
    category: 'HILL_STATION',
    status: 'ACTIVE',
    featured: true,
    rating: 4.9,
    reviewsCount: 38
  },
  {
    id: 'pkg_sikkim_01',
    name: 'Sikkim & Gangtok Alpine Explorer',
    destination: 'Gangtok & Sikkim',
    duration: '4 Nights / 5 Days',
    durationDays: 5,
    startingPrice: 12999,
    discountedPrice: 11499,
    badge: 'Popular',
    coverImage: '/src/assets/images/tour_gangtok_ropeway_1790324618130.jpg',
    gallery: [
      '/src/assets/images/tour_gangtok_ropeway_1790324618130.jpg',
      'https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=800&auto=format&fit=crop&q=80'
    ],
    overview: 'Discover Sikkim’s spiritual calm, glacial mountain lakes at 12,400 ft, Tibetan monasteries, floral viewpoints, and thrilling ropeway cable rides over Gangtok.',
    itinerary: [
      {
        day: 1,
        title: 'Bagdogra / NJP to Gangtok',
        description: 'Drive along the turquoise Teesta River to Gangtok (5,500 ft). Check-in and evening walk at MG Marg pedestrian promenade.',
        mealsIncluded: ['Dinner'],
        activities: ['Teesta River Drive', 'MG Marg Walk'],
        stayHotel: 'The Royal Oak Gangtok'
      },
      {
        day: 2,
        title: 'Excursion to Glacial Tsomgo Lake & Baba Mandir',
        description: 'Day trip to sacred Tsomgo Lake surrounded by snow-covered ridges. Visit historic Baba Harbhajan Singh Memorial Mandir.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Tsomgo Lake Excursion', 'Yak Rides', 'Baba Mandir Visit'],
        stayHotel: 'The Royal Oak Gangtok'
      },
      {
        day: 3,
        title: 'Gangtok Full Day Sightseeing & Cable Car Ropeway',
        description: 'Panoramic cable car ride over Gangtok valley. Visit Rumtek Monastery, Do Drul Chorten, Flower Exhibition Centre, and Ban Jhakri Falls.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Ropeway Cable Ride', 'Rumtek Monastery', 'Waterfall Park'],
        stayHotel: 'The Royal Oak Gangtok'
      },
      {
        day: 4,
        title: 'Namchi & Chardham Day Tour',
        description: 'Visit the colossal 87-ft statue of Lord Shiva at Siddheshwar Dham (Chardham) and the golden Samdruptse monastery.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Chardham Namchi', 'Samdruptse Hill', 'Temi Tea Garden'],
        stayHotel: 'The Royal Oak Gangtok'
      },
      {
        day: 5,
        title: 'Gangtok to NJP / Bagdogra Departure',
        description: 'Hearty breakfast followed by smooth departure transfer with scenic viewpoints on the way.',
        mealsIncluded: ['Breakfast'],
        activities: ['Departure Transfer']
      }
    ],
    hotels: ['The Royal Oak Gangtok (Deluxe Valley View)'],
    transportation: 'Dedicated AC Bolero / Scorpio / Innova with mountain permit',
    meals: 'Daily Breakfast & Multi-Cuisine Dinner',
    activities: ['Tsomgo Lake', 'Gangtok Ropeway', 'Rumtek Monastery', 'MG Marg Leisure'],
    inclusions: [
      '4 Nights Deluxe Valley-Facing Accommodation',
      'All transfers and sightseeing by private vehicle',
      'Sikkim Protected Area Permits assistance',
      'Breakfast and Dinner daily',
      'All toll taxes, parking, and driver allowances'
    ],
    exclusions: ['Nathula Pass permit fee (subject to military approval)', 'Personal expenses'],
    terms: ['Inner line permits require Passport/Voter ID and 4 passport photos'],
    groupSize: 'Min 2 travellers',
    category: 'HILL_STATION',
    status: 'ACTIVE',
    featured: true,
    rating: 5.0,
    reviewsCount: 29
  },
  {
    id: 'pkg_digha_weekend',
    name: 'Digha Coastal Beach & Casuarina Escape',
    destination: 'Digha',
    duration: '2 Nights / 3 Days',
    durationDays: 3,
    startingPrice: 3999,
    discountedPrice: 3499,
    badge: 'GoDigha Signature',
    coverImage: '/src/assets/images/hero_digha_sea_1790324572880.jpg',
    gallery: [
      '/src/assets/images/hero_digha_sea_1790324572880.jpg',
      '/src/assets/images/tour_mandarmani_resort_1790324605435.jpg'
    ],
    overview: 'The signature GoDigha beach weekend package designed with handpicked sea-facing hotel stays, railway station pickup/drop, local sightseeing, fresh seafood meal options, and beach bike rentals.',
    itinerary: [
      {
        day: 1,
        title: 'Arrival at Digha & Sea Beach Welcome',
        description: 'VIP pickup from Digha Railway Station / Bus Stand by GoDigha car. Check-in to sea-view hotel. Afternoon beach relaxation, coconut water, and sunset at Old Digha sea front.',
        mealsIncluded: ['Dinner'],
        activities: ['Station Pickup', 'Old Digha Promenade Sunset', 'Fresh Fried Fish Tasting'],
        stayHotel: 'Hotel Sea Star Grand Digha'
      },
      {
        day: 2,
        title: 'Local Sightseeing & Water Fun',
        description: 'Explore New Digha Beach, Marine Aquarium (India’s largest coastal research facility), Amarabati Park with ropeway, Chandaneswar Shiva Temple, and Udaipur Beach borderline.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Marine Aquarium Tour', 'Amarabati Ropeway', 'Udaipur Beach Water Scooter', 'Evening Shopping'],
        stayHotel: 'Hotel Sea Star Grand Digha'
      },
      {
        day: 3,
        title: 'Sunrise at Casuarina Beach & Departure',
        description: 'Early morning quiet beach walk. Enjoy authentic Bengali breakfast, pack local cashew nuts and handicrafts, with smooth railway station drop.',
        mealsIncluded: ['Breakfast'],
        activities: ['Morning Beach Walk', 'Handicraft & Cashew Shopping', 'Station Drop']
      }
    ],
    hotels: ['Hotel Sea Star Grand Digha (AC Sea View Room)'],
    transportation: 'Dedicated AC car for station transfers and local sightseeing',
    meals: 'Breakfast and Dinner with choice of Fresh Pomfret / Prawn / Bengali Thali or Veg',
    activities: ['Old Digha Seafront', 'Marine Aquarium', 'Amarabati Park', 'Udaipur Beach Ride'],
    inclusions: [
      '2 Nights AC Sea View Hotel Stay',
      'Both-way Digha Railway Station / Bus Stand Transfers',
      'Half-day Local Sightseeing in dedicated AC car',
      'Complimentary 1-hour Udaipur Beach Water Activity coupon',
      'Breakfast and Dinner included'
    ],
    exclusions: ['Entry tickets at parks', 'Personal expenses'],
    terms: ['Flexible check-in, 100% money back guarantee on 48h cancellation'],
    groupSize: 'Solo, Couples, Families, Groups',
    category: 'BEACH',
    status: 'ACTIVE',
    featured: true,
    rating: 5.0,
    reviewsCount: 44
  },
  {
    id: 'pkg_mandarmani_01',
    name: 'Mandarmani Luxury Seaside Beach Vacation',
    destination: 'Mandarmani',
    duration: '2 Nights / 3 Days',
    durationDays: 3,
    startingPrice: 5999,
    discountedPrice: 4999,
    badge: 'Luxury Resort',
    coverImage: '/src/assets/images/tour_mandarmani_resort_1790324605435.jpg',
    gallery: [
      '/src/assets/images/tour_mandarmani_resort_1790324605435.jpg',
      '/src/assets/images/hero_digha_sea_1790324572880.jpg'
    ],
    overview: 'Unwind at top-rated beachfront resorts in Mandarmani featuring private swimming pools, direct beach access, jet skiing, beach quad biking, and sunset beach barbecue.',
    itinerary: [
      {
        day: 1,
        title: 'Check-in to Beachfront Resort & Poolside Sunset',
        description: 'Chauffeured pickup from Digha / Contai. Arrive at luxury seaside resort. Afternoon dip in infinity pool followed by beach stroll observing red ghost crabs.',
        mealsIncluded: ['Dinner'],
        activities: ['Beach Resort Check-in', 'Poolside Sunset', 'Beach Bonfire'],
        stayHotel: 'Coastal Bay Luxury Resort Mandarmani'
      },
      {
        day: 2,
        title: 'Beach Thrills: Jet Ski, Speed Boat & Digha Muhana',
        description: 'Thrilling water sports at Mandarmani beach: high-speed jet ski and banana boat ride. Afternoon excursion to Digha Muhana fish harbor to watch fishing trawlers.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Jet Skiing', 'Banana Boat Ride', 'Mohana Fishing Port Tour', 'Seafood Barbecue'],
        stayHotel: 'Coastal Bay Luxury Resort Mandarmani'
      },
      {
        day: 3,
        title: 'Leisurely Seaside Breakfast & Departure',
        description: 'Wake up to the sound of breaking waves. Enjoy buffet breakfast by the beach followed by hassle-free checkout and return drop.',
        mealsIncluded: ['Breakfast'],
        activities: ['Morning Ocean Walk', 'Return Transfer']
      }
    ],
    hotels: ['Coastal Bay Luxury Resort Mandarmani (Poolside Cottages)'],
    transportation: 'Dedicated AC car for pickup, drop & sightseeing',
    meals: 'Daily Buffet Breakfast & Chef’s Special Dinner',
    activities: ['Water Sports at Beach', 'Poolside Relaxation', 'Digha Muhana Excursion'],
    inclusions: [
      '2 Nights Luxury Resort Accommodation',
      'Complimentary Swimming Pool Access',
      'Daily Buffet Breakfast and Dinner',
      'Dedicated AC Car Transfers',
      '20% Discount on Resort Water Activities'
    ],
    exclusions: ['Fuel for personal drive', 'Hard drinks'],
    terms: ['Valid Govt Photo ID required at resort check-in'],
    groupSize: 'Min 2 travellers',
    category: 'BEACH',
    status: 'ACTIVE',
    featured: true,
    rating: 4.9,
    reviewsCount: 31
  },
  {
    id: 'pkg_manali_01',
    name: 'Manali & Solang Valley Snow Panorama',
    destination: 'Manali',
    duration: '4 Nights / 5 Days',
    durationDays: 5,
    startingPrice: 14999,
    discountedPrice: 13499,
    badge: 'Snow Special',
    coverImage: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&auto=format&fit=crop&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?w=800&auto=format&fit=crop&q=80'
    ],
    overview: 'Experience the magic of Himachal with Solang valley snow adventures, Atal Tunnel, Old Manali hippie cafes, ancient Hadimba temple, and Vashisht hot water springs.',
    itinerary: [
      {
        day: 1,
        title: 'Arrival in Manali & Local Leisure',
        description: 'Check-in to pine-view resort. Afternoon stroll around Mall road, Tibetan monastery, and Old Manali riverside.',
        mealsIncluded: ['Dinner'],
        activities: ['Mall Road Stroll', 'Riverside Walk'],
        stayHotel: 'Snow Valley Grand Resort'
      },
      {
        day: 2,
        title: 'Solang Valley & Atal Tunnel Excursion',
        description: 'Exhilarating day at Solang Valley with paragliding, zorbing, and snow scooter. Drive through the historic Atal Tunnel into Lahaul valley.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Solang Valley Snow Sports', 'Atal Tunnel Drive', 'Sissu Waterfalls'],
        stayHotel: 'Snow Valley Grand Resort'
      },
      {
        day: 3,
        title: 'Kullu Valley & Naggar Castle Day Trip',
        description: 'River rafting in the thrilling rapids of Beas river in Kullu. Visit historic Naggar Castle and Nicholas Roerich art gallery.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['White Water Rafting', 'Naggar Castle', 'Kullu Shawl Weaving'],
        stayHotel: 'Snow Valley Grand Resort'
      },
      {
        day: 4,
        title: 'Manali Local Heritage & Cafe Trail',
        description: 'Visit 500-year-old timber Hadimba Devi Temple, Manu Temple, and hot sulphur springs of Vashisht village.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Hadimba Temple', 'Vashisht Springs', 'Old Manali Cafes'],
        stayHotel: 'Snow Valley Grand Resort'
      },
      {
        day: 5,
        title: 'Departure from Manali',
        description: 'Breakfast with morning snow peak views and Volvo bus / cab transfer.',
        mealsIncluded: ['Breakfast'],
        activities: ['Departure']
      }
    ],
    hotels: ['Snow Valley Grand Resort (Balcony Mountain View)'],
    transportation: 'Dedicated AC car for all tours + Atal Tunnel permits',
    meals: 'Daily Breakfast and Multi-Cuisine Dinner',
    activities: ['Solang Valley Adventures', 'Atal Tunnel Drive', 'Kullu Rafting', 'Naggar Castle'],
    inclusions: ['4 Nights Hotel Stay', 'Private cab for all days', 'Daily breakfast & dinner'],
    exclusions: ['Adventure activities tickets', 'Lahaul local cab if snow barrier closed'],
    terms: ['Heated rooms provided during winter season'],
    groupSize: 'Min 2 travellers',
    category: 'HILL_STATION',
    status: 'ACTIVE',
    featured: true,
    rating: 4.8,
    reviewsCount: 26
  },
  {
    id: 'pkg_bhutan_01',
    name: 'Bhutan: Kingdom of Thunder Dragon',
    destination: 'Bhutan',
    duration: '5 Nights / 6 Days',
    durationDays: 6,
    startingPrice: 31999,
    discountedPrice: 28999,
    badge: 'International',
    coverImage: 'https://images.unsplash.com/photo-1578637387939-43c525550085?w=800&auto=format&fit=crop&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1578637387939-43c525550085?w=800&auto=format&fit=crop&q=80'
    ],
    overview: 'Enter the happiest country on Earth. Visit Thimphu Buddha Dordenma, Punakha fortress between two glacial rivers, and hike to the hanging cliffside Tiger’s Nest (Taktsang Monastery).',
    itinerary: [
      {
        day: 1,
        title: 'Phuentsholing / Paro to Thimphu',
        description: 'Immigration clearance and transfer to Bhutan’s capital Thimphu. Check-in and evening walk through Clock Tower Square.',
        mealsIncluded: ['Dinner'],
        activities: ['Bhutan Entry', 'Thimphu City Walk'],
        stayHotel: 'Hotel Thimphu Grand'
      },
      {
        day: 2,
        title: 'Thimphu Cultural Treasures',
        description: 'Visit the colossal Buddha Dordenma statue overlooking the valley, Motithang Takin Preserve, Memorial Chorten, and National Textile Museum.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Buddha Dordenma', 'Takin Wildlife Preserve', 'Folk Heritage'],
        stayHotel: 'Hotel Thimphu Grand'
      },
      {
        day: 3,
        title: 'Dochula Pass to Punakha Valley',
        description: 'Drive across Dochula Pass (108 memorial stupas with panoramic Eastern Himalayas). Tour the majestic Punakha Dzong at the confluence of Pho Chhu and Mo Chhu.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Dochula Pass (3,100m)', 'Punakha Dzong', 'Suspension Bridge Walk'],
        stayHotel: 'Punakha River Resort'
      },
      {
        day: 4,
        title: 'Punakha to Paro Valley',
        description: 'Scenic transfer to Paro valley. Visit Ta Dzong (National Museum), Rinpung Dzong, and Kyichu Lhakhang.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Paro Dzong', 'National Museum', 'Traditional Bhutanese Archery'],
        stayHotel: 'Paro Heritage Haven'
      },
      {
        day: 5,
        title: 'Trek to Tiger’s Nest Monastery (Taktsang)',
        description: 'The crowning jewel of Bhutan: 4-hour trek to Taktsang monastery perched on a 900m sheer cliff. Breathtaking spiritual energy and vistas.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Tiger’s Nest Trek', 'Hot Stone Bath Experience'],
        stayHotel: 'Paro Heritage Haven'
      },
      {
        day: 6,
        title: 'Departure from Paro',
        description: 'Breakfast and airport/border transfer with auspicious Bhutanese blessings.',
        mealsIncluded: ['Breakfast'],
        activities: ['Departure Transfer']
      }
    ],
    hotels: ['3-Star Certified Bhutanese Heritage Hotels'],
    transportation: 'Dedicated Toyota Coaster / HiAce with licensed Bhutanese English/Hindi speaking guide',
    meals: 'All Meals Included (Daily Breakfast, Lunch & Dinner)',
    activities: ['Tiger’s Nest Hike', 'Dochula Pass', 'Punakha Dzong', 'Archery Demo'],
    inclusions: [
      '5 Nights Standard Bhutan Hotel Stay',
      'All meals (Breakfast, Lunch, Dinner)',
      'Certified Bhutanese Tourist Guide & Chauffeur',
      'Bhutan Entry Permits & Monument Entry fees',
      'SDF (Sustainable Development Fee) documentation assistance'
    ],
    exclusions: ['Airfare to Paro / Bagdogra', 'Personal shopping'],
    terms: ['Valid Indian Passport (min 6 months validity) or Voter ID card mandatory'],
    groupSize: 'Min 2 travellers',
    category: 'HERITAGE',
    status: 'ACTIVE',
    featured: true,
    rating: 5.0,
    reviewsCount: 19
  },
  {
    id: 'pkg_uttarakhand_01',
    name: 'Uttarakhand Devbhoomi & Kedarnath Pilgrimage',
    destination: 'Uttarakhand',
    duration: '5 Nights / 6 Days',
    durationDays: 6,
    startingPrice: 14999,
    discountedPrice: 12499,
    badge: 'Spiritual',
    coverImage: 'https://images.unsplash.com/photo-1596895111956-bf1cf0599ce5?w=800&auto=format&fit=crop&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1596895111956-bf1cf0599ce5?w=800&auto=format&fit=crop&q=80'
    ],
    overview: 'Sacred journey to Kedarnath Jyotirlinga in Garhwal Himalayas with Haridwar Ganga Aarti, Devprayag sangam, Guptkashi, and Rishikesh river banks.',
    itinerary: [
      {
        day: 1,
        title: 'Haridwar / Rishikesh to Guptkashi',
        description: 'Drive along holy rivers Alaknanda and Mandakini with views of Devprayag and Rudraprayag sangams. Arrive in Guptkashi.',
        mealsIncluded: ['Dinner'],
        activities: ['Devprayag Sangam', 'Rudraprayag View'],
        stayHotel: 'Kedar Valley Camp Resort'
      },
      {
        day: 2,
        title: 'Guptkashi to Gaurikund & Trek to Kedarnath',
        description: 'Early morning drive to Sonprayag and Gaurikund. Begin the sacred 16km trek (or pony/helicopter) to Kedarnath temple at 11,755 ft. Evening Aarti at Kedarnath.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Kedarnath Trek', 'Evening Kedar Aarti'],
        stayHotel: 'Kedarnath Temple Guest House / Tents'
      },
      {
        day: 3,
        title: 'Kedarnath Darshan & Trek Down to Guptkashi',
        description: 'Morning VIP Darshan of sacred Kedarnath Jyotirlinga surrounded by snow peaks. Trek down to Gaurikund and transfer back to Guptkashi.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Morning Jyotirlinga Darshan', 'Trek Down'],
        stayHotel: 'Kedar Valley Camp Resort'
      },
      {
        day: 4,
        title: 'Guptkashi to Rishikesh',
        description: 'Scenic return journey to Rishikesh. Check-in to riverside resort. Attend soul-stirring Ganga Aarti at Triveni Ghat.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Triveni Ghat Ganga Aarti', 'Ram Jhula Walk'],
        stayHotel: 'Ganga View Retreat Rishikesh'
      },
      {
        day: 5,
        title: 'Rishikesh Rafting & Ashrams Day',
        description: 'Morning thrilling white water river rafting in Ganges. Visit Beatles Ashram and Parmarth Niketan.',
        mealsIncluded: ['Breakfast', 'Dinner'],
        activities: ['Ganges River Rafting', 'Beatles Ashram', 'Neer Garh Waterfall'],
        stayHotel: 'Ganga View Retreat Rishikesh'
      },
      {
        day: 6,
        title: 'Departure from Haridwar / Dehradun',
        description: 'Breakfast and drop at Haridwar station or Dehradun Jolly Grant airport.',
        mealsIncluded: ['Breakfast'],
        activities: ['Departure Drop']
      }
    ],
    hotels: ['Deluxe Valley Resorts + Kedarnath Stay'],
    transportation: 'Dedicated AC Tempo / Innova for hill circuits',
    meals: 'Pure Vegetarian Breakfast & Dinner',
    activities: ['Kedarnath Darshan', 'Ganga Aarti', 'White Water Rafting'],
    inclusions: ['All hill transport', '5 nights accommodation', 'Helicopter/Pony booking assistance'],
    exclusions: ['Helicopter tickets (booked on IRCTC portal at actuals)', 'Pony / Doli charges'],
    terms: ['Biometric registration mandatory before trip'],
    groupSize: 'Min 2, Groups welcome',
    category: 'PILGRIMAGE',
    status: 'ACTIVE',
    featured: true,
    rating: 4.9,
    reviewsCount: 24
  },
  {
    id: 'pkg_sundarban_01',
    name: 'Sundarban Mangrove & Tiger Delta Safari',
    destination: 'Sundarban',
    duration: '2 Nights / 3 Days',
    durationDays: 3,
    startingPrice: 4999,
    discountedPrice: 4499,
    badge: 'Wild Safari',
    coverImage: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?w=800&auto=format&fit=crop&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?w=800&auto=format&fit=crop&q=80'
    ],
    overview: 'World Heritage mangrove delta expedition: Exclusive motorboat safari through narrow creeks, Sajnekhali watchtower, crocodile breeding center, and local Baul music performances.',
    itinerary: [
      {
        day: 1,
        title: 'Kolkata to Godhkhali & Cruise to Sundarban',
        description: 'Morning pickup from Kolkata in AC vehicle to Godhkhali port. Board motorized cruise vessel. Check-in to eco-resort followed by village walk and tribal folk dance.',
        mealsIncluded: ['Lunch', 'Dinner'],
        activities: ['River Cruise', 'Village Walk', 'Tribal Jhumur Dance'],
        stayHotel: 'Sundarban Tiger Roar Eco Resort'
      },
      {
        day: 2,
        title: 'Full Day Deep Forest Boat Safari & Watch Towers',
        description: 'Thrilling day-long cruise through rivers Matla and Bidya. Visit Sajnekhali, Sudhanyakhali, and Do Banki canopy walk. Spot tigers, deer, wild boars, and river dolphins.',
        mealsIncluded: ['Breakfast', 'Lunch', 'Dinner'],
        activities: ['Canopy Walk', 'Tiger Watch Towers', 'Delta Bird Watching'],
        stayHotel: 'Sundarban Tiger Roar Eco Resort'
      },
      {
        day: 3,
        title: 'Pakhiralay Morning Walk & Return to Kolkata',
        description: 'Morning bird watching walk, traditional Bengali fish lunch on boat, and return drive to Kolkata.',
        mealsIncluded: ['Breakfast', 'Lunch'],
        activities: ['Morning Creek Cruise', 'Return Drop to Kolkata']
      }
    ],
    hotels: ['Sundarban Tiger Roar Eco Resort (AC Cottage)'],
    transportation: 'AC Road transport Kolkata-Godhkhali + Special Safari Motorboat',
    meals: 'All Meals Included (Authentic Bengali Fresh River Fish Thalis & Veg)',
    activities: ['Delta Boat Safari', 'Watchtower Views', 'Baul Musical Evening'],
    inclusions: ['Kolkata pickup and drop', '2 nights eco resort stay', 'All meals and tea/snacks', 'Forest entry permits and naturalist guide'],
    exclusions: ['Camera fees', 'Personal tips'],
    terms: ['ID proof required for forest entry permit'],
    groupSize: 'Min 2 travellers',
    category: 'WILDLIFE',
    status: 'ACTIVE',
    featured: true,
    rating: 4.9,
    reviewsCount: 27
  }
];

export const HOTELS: Hotel[] = [
  {
    id: 'hotel_sea_star',
    vendorId: 'vendor_sea_star',
    name: 'Hotel Sea Star Grand Digha',
    location: 'Old Digha, West Bengal',
    address: 'Near Old Digha Sea Beach, Barrister Colony, Old Digha 721428',
    distanceFromBeach: '150 meters from Sea Beach (2 min walk)',
    rating: 4.9,
    reviewsCount: 86,
    images: [
      '/src/assets/images/hero_digha_sea_1790324572880.jpg',
      'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Premier associated hotel in Old Digha offering spotlessly clean sea-view rooms, 24-hour room service, in-house multi-cuisine restaurant serving authentic seafood, and free parking.',
    amenities: ['Free High-Speed Wi-Fi', 'AC & Non-AC Rooms', 'Sea Facing Balcony', 'Multi-Cuisine Restaurant', '24h Room Service', 'Power Backup', 'Free Parking', 'Travel Desk'],
    startingPrice: 1799,
    rooms: [
      {
        id: 'room_deluxe_ac',
        name: 'Deluxe AC Sea View Room',
        capacity: 2,
        bedType: '1 King Bed',
        pricePerNight: 2199,
        amenities: ['Sea View Balcony', 'Split AC', 'LED TV', 'Geyser', 'Free Wi-Fi'],
        image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=600&auto=format&fit=crop&q=80',
        availableRooms: 8
      },
      {
        id: 'room_super_deluxe',
        name: 'Super Deluxe Family Suite (4 Pax)',
        capacity: 4,
        bedType: '2 Double Beds',
        pricePerNight: 3499,
        amenities: ['Spacious Balcony', 'Split AC', 'Sofa Seating', 'Mini Fridge', 'Room Service'],
        image: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=600&auto=format&fit=crop&q=80',
        availableRooms: 4
      },
      {
        id: 'room_standard_ac',
        name: 'Standard AC Double Room',
        capacity: 2,
        bedType: '1 Queen Bed',
        pricePerNight: 1799,
        amenities: ['AC', 'Attached Bath', 'Geyser', 'Cable TV'],
        image: 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=600&auto=format&fit=crop&q=80',
        availableRooms: 6
      }
    ],
    policies: {
      checkIn: '11:00 AM',
      checkOut: '10:00 AM',
      cancellation: 'Free cancellation up to 48 hours before check-in date.'
    },
    contactPhone: '088491 25029',
    featured: true
  },
  {
    id: 'hotel_coastal_bay',
    vendorId: 'vendor_sea_star',
    name: 'Coastal Bay Luxury Beach Resort Mandarmani',
    location: 'Mandarmani Beachfront, West Bengal',
    address: 'Direct Sea Beach, Mandarmani Coastal Road, Purba Medinipur 721455',
    distanceFromBeach: 'Zero meters (Direct on beach with private lawn)',
    rating: 4.8,
    reviewsCount: 64,
    images: [
      '/src/assets/images/tour_mandarmani_resort_1790324605435.jpg',
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Expansive beachfront retreat in Mandarmani featuring an outdoor swimming pool, thatch beach shacks, lush lawn, live seafood barbecue, and direct vehicle beach access.',
    amenities: ['Swimming Pool', 'Private Beach Access', 'Beachside Shacks', 'Barbecue & Bonfire', 'Multi-Cuisine Dining', 'Lawn for Events', 'Free Wi-Fi', '24h Security'],
    startingPrice: 3299,
    rooms: [
      {
        id: 'room_cottage_pool',
        name: 'Luxury Beachfront Poolside Cottage',
        capacity: 2,
        bedType: '1 King Bed',
        pricePerNight: 4499,
        amenities: ['Pool View', 'Private Porch', 'King Size Bed', 'AC', 'Tea/Coffee Maker'],
        image: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=600&auto=format&fit=crop&q=80',
        availableRooms: 5
      },
      {
        id: 'room_deluxe_garden',
        name: 'Deluxe AC Garden Room',
        capacity: 2,
        bedType: '1 Queen Bed',
        pricePerNight: 3299,
        amenities: ['Garden View', 'AC', 'LED TV', 'Modern Bathroom'],
        image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=600&auto=format&fit=crop&q=80',
        availableRooms: 7
      }
    ],
    policies: {
      checkIn: '12:00 PM',
      checkOut: '11:00 AM',
      cancellation: 'Free cancellation up to 72 hours before arrival.'
    },
    contactPhone: '088491 25029',
    featured: true
  },
  {
    id: 'hotel_palm_breeze',
    vendorId: 'vendor_palm_breeze',
    name: 'Palm Breeze Holiday Inn New Digha',
    location: 'New Digha, West Bengal',
    address: 'Near Science City & Amarabati Park, New Digha 721463',
    distanceFromBeach: '300 meters from New Digha Beach (4 min walk)',
    rating: 4.7,
    reviewsCount: 52,
    images: [
      'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Modern family hotel adjacent to Amarabati Park and New Digha market. Features clean AC rooms, elevator, in-house Bengali dining, and guided sightseeing assistance.',
    amenities: ['Elevator', 'In-House Dining', '24h Front Desk', 'AC Rooms', 'Wi-Fi', 'CCTV Security'],
    startingPrice: 1599,
    rooms: [
      {
        id: 'room_pb_deluxe',
        name: 'Deluxe AC Double Room',
        capacity: 2,
        bedType: '1 Queen Bed',
        pricePerNight: 1599,
        amenities: ['AC', 'LED TV', 'Attached Geyser Bath'],
        image: 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=600&auto=format&fit=crop&q=80',
        availableRooms: 9
      },
      {
        id: 'room_pb_quad',
        name: 'Family 4-Bed AC Suite',
        capacity: 4,
        bedType: '2 Double Beds',
        pricePerNight: 2799,
        amenities: ['Spacious for Families', 'AC', 'Intercom', 'Balcony'],
        image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=600&auto=format&fit=crop&q=80',
        availableRooms: 3
      }
    ],
    policies: {
      checkIn: '11:00 AM',
      checkOut: '10:00 AM',
      cancellation: 'Free cancellation up to 48 hours before check-in.'
    },
    contactPhone: '088491 25029',
    featured: false
  }
];

export const TRANSPORTS: TransportService[] = [
  {
    id: 'trans_station_pickup',
    name: 'Digha Railway Station Pickup / Drop (AC Sedan)',
    category: 'SEDAN',
    seatingCapacity: 4,
    luggageCapacity: '2 Large + 2 Small Bags',
    basePrice: 400,
    image: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=600&auto=format&fit=crop&q=80',
    features: ['Chauffeur with Name Board', 'AC Assured', 'Assistance with Luggage', 'On-time Guarantee'],
    serviceType: 'RAILWAY_TRANSFER',
    available: true
  },
  {
    id: 'trans_digha_sightseeing_sedan',
    name: 'Swift Dzire (Full Day Digha & Udaipur Sightseeing)',
    category: 'SEDAN',
    seatingCapacity: 4,
    luggageCapacity: '3 Bags',
    basePrice: 1800,
    pricePerKm: 12,
    image: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=600&auto=format&fit=crop&q=80',
    features: ['Old & New Digha', 'Marine Aquarium', 'Amarabati Park', 'Chandaneswar Shiva Temple', 'Talsari & Udaipur'],
    serviceType: 'LOCAL_SIGHTSEEING',
    available: true
  },
  {
    id: 'trans_mandarmani_transfer',
    name: 'Innova Crysta (Digha to Mandarmani / Shankarpur / Tajpur)',
    category: 'SUV',
    seatingCapacity: 7,
    luggageCapacity: '5 Large Bags',
    basePrice: 2400,
    pricePerKm: 16,
    image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=600&auto=format&fit=crop&q=80',
    features: ['Spacious 7 Seater', 'Plush Captain Seats', 'Dual AC', 'Experienced Coastal Driver'],
    serviceType: 'PICKUP_DROP',
    available: true
  },
  {
    id: 'trans_kolkata_outstation',
    name: 'Kolkata to Digha Outstation Chauffeur (Sedan / SUV)',
    category: 'SUV',
    seatingCapacity: 6,
    luggageCapacity: '4 Large Bags',
    basePrice: 4800,
    pricePerKm: 14,
    image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=600&auto=format&fit=crop&q=80',
    features: ['Doorstep Kolkata Pickup', 'Toll Taxes Included Option', 'Direct Fast Expressway Route (NH16/NH116B)'],
    serviceType: 'OUTSTATION',
    available: true
  },
  {
    id: 'trans_tempo_traveller',
    name: '17-Seater AC Force Tempo Traveller (Group / Corporate)',
    category: 'TEMPO',
    seatingCapacity: 17,
    luggageCapacity: 'Ample Boot Space for 15+ Bags',
    basePrice: 4500,
    pricePerKm: 22,
    image: 'https://images.unsplash.com/photo-1570125909232-eb263c188f7e?w=600&auto=format&fit=crop&q=80',
    features: ['Push-back Reclining Seats', 'Roof AC Vents', 'Music System with Mic for Tour Guide', 'Best for Corporate & Family Groups'],
    serviceType: 'LOCAL_SIGHTSEEING',
    available: true
  },
  {
    id: 'trans_swift_dzire_direct',
    name: 'Swift Dzire (Digha to Mandarmani Cab)',
    category: 'SEDAN',
    seatingCapacity: 4,
    luggageCapacity: '2 Large Bags + Handbags',
    basePrice: 1499,
    pricePerKm: 12,
    image: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=600&auto=format&fit=crop&q=80',
    features: ['Chilled AC', '4 Comfortable Seats', 'Driver Included', 'Doorstep Pickup & Drop', 'Toll Free Route'],
    serviceType: 'PICKUP_DROP',
    available: true
  },
  {
    id: 'trans_ertiga_family',
    name: 'Maruti Ertiga (Family AC Cab - 6 Seater)',
    category: 'SUV',
    seatingCapacity: 6,
    luggageCapacity: '4 Bags',
    basePrice: 2199,
    pricePerKm: 14,
    image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=600&auto=format&fit=crop&q=80',
    features: ['6 Comfortable Passenger Seats', 'AC All Rows', 'Music System', 'Experienced Coastal Driver'],
    serviceType: 'PICKUP_DROP',
    available: true
  }
];

export const WATER_ACTIVITIES: WaterActivity[] = [
  {
    id: 'act_parasailing',
    name: 'Coastal Tandem Parasailing',
    location: 'Mandarmani & Udaipur Beach',
    duration: '20 Minutes',
    price: 1200,
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=600&auto=format&fit=crop&q=80',
    description: 'Fly high above the Bay of Bengal coast with breathtaking bird-eye views of the shoreline, gentle sea breeze, and safety boat tow.',
    safetyBriefing: 'Dual harness with certified instructor and emergency marine vessel.',
    suitableFor: 'Ages 12+ (Weight 35kg to 90kg)'
  },
  {
    id: 'act_jet_ski',
    name: 'High-Speed Ocean Jet Ski Adventure',
    location: 'Mandarmani & Udaipur Beach',
    duration: '15 Minutes',
    price: 650,
    image: 'https://images.unsplash.com/photo-1563298723-dcfebaa392e3?w=600&auto=format&fit=crop&q=80',
    description: 'Ride the rolling waves of Bay of Bengal under the guidance of certified coastal maritime instructors.',
    safetyBriefing: 'Life jacket provided. Strict safety boundary observed.',
    suitableFor: 'Ages 10+ (Single or tandem ride with instructor)'
  },
  {
    id: 'act_banana_ride',
    name: 'Multi-Rider Banana Boat Thrill',
    location: 'Mandarmani Beach',
    duration: '20 Minutes',
    price: 450,
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=600&auto=format&fit=crop&q=80',
    description: 'Fun-filled inflatable banana raft pulled at exhilarating speed by a high-horsepower marine speedboat.',
    safetyBriefing: 'Certified safety vests provided. Rescue boat on standby.',
    suitableFor: 'Families & friend groups (Up to 6 riders at once)'
  },
  {
    id: 'act_speed_boat',
    name: 'Deep Sea Speed Boat Safari',
    location: 'Old Digha & Mandarmani',
    duration: '25 Minutes',
    price: 800,
    image: 'https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=600&auto=format&fit=crop&q=80',
    description: 'Speed across deep sea waters to view the vast coastlines, fishing trawlers, and distant sand islands.',
    safetyBriefing: 'Complete life jackets and maritime coast guard compliance.',
    suitableFor: 'All age groups'
  },
  {
    id: 'act_photography_tour',
    name: 'Coastal Beach Sunset Photography & Drone Shoot',
    location: 'Old Digha & Tajpur Beach',
    duration: '60 Minutes',
    price: 999,
    image: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
    description: 'Professional photographer capturing your vacation moments at golden hour along the scenic sea wall and casuarina pine groves.',
    safetyBriefing: 'High-res edited photos delivered on WhatsApp / Drive within 24 hours.',
    suitableFor: 'Couples, Families, and Solo Travelers'
  },
  {
    id: 'act_beach_atv',
    name: 'Coastal Beach Quad Bike (ATV 4x4)',
    location: 'Mandarmani Hard Beach',
    duration: '15 Minutes',
    price: 500,
    image: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
    description: 'Zoom over the firm wet sands of Mandarmani beach on a 4-wheel all-terrain quad vehicle.',
    safetyBriefing: 'Helmet provided. Instructors supervise speed limit zones.',
    suitableFor: 'Ages 14+'
  }
];

export const BIKE_RENTALS: BikeRental[] = [
  {
    id: 'bike_activa',
    name: 'Honda Activa 6G (Automatic Scooter)',
    type: 'SCOOTER',
    pricePerDay: 499,
    securityDeposit: 1000,
    image: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?w=600&auto=format&fit=crop&q=80',
    fuelType: 'Petrol',
    helmetsIncluded: 2,
    pickupLocation: 'Old Digha Office (Opp. Barrister Colony)',
    terms: ['Valid Driving License required', 'Refundable security deposit', 'Unlimited km in Digha & Mandarmani zone'],
    available: true
  },
  {
    id: 'bike_royal_enfield',
    name: 'Royal Enfield Classic 350',
    type: 'CRUISER',
    pricePerDay: 999,
    securityDeposit: 2500,
    image: 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=600&auto=format&fit=crop&q=80',
    fuelType: 'Petrol',
    helmetsIncluded: 2,
    pickupLocation: 'GoDigha Main Travel Hub, Old Digha',
    terms: ['Valid 2-wheeler Driving License mandatory', 'Original ID deposit', 'Fuel not included'],
    available: true
  },
  {
    id: 'bike_pulsar',
    name: 'Bajaj Pulsar 150cc',
    type: 'SPORTS',
    pricePerDay: 699,
    securityDeposit: 1500,
    image: 'https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?w=600&auto=format&fit=crop&q=80',
    fuelType: 'Petrol',
    helmetsIncluded: 2,
    pickupLocation: 'Old Digha / New Digha Rail Station',
    terms: ['Driving License & Aadhaar copy required', 'Same-day or multi-day rental'],
    available: true
  },
  {
    id: 'bike_jupiter',
    name: 'TVS Jupiter 125cc (Automatic Scooter)',
    type: 'SCOOTER',
    pricePerDay: 449,
    securityDeposit: 1000,
    image: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?w=600&auto=format&fit=crop&q=80',
    fuelType: 'Petrol',
    helmetsIncluded: 2,
    pickupLocation: 'New Digha Sea Beach Road',
    terms: ['Driving license required', 'Great mileage for couples & family cruising'],
    available: true
  },
  {
    id: 'bike_hunter',
    name: 'Royal Enfield Hunter 350 (Metro Cruiser)',
    type: 'CRUISER',
    pricePerDay: 1199,
    securityDeposit: 3000,
    image: 'https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=600&auto=format&fit=crop&q=80',
    fuelType: 'Petrol',
    helmetsIncluded: 2,
    pickupLocation: 'Old Digha Station / Mandarmani Beach Hub',
    terms: ['Valid 2-wheeler license required', 'Helmet provided', 'Dual-channel ABS'],
    available: true
  }
];

export const SIGHTSEEING_TOURS: SightseeingTour[] = [
  {
    id: 'sight_digha_heritage',
    name: 'Complete Digha & Coastal Heritage Circuit',
    destination: 'Digha & Udaipur',
    duration: '5 - 6 Hours',
    price: 1800,
    image: '/src/assets/images/hero_digha_sea_1790324572880.jpg',
    description: 'Explore the best of Digha including Marine Aquarium, Amarabati Lake & Ropeway, Chandaneswar Shiva Temple, and Udaipur Beach sunset.',
    highlights: [
      'Marine Aquarium and Regional Centre (ZSI)',
      'Amarabati Park cable ropeway ride',
      'Historical 100-year-old Chandaneswar Shiva Temple',
      'Udaipur virgin beach right at Bengal-Odisha border'
    ],
    inclusions: ['Dedicated AC vehicle with chauffeur', 'Fuel and parking charges', 'Complimentary mineral water bottles'],
    pickupPoints: ['Any hotel in Old Digha / New Digha']
  },
  {
    id: 'sight_mandarmani_shankar',
    name: 'Mandarmani, Tajpur & Shankarpur Fisherman Shore Tour',
    destination: 'Mandarmani & Tajpur',
    duration: '6 Hours',
    price: 2400,
    image: '/src/assets/images/tour_mandarmani_resort_1790324605435.jpg',
    description: 'Scenic coastal expedition along three distinct coastal beaches: motorable Mandarmani, pine-fringed serene Tajpur, and Shankarpur fishing harbour.',
    highlights: [
      'Drive-on firm sands of Mandarmani',
      'Tajpur secluded casuarina beach',
      'Shankarpur harbour fishing trawler fleet view',
      'Fresh sea-fish fry stalls'
    ],
    inclusions: ['Dedicated AC SUV / Sedan', 'All bridge and entry tolls', 'Chauffeur guide'],
    pickupPoints: ['Digha, Mandarmani, or Tajpur Hotels']
  }
];

export const EVENT_SERVICES: EventService[] = [
  {
    id: 'event_corporate_conf',
    name: 'Corporate Meetings & Conferences',
    category: 'CONFERENCE',
    description: 'End-to-end management of annual conferences, off-site workshops, audio-visual projectors, sound systems, delegate stationery, and corporate catering in Digha & Mandarmani.',
    capacity: '20 to 350 Delegates',
    startingPrice: 15000,
    image: 'https://images.unsplash.com/photo-1511578314322-379afb476865?w=600&auto=format&fit=crop&q=80',
    features: ['High-lumen HD Projectors & Screens', 'Podium & Wireless Microphones', 'Tea/Coffee Break & Buffet Lunch Arrangements', 'Executive Transport Fleet']
  },
  {
    id: 'event_banquet_hall',
    name: 'Banquet & Event Halls Booking',
    category: 'BANQUET',
    description: 'Spacious air-conditioned celebration and event halls in Old Digha & beachfront Mandarmani resorts for weddings, family reunions, seminars, and receptions.',
    capacity: '50 to 500 Guests',
    startingPrice: 20000,
    image: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?w=600&auto=format&fit=crop&q=80',
    features: ['Grand Decorated Stage Setup', 'Climate-Controlled Air Conditioning', 'Dedicated Dining Hall', 'Valet Parking Facilities']
  },
  {
    id: 'event_dj_music',
    name: 'DJ & Sound Entertainment Setup',
    category: 'DJ',
    description: 'Professional live DJ with dynamic truss lighting, smoke machines, powerful subwoofers, and Bollywood/International playlists for beach parties and private celebrations.',
    capacity: 'Open Beach or Indoor Halls',
    startingPrice: 8500,
    image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80',
    features: ['Pro DJ Console & Sound Engineer', 'LED Strobe & Laser Lights', 'Dual Wireless Mics', 'Pre-curated Custom Playlist']
  },
  {
    id: 'event_fooding_catering',
    name: 'Gourmet Fooding & Catering Arrangements',
    category: 'PARTY',
    description: 'Authentic Bengali, Tandoori, North Indian, and Chinese culinary banquets prepared by veteran coastal chefs with live seafood counters (Crab, Prawns, Bhetki, Pomfret).',
    capacity: 'Buffets from 25 to 500 Guests',
    startingPrice: 450, // per plate starting
    image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600&auto=format&fit=crop&q=80',
    features: ['Live Fish Fry & Tandoor Counters', 'Hygienic Spotless Fooding Covers', 'Custom Veg & Non-Veg Menus', 'Professional Hospitality Stewards']
  },
  {
    id: 'event_beverages',
    name: 'Beverages & Mocktail Bars',
    category: 'BEVERAGE',
    description: 'Refreshing tropical mocktails, fresh coastal tender coconut stations, craft sodas, and curated celebration beverages with licensed bar assistance.',
    capacity: 'Customized as per Event',
    startingPrice: 5000,
    image: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=600&auto=format&fit=crop&q=80',
    features: ['Bartenders & Mixologists', 'Custom Beach Tiki Cocktails / Mocktails', 'Fresh Coconut Bar', 'Ice & Glassware Supply']
  }
];

export const REVIEWS: Review[] = [
  {
    id: 'rev_01',
    author: 'Rahul B.',
    rating: 5,
    date: '2 weeks ago',
    comment: 'had a really great experience with Godigha, Everything was smooth, comfortable, and well-organized from start to finish.',
    verifiedSource: 'Google Reviews',
    tripType: 'Digha Family Trip'
  },
  {
    id: 'rev_02',
    author: 'Debojyoti Ghosh',
    rating: 5,
    date: '1 month ago',
    comment: 'Good service from Samir Mandal. Room service are good and Staff Behaviour is too good',
    verifiedSource: 'Google Reviews',
    tripType: 'Hotel & Sightseeing'
  },
  {
    id: 'rev_03',
    author: 'Suman Karmakar',
    rating: 5,
    date: '3 weeks ago',
    comment: 'Good and trusted travel company in digha mandarmani..we satisfied',
    verifiedSource: 'Google Reviews',
    tripType: 'Mandarmani Beach Break'
  },
  {
    id: 'rev_04',
    author: 'Priyanka Mukherjee',
    rating: 5,
    date: '1 month ago',
    comment: 'The accommodation and dining facilities were spotlessly clean.',
    verifiedSource: 'Google Reviews',
    tripType: 'Corporate Weekend Tour'
  },
  {
    id: 'rev_05',
    author: 'Anirban Sen',
    rating: 5,
    date: '2 months ago',
    comment: 'Booked their Darjeeling tour package through WhatsApp. Chauffeur was waiting right at NJP station. Hotel had fantastic Kanchenjunga view. Truly 5 star professional travel agency!',
    verifiedSource: 'Google Reviews',
    tripType: 'Darjeeling Himalayan Tour'
  },
  {
    id: 'rev_06',
    author: 'Subhamita Das',
    rating: 5,
    date: '2 months ago',
    comment: 'Best rental bike service in Old Digha. Received Activa in spotless condition with 2 helmets. Smooth deposit return without any hassle.',
    verifiedSource: 'Google Reviews',
    tripType: 'Bike Rental Experience'
  }
];

export const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'GD-BK-2026-8941',
    customerId: 'user_cust_01',
    customerName: 'Rahul Banerjee',
    customerEmail: 'rahul.b@example.com',
    customerPhone: '+91 98301 24567',
    bookingType: 'PACKAGE',
    itemId: 'pkg_digha_weekend',
    itemTitle: 'Digha Coastal Beach & Casuarina Escape',
    itemSubtitle: '2 Nights / 3 Days · AC Sea View Room Included',
    itemImage: '/src/assets/images/hero_digha_sea_1790324572880.jpg',
    vendorId: 'vendor_sea_star',
    travelDate: '2026-10-15',
    returnDate: '2026-10-17',
    travellers: 2,
    guests: [
      { fullName: 'Rahul Banerjee', age: 32, gender: 'Male', idProofType: 'Aadhaar Card' },
      { fullName: 'Sneha Banerjee', age: 29, gender: 'Female', idProofType: 'Aadhaar Card' }
    ],
    baseAmount: 6998,
    taxAmount: 350,
    discountAmount: 500,
    goCashUsed: 400,
    totalAmount: 6448,
    paymentStatus: 'PAID',
    bookingStatus: 'CONFIRMED',
    paymentId: 'pay_rzp_mock_89410',
    orderId: 'order_godigha_89410',
    specialRequests: 'Upper floor sea-facing room requested. Early check-in if possible.',
    createdAt: '2026-09-20T10:30:00Z'
  },
  {
    id: 'GD-BK-2026-7812',
    customerId: 'user_cust_01',
    customerName: 'Rahul Banerjee',
    customerEmail: 'rahul.b@example.com',
    customerPhone: '+91 98301 24567',
    bookingType: 'HOTEL',
    itemId: 'hotel_sea_star',
    itemTitle: 'Hotel Sea Star Grand Digha',
    itemSubtitle: 'Deluxe AC Sea View Room · 1 Night',
    itemImage: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=600&auto=format&fit=crop&q=80',
    vendorId: 'vendor_sea_star',
    travelDate: '2026-08-12',
    returnDate: '2026-08-13',
    travellers: 2,
    guests: [
      { fullName: 'Rahul Banerjee', age: 32, gender: 'Male' },
      { fullName: 'Sneha Banerjee', age: 29, gender: 'Female' }
    ],
    baseAmount: 2199,
    taxAmount: 110,
    discountAmount: 0,
    goCashUsed: 0,
    totalAmount: 2309,
    paymentStatus: 'PAID',
    bookingStatus: 'COMPLETED',
    paymentId: 'pay_rzp_mock_78120',
    orderId: 'order_godigha_78120',
    createdAt: '2026-08-01T14:15:00Z'
  }
];

export const INITIAL_ENQUIRIES: Enquiry[] = [
  {
    id: 'ENQ-9912',
    customerId: 'user_cust_01',
    name: 'Rahul Banerjee',
    phone: '+91 98301 24567',
    email: 'rahul.b@example.com',
    type: 'CORPORATE',
    destination: 'Mandarmani',
    travelDates: '12 Nov 2026 to 14 Nov 2026',
    travellersCount: 45,
    budgetRange: '₹3,00,000 - ₹4,50,000',
    transportRequired: true,
    hotelRequired: true,
    foodRequired: true,
    activitiesRequired: true,
    message: 'Annual corporate team offsite for 45 members. Require beachfront resort, conference audio setup, team-building beach games, DJ night, and buffet catering with seafood.',
    status: 'CONTACTED',
    adminNotes: 'Spoke with client on phone. Custom proposal sent via WhatsApp. Awaiting internal committee approval.',
    createdAt: '2026-09-22T11:45:00Z'
  },
  {
    id: 'ENQ-9913',
    name: 'Amitava Roy',
    phone: '+91 98310 99882',
    email: 'amitava.roy@techsolutions.in',
    type: 'GROUP',
    destination: 'Darjeeling & Gangtok',
    travelDates: '22 Dec 2026 to 28 Dec 2026',
    travellersCount: 12,
    budgetRange: '₹1,50,000 - ₹2,00,000',
    transportRequired: true,
    hotelRequired: true,
    foodRequired: true,
    activitiesRequired: false,
    message: 'Family group tour for Christmas holidays. Need 6 rooms and 2 Tempo Travellers or Innovas.',
    status: 'NEW',
    createdAt: '2026-09-24T16:20:00Z'
  }
];

export const INITIAL_NOTIFICATIONS: AccountNotification[] = [
  {
    id: 'notif_01',
    userId: 'user_cust_01',
    title: 'Booking Confirmed!',
    message: 'Your Digha Coastal Beach & Casuarina Escape (GD-BK-2026-8941) has been verified and confirmed. Pack your bags!',
    type: 'BOOKING',
    read: false,
    date: '2026-09-20T10:35:00Z',
    linkTab: 'bookings'
  },
  {
    id: 'notif_02',
    userId: 'user_cust_01',
    title: 'Payment Successful (₹6,448)',
    message: 'UPI payment of ₹6,448 was captured successfully via Razorpay. ₹322 GoCash cashback credited to your wallet.',
    type: 'PAYMENT',
    read: false,
    date: '2026-09-20T10:32:00Z',
    linkTab: 'payments'
  },
  {
    id: 'notif_03',
    userId: 'user_cust_01',
    title: 'Corporate Offsite Quote Ready',
    message: 'Our travel desk has prepared a comprehensive quote for your Mandarmani corporate team trip (ENQ-9912).',
    type: 'ENQUIRY',
    read: false,
    date: '2026-09-23T14:10:00Z',
    linkTab: 'enquiries'
  },
  {
    id: 'notif_04',
    userId: 'user_cust_01',
    title: 'Upcoming Trip Reminder',
    message: 'Your Digha holiday starts on 15 Oct 2026. Private cab pickup is scheduled at 08:30 AM.',
    type: 'TRIP',
    read: true,
    date: '2026-09-25T09:00:00Z',
    linkTab: 'trips'
  },
  {
    id: 'notif_05',
    userId: 'user_cust_01',
    title: 'Puja Special Offer: 15% Off',
    message: 'Book Mandarmani luxury sea facing resorts for Durga Puja and get up to 15% instant discount with code GODIGHA2026.',
    type: 'OFFER',
    read: true,
    date: '2026-09-26T18:00:00Z',
    linkTab: 'saved'
  }
];

export const INITIAL_PAYMENTS: PaymentTransaction[] = [
  {
    id: 'tx_01',
    paymentId: 'pay_rzp_mock_89410',
    orderId: 'order_godigha_89410',
    bookingId: 'GD-BK-2026-8941',
    userId: 'user_cust_01',
    amount: 6448,
    currency: 'INR',
    method: 'UPI',
    status: 'PAID',
    date: '2026-09-20T10:31:00Z',
    itemTitle: 'Digha Coastal Beach & Casuarina Escape',
    refundStatus: 'NONE'
  },
  {
    id: 'tx_02',
    paymentId: 'pay_rzp_mock_78120',
    orderId: 'order_godigha_78120',
    bookingId: 'GD-BK-2026-7812',
    userId: 'user_cust_01',
    amount: 2309,
    currency: 'INR',
    method: 'CARD',
    status: 'PAID',
    date: '2026-08-01T14:16:00Z',
    itemTitle: 'Hotel Sea Star Grand Digha',
    refundStatus: 'NONE'
  }
];
