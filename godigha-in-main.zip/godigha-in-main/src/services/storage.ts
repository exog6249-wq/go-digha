import {
  User,
  TravelPackage,
  Hotel,
  TransportService,
  WaterActivity,
  BikeRental,
  EventService,
  Destination,
  SightseeingTour,
  Booking,
  Enquiry,
  Review,
  AccountNotification,
  PaymentTransaction,
  RecentSearchItem
} from '../types';
import {
  INITIAL_USERS,
  TRAVEL_PACKAGES,
  HOTELS,
  TRANSPORTS,
  SIGHTSEEING_TOURS,
  WATER_ACTIVITIES,
  BIKE_RENTALS,
  EVENT_SERVICES,
  DESTINATIONS,
  INITIAL_BOOKINGS,
  INITIAL_ENQUIRIES,
  REVIEWS,
  INITIAL_NOTIFICATIONS,
  INITIAL_PAYMENTS
} from '../data/mockData';

const STORAGE_KEYS = {
  USERS: 'godigha_users',
  CURRENT_USER: 'godigha_current_user',
  PACKAGES: 'godigha_packages',
  HOTELS: 'godigha_hotels',
  TRANSPORTS: 'godigha_transports',
  ACTIVITIES: 'godigha_activities',
  BIKES: 'godigha_bikes',
  EVENTS: 'godigha_events',
  DESTINATIONS: 'godigha_destinations',
  BOOKINGS: 'godigha_bookings',
  ENQUIRIES: 'godigha_enquiries',
  REVIEWS: 'godigha_reviews',
  SAVED_PACKAGES: 'godigha_saved_packages',
  NOTIFICATIONS: 'godigha_notifications',
  PAYMENTS: 'godigha_payments'
};

function getFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) return defaultValue;
    return JSON.parse(item);
  } catch (e) {
    console.error(`Error reading ${key} from storage:`, e);
    return defaultValue;
  }
}

function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new Event('godigha_storage_updated'));
  } catch (e) {
    console.error(`Error writing ${key} to storage:`, e);
  }
}

export const StorageService = {
  // Current user / Auth
  getCurrentUser(): User | null {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (!raw) {
      const loggedOut = localStorage.getItem('godigha_logged_out');
      if (loggedOut === 'true') {
        return null;
      }
      return INITIAL_USERS[0]; // Rahul Banerjee as initial demo session
    }
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  },

  setCurrentUser(user: User | null): void {
    if (user) {
      localStorage.removeItem('godigha_logged_out');
      saveToStorage(STORAGE_KEYS.CURRENT_USER, user);
    } else {
      localStorage.setItem('godigha_logged_out', 'true');
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
      window.dispatchEvent(new Event('godigha_storage_updated'));
    }
  },

  logout(): void {
    this.setCurrentUser(null);
  },

  getUsers(): User[] {
    return getFromStorage<User[]>(STORAGE_KEYS.USERS, INITIAL_USERS);
  },

  updateUser(user: User): void {
    const users = this.getUsers().map(u => u.id === user.id ? user : u);
    saveToStorage(STORAGE_KEYS.USERS, users);
    const curr = this.getCurrentUser();
    if (curr && curr.id === user.id) {
      this.setCurrentUser(user);
    }
  },

  loginUser(identifier: string, _password?: string): { success: boolean; user?: User; error?: string } {
    const cleanId = identifier.trim().toLowerCase();
    const users = this.getUsers();
    
    // Find by email or phone
    const found = users.find(u => 
      u.email.toLowerCase() === cleanId || 
      u.phone.replace(/[\s+-]/g, '') === cleanId.replace(/[\s+-]/g, '')
    );

    if (found) {
      this.setCurrentUser(found);
      return { success: true, user: found };
    }

    // Auto-create new customer if not found
    const isEmail = identifier.includes('@');
    const newUser: User = {
      id: `user_cust_${Date.now()}`,
      name: isEmail ? identifier.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) : 'GoDigha Traveller',
      email: isEmail ? cleanId : `${cleanId}@godigha-traveller.in`,
      phone: isEmail ? '+91 98830 12026' : identifier,
      role: 'CUSTOMER',
      goCashBalance: 500, // Welcome signup bonus
      createdAt: new Date().toISOString()
    };

    const updatedUsers = [newUser, ...users];
    saveToStorage(STORAGE_KEYS.USERS, updatedUsers);
    this.setCurrentUser(newUser);

    // Add welcome notification
    this.addNotification({
      userId: newUser.id,
      title: 'Welcome to GoDigha!',
      message: '₹500 GoCash signup bonus credited to your travel wallet. Use it towards your first hotel or package booking.',
      type: 'OFFER',
      read: false,
      linkTab: 'dashboard'
    });

    return { success: true, user: newUser };
  },

  registerUser(data: { firstName: string; lastName: string; email: string; phone: string; password?: string }): { success: boolean; user?: User; error?: string } {
    const cleanEmail = data.email.trim().toLowerCase();
    const users = this.getUsers();

    if (users.some(u => u.email.toLowerCase() === cleanEmail)) {
      return { success: false, error: 'An account with this email address already exists. Please log in.' };
    }

    const fullName = `${data.firstName.trim()} ${data.lastName.trim()}`.trim();
    const newUser: User = {
      id: `user_cust_${Date.now()}`,
      name: fullName || 'GoDigha Traveller',
      firstName: data.firstName.trim(),
      lastName: data.lastName.trim(),
      email: cleanEmail,
      phone: data.phone.trim(),
      role: 'CUSTOMER',
      goCashBalance: 500,
      createdAt: new Date().toISOString()
    };

    const updatedUsers = [newUser, ...users];
    saveToStorage(STORAGE_KEYS.USERS, updatedUsers);
    this.setCurrentUser(newUser);

    this.addNotification({
      userId: newUser.id,
      title: 'Welcome to GoDigha Family!',
      message: `Hello ${data.firstName}! Your GoDigha account is ready. ₹500 GoCash has been credited to your wallet.`,
      type: 'OFFER',
      read: false,
      linkTab: 'dashboard'
    });

    return { success: true, user: newUser };
  },

  updateUserProfile(userId: string, data: Partial<User>): User | null {
    const users = this.getUsers().map(u => {
      if (u.id === userId) {
        const updated = { ...u, ...data };
        if (data.firstName !== undefined || data.lastName !== undefined) {
          const fn = data.firstName !== undefined ? data.firstName : (u.firstName || '');
          const ln = data.lastName !== undefined ? data.lastName : (u.lastName || '');
          updated.name = `${fn} ${ln}`.trim() || updated.name;
        }
        return updated;
      }
      return u;
    });
    saveToStorage(STORAGE_KEYS.USERS, users);
    const curr = this.getCurrentUser();
    if (curr && curr.id === userId) {
      const updatedUser = users.find(u => u.id === userId) || null;
      if (updatedUser) this.setCurrentUser(updatedUser);
      return updatedUser;
    }
    return users.find(u => u.id === userId) || null;
  },

  // Packages
  getPackages(): TravelPackage[] {
    return getFromStorage<TravelPackage[]>(STORAGE_KEYS.PACKAGES, TRAVEL_PACKAGES);
  },

  getPackageById(id: string): TravelPackage | undefined {
    return this.getPackages().find(p => p.id === id);
  },

  savePackage(pkg: TravelPackage): void {
    const pkgs = this.getPackages();
    const index = pkgs.findIndex(p => p.id === pkg.id);
    if (index >= 0) {
      pkgs[index] = pkg;
    } else {
      pkgs.unshift(pkg);
    }
    saveToStorage(STORAGE_KEYS.PACKAGES, pkgs);
  },

  deletePackage(id: string): void {
    const pkgs = this.getPackages().filter(p => p.id !== id);
    saveToStorage(STORAGE_KEYS.PACKAGES, pkgs);
  },

  // Hotels
  getHotels(): Hotel[] {
    return getFromStorage<Hotel[]>(STORAGE_KEYS.HOTELS, HOTELS);
  },

  getHotelById(id: string): Hotel | undefined {
    return this.getHotels().find(h => h.id === id);
  },

  saveHotel(hotel: Hotel): void {
    const hotels = this.getHotels();
    const index = hotels.findIndex(h => h.id === hotel.id);
    if (index >= 0) {
      hotels[index] = hotel;
    } else {
      hotels.unshift(hotel);
    }
    saveToStorage(STORAGE_KEYS.HOTELS, hotels);
  },

  deleteHotel(id: string): void {
    const hotels = this.getHotels().filter(h => h.id !== id);
    saveToStorage(STORAGE_KEYS.HOTELS, hotels);
  },

  // Destinations
  getDestinations(): Destination[] {
    return getFromStorage<Destination[]>(STORAGE_KEYS.DESTINATIONS, DESTINATIONS);
  },

  saveDestination(dest: Destination): void {
    const dests = this.getDestinations();
    const index = dests.findIndex(d => d.id === dest.id);
    if (index >= 0) {
      dests[index] = dest;
    } else {
      dests.push(dest);
    }
    saveToStorage(STORAGE_KEYS.DESTINATIONS, dests);
  },

  // Transports
  getTransports(): TransportService[] {
    return getFromStorage<TransportService[]>(STORAGE_KEYS.TRANSPORTS, TRANSPORTS);
  },

  saveTransport(trans: TransportService): void {
    const list = this.getTransports();
    const index = list.findIndex(t => t.id === trans.id);
    if (index >= 0) list[index] = trans;
    else list.push(trans);
    saveToStorage(STORAGE_KEYS.TRANSPORTS, list);
  },

  // Sightseeing tours
  getSightseeing(): SightseeingTour[] {
    return getFromStorage<SightseeingTour[]>('godigha_sightseeing', SIGHTSEEING_TOURS);
  },

  // Water activities
  getActivities(): WaterActivity[] {
    return getFromStorage<WaterActivity[]>(STORAGE_KEYS.ACTIVITIES, WATER_ACTIVITIES);
  },

  // Bike rentals
  getBikes(): BikeRental[] {
    return getFromStorage<BikeRental[]>(STORAGE_KEYS.BIKES, BIKE_RENTALS);
  },

  // Event services
  getEvents(): EventService[] {
    return getFromStorage<EventService[]>(STORAGE_KEYS.EVENTS, EVENT_SERVICES);
  },

  // Bookings
  getBookings(): Booking[] {
    return getFromStorage<Booking[]>(STORAGE_KEYS.BOOKINGS, INITIAL_BOOKINGS);
  },

  saveBooking(booking: Booking): void {
    const bookings = this.getBookings();
    const index = bookings.findIndex(b => b.id === booking.id);
    if (index >= 0) {
      bookings[index] = booking;
    } else {
      bookings.unshift(booking);
    }
    saveToStorage(STORAGE_KEYS.BOOKINGS, bookings);

    // If booking was paid and GoCash was used, update user balance; reward 5% cashback in GoCash
    if (booking.paymentStatus === 'PAID') {
      const user = this.getCurrentUser();
      if (user && user.id === booking.customerId) {
        const cashbackEarned = Math.round(booking.totalAmount * 0.05);
        const newBalance = Math.max(0, user.goCashBalance - booking.goCashUsed) + cashbackEarned;
        this.updateUser({ ...user, goCashBalance: newBalance });
      }
    }
  },

  updateBookingStatus(id: string, status: Booking['bookingStatus']): void {
    const bookings = this.getBookings().map(b => b.id === id ? { ...b, bookingStatus: status } : b);
    saveToStorage(STORAGE_KEYS.BOOKINGS, bookings);
  },

  // Enquiries
  getEnquiries(): Enquiry[] {
    return getFromStorage<Enquiry[]>(STORAGE_KEYS.ENQUIRIES, INITIAL_ENQUIRIES);
  },

  saveEnquiry(enquiry: Enquiry): void {
    const enquiries = this.getEnquiries();
    const index = enquiries.findIndex(e => e.id === enquiry.id);
    if (index >= 0) {
      enquiries[index] = enquiry;
    } else {
      enquiries.unshift(enquiry);
    }
    saveToStorage(STORAGE_KEYS.ENQUIRIES, enquiries);
  },

  updateEnquiryStatus(id: string, status: Enquiry['status'], notes?: string): void {
    const enquiries = this.getEnquiries().map(e => e.id === id ? { ...e, status, adminNotes: notes ?? e.adminNotes } : e);
    saveToStorage(STORAGE_KEYS.ENQUIRIES, enquiries);
  },

  // Reviews
  getReviews(): Review[] {
    return getFromStorage<Review[]>(STORAGE_KEYS.REVIEWS, REVIEWS);
  },

  // Saved / Wishlist Packages
  getSavedPackageIds(): string[] {
    return getFromStorage<string[]>(STORAGE_KEYS.SAVED_PACKAGES, ['pkg_digha_weekend', 'pkg_darjeeling_01']);
  },

  toggleSavedPackage(packageId: string): boolean {
    const ids = this.getSavedPackageIds();
    const exists = ids.includes(packageId);
    const updated = exists ? ids.filter(id => id !== packageId) : [...ids, packageId];
    saveToStorage(STORAGE_KEYS.SAVED_PACKAGES, updated);
    return !exists;
  },

  // Notifications
  getNotifications(userId?: string): AccountNotification[] {
    const all = getFromStorage<AccountNotification[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    if (!userId) return all;
    return all.filter(n => n.userId === userId);
  },

  markNotificationAsRead(id: string): void {
    const list = this.getNotifications().map(n => n.id === id ? { ...n, read: true } : n);
    saveToStorage(STORAGE_KEYS.NOTIFICATIONS, list);
  },

  markAllNotificationsAsRead(userId: string): void {
    const list = this.getNotifications().map(n => n.userId === userId ? { ...n, read: true } : n);
    saveToStorage(STORAGE_KEYS.NOTIFICATIONS, list);
  },

  addNotification(notif: Omit<AccountNotification, 'id' | 'date'>): AccountNotification {
    const newNotif: AccountNotification = {
      ...notif,
      id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      date: new Date().toISOString()
    };
    const list = [newNotif, ...this.getNotifications()];
    saveToStorage(STORAGE_KEYS.NOTIFICATIONS, list);
    return newNotif;
  },

  // Payments & Transactions
  getPaymentTransactions(userId?: string): PaymentTransaction[] {
    const all = getFromStorage<PaymentTransaction[]>(STORAGE_KEYS.PAYMENTS, INITIAL_PAYMENTS);
    if (!userId) return all;
    return all.filter(t => t.userId === userId);
  },

  savePaymentTransaction(tx: PaymentTransaction): void {
    const list = this.getPaymentTransactions();
    const index = list.findIndex(t => t.id === tx.id || t.paymentId === tx.paymentId);
    if (index >= 0) {
      list[index] = tx;
    } else {
      list.unshift(tx);
    }
    saveToStorage(STORAGE_KEYS.PAYMENTS, list);
  },

  requestRefund(bookingId: string, _reason?: string): { success: boolean; message: string } {
    // 1. Update Booking
    const bookings = this.getBookings().map(b => {
      if (b.id === bookingId) {
        return {
          ...b,
          bookingStatus: 'CANCELLED' as const,
          paymentStatus: 'REFUNDED' as const
        };
      }
      return b;
    });
    saveToStorage(STORAGE_KEYS.BOOKINGS, bookings);

    // 2. Update Payment record
    const targetBooking = bookings.find(b => b.id === bookingId);
    const txs = this.getPaymentTransactions().map(t => {
      if (t.bookingId === bookingId) {
        return {
          ...t,
          status: 'REFUNDED' as const,
          refundStatus: 'REQUESTED' as const
        };
      }
      return t;
    });
    saveToStorage(STORAGE_KEYS.PAYMENTS, txs);

    // 3. Add system notification
    if (targetBooking) {
      this.addNotification({
        userId: targetBooking.customerId,
        title: 'Refund Request Received',
        message: `Your cancellation and refund request of ₹${targetBooking.totalAmount} for ${targetBooking.itemTitle} (${bookingId}) has been registered. Our accounts desk will process the refund to the original payment source.`,
        type: 'REFUND',
        read: false,
        linkTab: 'payments'
      });
    }

    return { success: true, message: 'Refund initiated. Tracking status updated in Payments tab.' };
  },

  // Recent Searches Management (Sections 12, 13, 14)
  getRecentSearches(userId?: string): RecentSearchItem[] {
    const key = userId ? `godigha_recent_searches_${userId}` : 'godigha_recent_searches_guest';
    const raw = localStorage.getItem(key);
    if (!raw) {
      // Default initial recent searches if nothing yet
      return [
        {
          id: 'rs_default_1',
          query: 'Digha Hotels',
          category: 'hotel',
          destination: 'Old Digha',
          params: { destination: 'Old Digha, West Bengal', checkIn: '2026-10-15', checkOut: '2026-10-18', guests: '2 Guests' },
          timestamp: Date.now() - 1000 * 60 * 30,
          label: 'Digha Hotels',
          subtitle: 'Hotels • Old Digha'
        },
        {
          id: 'rs_default_2',
          query: 'Mandarmani Beach Resort',
          category: 'hotel',
          destination: 'Mandarmani',
          params: { destination: 'Mandarmani Beach Resort', checkIn: '2026-10-15', checkOut: '2026-10-18', guests: '2 Guests' },
          timestamp: Date.now() - 1000 * 60 * 60,
          label: 'Mandarmani Beach Resort',
          subtitle: 'Hotels • Mandarmani'
        },
        {
          id: 'rs_default_3',
          query: 'Digha Sightseeing',
          category: 'tour',
          destination: 'Digha',
          params: { destination: 'Digha', travelDate: '2026-10-15', duration: 'All Durations', travellers: '2 Travellers' },
          timestamp: Date.now() - 1000 * 60 * 120,
          label: 'Digha Sightseeing',
          subtitle: 'Tours • Digha'
        },
        {
          id: 'rs_default_4',
          query: 'Bike Rental Digha',
          category: 'bike',
          destination: 'Digha',
          params: { pickupLocation: 'Old Digha Station', pickupDate: '2026-10-15', returnDate: '2026-10-17', bikeType: 'Scooter' },
          timestamp: Date.now() - 1000 * 60 * 240,
          label: 'Bike Rental Digha',
          subtitle: 'Bikes • Digha'
        }
      ];
    }
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  addRecentSearch(
    item: {
      query: string;
      category: 'hotel' | 'cab' | 'tour' | 'activity' | 'bike';
      destination?: string;
      params?: Record<string, any>;
      label?: string;
      subtitle?: string;
    },
    userId?: string
  ): RecentSearchItem {
    const current = this.getRecentSearches(userId);
    const key = userId ? `godigha_recent_searches_${userId}` : 'godigha_recent_searches_guest';
    const label = item.label || item.query || `${item.category.toUpperCase()} in ${item.destination || 'Digha'}`;
    const cleanDestination = item.destination || (item.params?.destination) || 'Digha';

    const newItem: RecentSearchItem = {
      id: `rs_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      query: item.query || label,
      category: item.category,
      destination: cleanDestination,
      params: item.params || {},
      timestamp: Date.now(),
      label,
      subtitle: item.subtitle || `${item.category.charAt(0).toUpperCase() + item.category.slice(1)} • ${cleanDestination}`
    };

    // Filter out duplicates (match by label or exact query + category)
    const filtered = current.filter(
      existing =>
        existing.label.toLowerCase() !== newItem.label.toLowerCase() &&
        !(existing.query.toLowerCase() === newItem.query.toLowerCase() && existing.category === newItem.category)
    );

    // Newest first, maximum 6 entries
    const updated = [newItem, ...filtered].slice(0, 6);
    try {
      localStorage.setItem(key, JSON.stringify(updated));
      window.dispatchEvent(new Event('godigha_storage_updated'));
    } catch (e) {
      console.error('Error saving recent search:', e);
    }
    return newItem;
  },

  removeRecentSearch(id: string, userId?: string): void {
    const current = this.getRecentSearches(userId);
    const key = userId ? `godigha_recent_searches_${userId}` : 'godigha_recent_searches_guest';
    const updated = current.filter(item => item.id !== id);
    try {
      localStorage.setItem(key, JSON.stringify(updated));
      window.dispatchEvent(new Event('godigha_storage_updated'));
    } catch (e) {
      console.error('Error removing recent search:', e);
    }
  },

  clearRecentSearches(userId?: string): void {
    const key = userId ? `godigha_recent_searches_${userId}` : 'godigha_recent_searches_guest';
    try {
      localStorage.setItem(key, JSON.stringify([]));
      window.dispatchEvent(new Event('godigha_storage_updated'));
    } catch (e) {
      console.error('Error clearing recent searches:', e);
    }
  },

  mergeGuestRecentSearches(userId: string): void {
    if (!userId) return;
    const guestSearches = this.getRecentSearches();
    const userKey = `godigha_recent_searches_${userId}`;
    const userRaw = localStorage.getItem(userKey);
    let userSearches: RecentSearchItem[] = [];
    if (userRaw) {
      try {
        userSearches = JSON.parse(userRaw);
      } catch {
        userSearches = [];
      }
    }

    // Merge without duplicates
    const combined = [...guestSearches, ...userSearches];
    const deduped: RecentSearchItem[] = [];
    for (const item of combined) {
      const exists = deduped.some(
        d =>
          d.label.toLowerCase() === item.label.toLowerCase() ||
          (d.query.toLowerCase() === item.query.toLowerCase() && d.category === item.category)
      );
      if (!exists) {
        deduped.push(item);
      }
    }
    deduped.sort((a, b) => b.timestamp - a.timestamp);
    const result = deduped.slice(0, 6);
    try {
      localStorage.setItem(userKey, JSON.stringify(result));
      window.dispatchEvent(new Event('godigha_storage_updated'));
    } catch (e) {
      console.error('Error merging recent searches:', e);
    }
  }
};
