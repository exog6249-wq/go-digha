import {
  Hotel,
  TransportService,
  TravelPackage,
  WaterActivity,
  BikeRental,
  SightseeingTour,
  ServiceCategory,
  HotelSearchParams,
  CabSearchParams,
  TourSearchParams,
  ActivitySearchParams,
  BikeSearchParams,
  RecentSearchItem
} from '../types';

export interface SearchSuggestionItem {
  id: string;
  type: 'recent' | 'suggestion' | 'category' | 'destination' | 'popular';
  title: string;
  subtitle?: string;
  category: ServiceCategory;
  destination?: string;
  query: string;
}

export const POPULAR_SEARCH_TERMS = [
  'Digha Hotels',
  'Mandarmani Hotels',
  'Sea Facing',
  'Budget Hotels',
  'Family',
  'Couple Friendly',
  'Resort',
  'Near Beach'
];

export const TOP_DESTINATIONS = [
  { name: 'Old Digha', label: 'Old Digha Sea Beach', state: 'West Bengal' },
  { name: 'New Digha', label: 'New Digha Marine Drive', state: 'West Bengal' },
  { name: 'Mandarmani', label: 'Mandarmani Beach Resort Hub', state: 'West Bengal' },
  { name: 'Tajpur', label: 'Tajpur Red Crab Beach', state: 'West Bengal' },
  { name: 'Shankarpur', label: 'Shankarpur Fishing Harbor', state: 'West Bengal' },
  { name: 'Bakkhali', label: 'Bakkhali Coastal Strip', state: 'West Bengal' },
  { name: 'Darjeeling', label: 'Darjeeling Hill Station', state: 'West Bengal' },
  { name: 'Sundarban', label: 'Sundarban Mangrove Delta', state: 'West Bengal' }
];

export const CATEGORY_DETAILS: Record<
  ServiceCategory,
  { label: string; icon: string; tag: string; description: string }
> = {
  hotel: { label: 'Hotels & Resorts', icon: 'Hotel', tag: 'Stay', description: 'Sea-facing rooms, budget & luxury beach resorts' },
  cab: { label: 'Cabs & Car Rentals', icon: 'Car', tag: 'Transport', description: 'AC Sedans, SUVs, Tempo Travellers & station pickups' },
  tour: { label: 'Tour Packages', icon: 'Compass', tag: 'Packages', description: 'Weekend escapes, combo tours & family holidays' },
  activity: { label: 'Water Sports & Activities', icon: 'Waves', tag: 'Experiences', description: 'Jet ski, banana ride, parasailing & boating' },
  bike: { label: 'Bike & Scooter Rentals', icon: 'Bike', tag: 'Rentals', description: 'Activa scooters, Royal Enfield & sports bikes' }
};

/**
 * Detects if a search query specifies a certain category (Section 9)
 */
export function detectCategoryFromQuery(query: string): ServiceCategory | null {
  const q = query.toLowerCase().trim();
  if (q.includes('hotel') || q.includes('resort') || q.includes('stay') || q.includes('room') || q.includes('lodge') || q.includes('guest house')) {
    return 'hotel';
  }
  if (q.includes('cab') || q.includes('taxi') || q.includes('car') || q.includes('pickup') || q.includes('drop') || q.includes('transfer') || q.includes('dzire') || q.includes('innova')) {
    return 'cab';
  }
  if (q.includes('tour') || q.includes('package') || q.includes('holiday') || q.includes('trip') || q.includes('escape') || q.includes('combo') || q.includes('nights') || q.includes('days')) {
    return 'tour';
  }
  if (q.includes('activity') || q.includes('water sport') || q.includes('jet ski') || q.includes('banana') || q.includes('parasail') || q.includes('boat') || q.includes('atv') || q.includes('photo')) {
    return 'activity';
  }
  if (q.includes('bike') || q.includes('scooter') || q.includes('activa') || q.includes('bullet') || q.includes('enfield') || q.includes('pulsar') || q.includes('rent')) {
    return 'bike';
  }
  return null;
}

/**
 * Generates live suggestions as user types or when focused (Sections 10 & 11)
 */
export function getLiveSuggestions(
  input: string,
  recentSearches: RecentSearchItem[]
): SearchSuggestionItem[] {
  const q = input.toLowerCase().trim();

  // If input is empty: show recent searches and popular suggestions
  if (!q) {
    const list: SearchSuggestionItem[] = [];

    // 1. Recent searches
    recentSearches.forEach(rs => {
      list.push({
        id: `recent_${rs.id}`,
        type: 'recent',
        title: rs.label || rs.query,
        subtitle: rs.subtitle || `${rs.category.toUpperCase()} • ${rs.destination || 'Digha'}`,
        category: rs.category,
        destination: rs.destination,
        query: rs.query
      });
    });

    // 2. Popular categories
    (Object.keys(CATEGORY_DETAILS) as ServiceCategory[]).forEach(cat => {
      list.push({
        id: `cat_${cat}`,
        type: 'category',
        title: CATEGORY_DETAILS[cat].label,
        subtitle: CATEGORY_DETAILS[cat].description,
        category: cat,
        query: CATEGORY_DETAILS[cat].label
      });
    });

    return list;
  }

  // Dynamic matching when typing
  const suggestions: SearchSuggestionItem[] = [];

  // 1. Matches from recent searches
  recentSearches.forEach(rs => {
    if (rs.label.toLowerCase().includes(q) || rs.query.toLowerCase().includes(q)) {
      suggestions.push({
        id: `match_recent_${rs.id}`,
        type: 'recent',
        title: rs.label || rs.query,
        subtitle: `Recent • ${rs.category.toUpperCase()}`,
        category: rs.category,
        destination: rs.destination,
        query: rs.query
      });
    }
  });

  // 2. Specific pattern dynamic templates as requested in Section 11:
  // "Digha" -> Digha Hotels, Digha Holiday Packages, Digha Sightseeing, Digha Cabs, Bike Rental in Digha, Digha Water Activities
  const lowerDest = q.includes('mandarmani') ? 'Mandarmani' : 'Digha';

  const contextualSuggestions: { title: string; category: ServiceCategory }[] = [
    { title: `${lowerDest} Hotels & Resorts`, category: 'hotel' },
    { title: `${lowerDest} Holiday Packages`, category: 'tour' },
    { title: `${lowerDest} Sightseeing Tours`, category: 'tour' },
    { title: `${lowerDest} Cabs & Car Rental`, category: 'cab' },
    { title: `Bike Rental in ${lowerDest}`, category: 'bike' },
    { title: `${lowerDest} Water Sports & Activities`, category: 'activity' }
  ];

  contextualSuggestions.forEach((cs, i) => {
    if (cs.title.toLowerCase().includes(q) || q.includes(lowerDest.toLowerCase())) {
      suggestions.push({
        id: `ctx_${lowerDest}_${i}`,
        type: 'suggestion',
        title: cs.title,
        subtitle: `${CATEGORY_DETAILS[cs.category].tag} in ${lowerDest}`,
        category: cs.category,
        destination: lowerDest,
        query: cs.title
      });
    }
  });

  // 3. Match destinations
  TOP_DESTINATIONS.forEach(dest => {
    if (dest.name.toLowerCase().includes(q) || dest.label.toLowerCase().includes(q)) {
      suggestions.push({
        id: `dest_${dest.name}`,
        type: 'destination',
        title: dest.label,
        subtitle: `Top Destination • ${dest.state}`,
        category: 'hotel',
        destination: dest.name,
        query: `${dest.name} Hotels`
      });
    }
  });

  // Deduplicate by title
  const seen = new Set<string>();
  return suggestions.filter(item => {
    const key = item.title.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 8);
}

/**
 * HOTEL SEARCH & FILTER (Sections 2 & 15)
 */
export function searchHotels(
  hotels: Hotel[],
  params?: Partial<HotelSearchParams>,
  globalQuery?: string
): Hotel[] {
  let results = [...hotels];

  // Global Query filter
  if (globalQuery && globalQuery.trim()) {
    const q = globalQuery.toLowerCase().trim();
    results = results.filter(h => {
      const matchName = h.name.toLowerCase().includes(q);
      const matchLoc = h.location.toLowerCase().includes(q) || h.address.toLowerCase().includes(q);
      const matchDesc = h.description.toLowerCase().includes(q);
      const matchAmenity = h.amenities.some(a => a.toLowerCase().includes(q));
      const matchRoom = h.rooms.some(r => r.name.toLowerCase().includes(q) || r.amenities.some(ra => ra.toLowerCase().includes(q)));
      
      // Keywords mapping
      if (q.includes('budget') && h.startingPrice < 2000) return true;
      if (q.includes('luxury') && (h.startingPrice >= 3000 || h.name.toLowerCase().includes('luxury') || h.name.toLowerCase().includes('resort'))) return true;
      if (q.includes('resort') && (h.name.toLowerCase().includes('resort') || h.amenities.includes('Swimming Pool'))) return true;
      if (q.includes('sea facing') || q.includes('sea view') || q.includes('beachfront') || q.includes('near beach')) {
        if (h.distanceFromBeach.toLowerCase().includes('sea') || h.distanceFromBeach.toLowerCase().includes('150') || h.distanceFromBeach.toLowerCase().includes('zero') || h.amenities.some(a => a.toLowerCase().includes('sea'))) return true;
      }
      if (q.includes('family') && (h.rooms.some(r => r.capacity >= 4) || h.description.toLowerCase().includes('family'))) return true;
      if (q.includes('couple') && (h.rooms.some(r => r.bedType.toLowerCase().includes('king') || r.bedType.toLowerCase().includes('queen')))) return true;

      return matchName || matchLoc || matchDesc || matchAmenity || matchRoom;
    });
  }

  // Destination filter
  if (params?.destination && params.destination.trim() && params.destination !== 'All' && !params.destination.toLowerCase().includes('all')) {
    const destTerm = params.destination.split(',')[0].toLowerCase().trim();
    results = results.filter(h => 
      h.location.toLowerCase().includes(destTerm) ||
      h.address.toLowerCase().includes(destTerm) ||
      destTerm.includes('digha') && h.location.toLowerCase().includes('digha') ||
      destTerm.includes('mandarmani') && h.location.toLowerCase().includes('mandarmani')
    );
  }

  // Guests filter
  if (params?.guests) {
    const minGuests = parseInt(params.guests) || 1;
    if (minGuests > 2) {
      results = results.filter(h => h.rooms.some(r => r.capacity >= minGuests || r.availableRooms >= Math.ceil(minGuests / 2)));
    }
  }

  // Property Type filter
  if (params?.propertyType && params.propertyType !== 'ALL') {
    const pt = params.propertyType.toLowerCase();
    results = results.filter(h => {
      if (pt === 'resort') return h.name.toLowerCase().includes('resort') || h.amenities.includes('Swimming Pool');
      if (pt === 'beach' || pt === 'sea facing') return h.distanceFromBeach.toLowerCase().includes('sea') || h.distanceFromBeach.toLowerCase().includes('150') || h.distanceFromBeach.toLowerCase().includes('zero');
      if (pt === 'budget') return h.startingPrice <= 2000;
      if (pt === 'luxury') return h.startingPrice >= 3000;
      if (pt === 'family') return h.rooms.some(r => r.capacity >= 4);
      return true;
    });
  }

  // Rating filter
  if (params?.minRating && params.minRating > 0) {
    results = results.filter(h => h.rating >= params.minRating!);
  }

  // Amenities filter
  if (params?.amenities && params.amenities.length > 0) {
    results = results.filter(h => 
      params.amenities!.every(req => 
        h.amenities.some(a => a.toLowerCase().includes(req.toLowerCase()))
      )
    );
  }

  return results;
}

/**
 * CAB / TRANSPORT SEARCH & FILTER (Sections 3 & 15)
 */
export function searchCabs(
  cabs: TransportService[],
  params?: Partial<CabSearchParams>,
  globalQuery?: string
): TransportService[] {
  let results = [...cabs];

  if (globalQuery && globalQuery.trim()) {
    const q = globalQuery.toLowerCase().trim();
    results = results.filter(c => {
      const matchName = c.name.toLowerCase().includes(q);
      const matchCat = c.category.toLowerCase().includes(q);
      const matchFeat = c.features.some(f => f.toLowerCase().includes(q));
      if (q.includes('sedan') && c.category === 'SEDAN') return true;
      if (q.includes('suv') && c.category === 'SUV') return true;
      if (q.includes('tempo') && c.category === 'TEMPO') return true;
      if (q.includes('dzire') && c.name.toLowerCase().includes('dzire')) return true;
      if (q.includes('innova') && c.name.toLowerCase().includes('innova')) return true;
      if (q.includes('mandarmani') && (c.name.toLowerCase().includes('mandarmani') || c.serviceType === 'PICKUP_DROP')) return true;
      if (q.includes('digha') && (c.name.toLowerCase().includes('digha') || c.serviceType === 'LOCAL_SIGHTSEEING')) return true;
      return matchName || matchCat || matchFeat;
    });
  }

  if (params?.vehicleType && params.vehicleType !== 'ALL') {
    results = results.filter(c => c.category === params.vehicleType);
  }

  if (params?.passengers) {
    const pax = parseInt(params.passengers) || 1;
    results = results.filter(c => c.seatingCapacity >= pax);
  }

  if (params?.acOnly) {
    results = results.filter(c => c.name.includes('AC') || c.features.some(f => f.includes('AC')));
  }

  return results;
}

/**
 * TOUR / PACKAGE SEARCH & FILTER (Sections 4 & 15)
 */
export function searchTours(
  packages: TravelPackage[],
  params?: Partial<TourSearchParams>,
  globalQuery?: string
): TravelPackage[] {
  let results = [...packages];

  if (globalQuery && globalQuery.trim()) {
    const q = globalQuery.toLowerCase().trim();
    results = results.filter(p => {
      const matchName = p.name.toLowerCase().includes(q);
      const matchDest = p.destination.toLowerCase().includes(q);
      const matchOverview = p.overview.toLowerCase().includes(q);
      const matchActivities = p.activities.some(a => a.toLowerCase().includes(q));
      const matchBadge = p.badge?.toLowerCase().includes(q) || false;
      const matchCategory = p.category.toLowerCase().includes(q);

      if (q.includes('weekend') && (p.name.toLowerCase().includes('weekend') || p.durationDays <= 3)) return true;
      if (q.includes('family') && (p.name.toLowerCase().includes('family') || p.badge?.toLowerCase().includes('family'))) return true;
      if (q.includes('combo') && p.name.toLowerCase().includes('combo')) return true;
      if (q.includes('2 nights') && p.duration.toLowerCase().includes('2 nights')) return true;
      if (q.includes('3 nights') && p.duration.toLowerCase().includes('3 nights')) return true;

      return matchName || matchDest || matchOverview || matchActivities || matchBadge || matchCategory;
    });
  }

  if (params?.destination && params.destination.trim() && params.destination !== 'All' && !params.destination.toLowerCase().includes('all')) {
    const dest = params.destination.toLowerCase().trim();
    results = results.filter(p => p.destination.toLowerCase().includes(dest));
  }

  if (params?.duration && params.duration !== 'ALL' && params.duration !== 'All Durations') {
    const dur = params.duration.toLowerCase();
    results = results.filter(p => {
      if (dur.includes('2 night') || dur.includes('3 day')) return p.durationDays <= 3;
      if (dur.includes('3 night') || dur.includes('4 day')) return p.durationDays === 4;
      if (dur.includes('4+') || dur.includes('5 night') || dur.includes('6 day')) return p.durationDays >= 5;
      return true;
    });
  }

  if (params?.category && params.category !== 'ALL') {
    results = results.filter(p => p.category === params.category);
  }

  return results;
}

/**
 * ACTIVITY SEARCH & FILTER (Sections 5 & 15)
 */
export function searchActivities(
  activities: WaterActivity[],
  sightseeing: SightseeingTour[],
  params?: Partial<ActivitySearchParams>,
  globalQuery?: string
): { activities: WaterActivity[]; sightseeing: SightseeingTour[] } {
  let matchedActs = [...activities];
  let matchedSight = [...sightseeing];

  if (globalQuery && globalQuery.trim()) {
    const q = globalQuery.toLowerCase().trim();
    matchedActs = matchedActs.filter(a => {
      const matchName = a.name.toLowerCase().includes(q);
      const matchLoc = a.location.toLowerCase().includes(q);
      const matchDesc = a.description.toLowerCase().includes(q);
      if (q.includes('water') || q.includes('sports')) return true;
      if (q.includes('jet ski') && a.name.toLowerCase().includes('jet ski')) return true;
      if (q.includes('banana') && a.name.toLowerCase().includes('banana')) return true;
      if (q.includes('parasail') && a.name.toLowerCase().includes('parasail')) return true;
      if (q.includes('boat') && (a.name.toLowerCase().includes('boat') || a.name.toLowerCase().includes('speed'))) return true;
      if (q.includes('photo') && a.name.toLowerCase().includes('photo')) return true;
      if (q.includes('atv') && a.name.toLowerCase().includes('atv')) return true;
      return matchName || matchLoc || matchDesc;
    });

    matchedSight = matchedSight.filter(s => {
      return s.name.toLowerCase().includes(q) ||
        s.destination.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q) ||
        s.highlights.some(h => h.toLowerCase().includes(q));
    });
  }

  if (params?.destination && params.destination.trim() && params.destination !== 'All' && !params.destination.toLowerCase().includes('all')) {
    const dest = params.destination.toLowerCase().trim();
    matchedActs = matchedActs.filter(a => a.location.toLowerCase().includes(dest));
    matchedSight = matchedSight.filter(s => s.destination.toLowerCase().includes(dest));
  }

  if (params?.activityType && params.activityType !== 'ALL' && params.activityType !== 'All Activities') {
    const at = params.activityType.toLowerCase();
    matchedActs = matchedActs.filter(a => a.name.toLowerCase().includes(at) || a.description.toLowerCase().includes(at));
  }

  return { activities: matchedActs, sightseeing: matchedSight };
}

/**
 * BIKE SEARCH & FILTER (Sections 6 & 15)
 */
export function searchBikes(
  bikes: BikeRental[],
  params?: Partial<BikeSearchParams>,
  globalQuery?: string
): BikeRental[] {
  let results = [...bikes];

  if (globalQuery && globalQuery.trim()) {
    const q = globalQuery.toLowerCase().trim();
    results = results.filter(b => {
      const matchName = b.name.toLowerCase().includes(q);
      const matchType = b.type.toLowerCase().includes(q);
      const matchLoc = b.pickupLocation.toLowerCase().includes(q);
      if (q.includes('scooter') || q.includes('activa') && b.type === 'SCOOTER') return true;
      if (q.includes('cruiser') || q.includes('bullet') || q.includes('royal enfield') && b.type === 'CRUISER') return true;
      if (q.includes('gear') || q.includes('sports') || q.includes('pulsar') && b.type === 'SPORTS') return true;
      return matchName || matchType || matchLoc;
    });
  }

  if (params?.bikeType && params.bikeType !== 'ALL' && params.bikeType !== 'All Types') {
    const bt = params.bikeType.toUpperCase();
    if (bt.includes('SCOOTER')) results = results.filter(b => b.type === 'SCOOTER');
    else if (bt.includes('CRUISER')) results = results.filter(b => b.type === 'CRUISER');
    else if (bt.includes('SPORTS') || bt.includes('GEAR')) results = results.filter(b => b.type === 'SPORTS');
  }

  if (params?.pickupLocation && params.pickupLocation.trim() && params.pickupLocation !== 'All') {
    const loc = params.pickupLocation.toLowerCase();
    results = results.filter(b => b.pickupLocation.toLowerCase().includes(loc) || loc.includes('digha'));
  }

  return results;
}
