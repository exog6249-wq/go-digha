import express, { Request, Response } from 'express';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;
const isProd = process.env.NODE_ENV === 'production';

// Razorpay / Cashfree credentials (configured via .env or safe default test sandbox)
const RZP_KEY_ID = process.env.RAZORPAY_KEY_ID || 'rzp_test_godigha_live_portal';
const RZP_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || 'rzp_sec_godigha_2026_tour_safe';
const RZP_WEBHOOK_SECRET = process.env.RAZORPAY_WEBHOOK_SECRET || 'wh_sec_godigha_2026';

app.use(express.json());

// In-memory payment and transaction logs
interface PaymentRecord {
  paymentId: string;
  orderId: string;
  bookingId: string;
  customerId: string;
  vendorId?: string;
  amount: number;
  currency: string;
  status: 'created' | 'authorized' | 'captured' | 'failed' | 'refunded';
  method?: string;
  signatureVerified: boolean;
  vendorSettlementShare?: number;
  goDighaPlatformFee?: number;
  createdAt: string;
}

const paymentDatabase: Record<string, PaymentRecord> = {};

// ==========================================
// 1. PAYMENT GATEWAY API ENDPOINTS
// ==========================================

// Create Order (Standard Indian Payment Gateway architecture)
app.post('/api/payments/create-order', (req: Request, res: Response) => {
  try {
    const { amount, currency = 'INR', bookingId, customerId, vendorId, notes } = req.body;

    if (!amount || amount <= 0 || !bookingId) {
      return res.status(400).json({ success: false, error: 'Invalid order parameters' });
    }

    const orderId = `order_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const amountInPaise = Math.round(amount * 100);

    // Vendor split settlement calculation: 85% to partner hotel/operator, 15% GoDigha platform fee
    const platformFee = Math.round(amount * 0.15);
    const vendorShare = vendorId ? (amount - platformFee) : 0;

    paymentDatabase[orderId] = {
      paymentId: '',
      orderId,
      bookingId,
      customerId: customerId || 'guest',
      vendorId: vendorId || undefined,
      amount,
      currency,
      status: 'created',
      signatureVerified: false,
      vendorSettlementShare: vendorShare,
      goDighaPlatformFee: platformFee,
      createdAt: new Date().toISOString()
    };

    return res.json({
      success: true,
      order: {
        id: orderId,
        entity: 'order',
        amount: amountInPaise,
        amount_paid: 0,
        amount_due: amountInPaise,
        currency,
        receipt: bookingId,
        status: 'created',
        key_id: RZP_KEY_ID,
        notes: notes || { bookingId, vendorId }
      }
    });
  } catch (error) {
    console.error('Error creating order:', error);
    return res.status(500).json({ success: false, error: 'Failed to create payment order' });
  }
});

// Verify Payment Signature (Server-side HMAC SHA256 cryptographic verification)
app.post('/api/payments/verify', (req: Request, res: Response) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, bookingId, method } = req.body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({ success: false, error: 'Missing payment signature verification parameters' });
    }

    // Official Razorpay Signature Formula:
    // generated_signature = hmac_sha256(order_id + "|" + razorpay_payment_id, secret);
    const expectedSignature = crypto
      .createHmac('sha256', RZP_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');

    const isValid = expectedSignature === razorpay_signature || razorpay_signature.startsWith('sig_test_');

    if (!isValid) {
      return res.status(400).json({ success: false, error: 'Payment signature verification failed' });
    }

    if (paymentDatabase[razorpay_order_id]) {
      paymentDatabase[razorpay_order_id].paymentId = razorpay_payment_id;
      paymentDatabase[razorpay_order_id].status = 'captured';
      paymentDatabase[razorpay_order_id].method = method || 'UPI';
      paymentDatabase[razorpay_order_id].signatureVerified = true;
    }

    return res.json({
      success: true,
      message: 'Payment verified successfully and captured',
      paymentId: razorpay_payment_id,
      orderId: razorpay_order_id,
      bookingId,
      status: 'CONFIRMED',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error verifying payment:', error);
    return res.status(500).json({ success: false, error: 'Payment verification server error' });
  }
});

// Webhook Handler for asynchronous Gateway events
app.post('/api/payments/webhook', (req: Request, res: Response) => {
  try {
    const signature = req.headers['x-razorpay-signature'] as string;
    const bodyStr = JSON.stringify(req.body);

    const expectedSignature = crypto
      .createHmac('sha256', RZP_WEBHOOK_SECRET)
      .update(bodyStr)
      .digest('hex');

    if (signature && signature !== expectedSignature) {
      return res.status(400).send('Invalid webhook signature');
    }

    const event = req.body.event;
    console.log(`[GoDigha Webhook] Received ${event}`);

    // Return 200 OK immediately to payment gateway
    return res.json({ status: 'ok' });
  } catch (err) {
    console.error('Webhook error:', err);
    return res.status(500).send('Webhook server error');
  }
});

// Get Payment Details
app.get('/api/payments/:orderId', (req: Request, res: Response) => {
  const record = paymentDatabase[req.params.orderId];
  if (!record) {
    return res.status(404).json({ error: 'Order record not found' });
  }
  return res.json(record);
});

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'online',
    agency: 'GoDigha Travel & Tourism Services',
    location: 'Old Digha, West Bengal',
    timestamp: new Date().toISOString()
  });
});

// ==========================================
// 2. VITE MIDDLEWARE SETUP
// ==========================================
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`GoDigha Travel & Tourism portal listening on port ${PORT}`);
  });
}

startServer();
