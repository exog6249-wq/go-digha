# GoDigha Travel & Tourism Services — Production Deployment & Architecture Guide

## 1. Overview
GoDigha Travel & Tourism Services is a full-stack travel agency portal and marketplace platform built for **Old Digha, West Bengal 721428, India** (Google Plus Code: `JGFG+39 Digha, West Bengal`).

---

## 2. Architecture & Components

```
├── server.ts                       # Express backend (Port 3000)
│   ├── /api/payments/create-order  # Razorpay order generation endpoint
│   ├── /api/payments/verify        # Cryptographic HMAC-SHA256 signature verification
│   ├── /api/payments/webhook       # Asynchronous webhook handler for payment events
│   └── Vite middleware             # Seamless SSR & SPA routing
├── src/
│   ├── types/index.ts              # Domain entities (Packages, Hotels, Bookings, Transports, Enquiries)
│   ├── data/mockData.ts            # Authentic seed data with verified Google reviews & 5.0 rating
│   ├── services/storage.ts         # Reactive database persistence layer with event dispatching
│   ├── components/
│   │   ├── Header.tsx              # Deep nautical blue header with circular GoDigha badge
│   │   ├── WhatsAppRibbon.tsx      # Exact orange contact ribbon (+91 88491 25029)
│   │   ├── OurServicesGrid.tsx     # 13-service icon grid matching reference design
│   │   ├── ExploreTopTours.tsx     # 4-column rounded cards grid matching reference
│   │   ├── HeroSearch.tsx          # Multi-parameter travel planning search engine
│   │   ├── HotelsSection.tsx       # Associated Digha & Mandarmani accommodation module
│   │   ├── TransportationSection.tsx # Cabs, station pickups, 17-seater Tempo Travellers
│   │   ├── ExperiencesSection.tsx  # Water sports, rental bikes, sightseeing
│   │   ├── CorporateEventsSection.tsx # MICE, conferences, DJ, banquet halls, catering
│   │   ├── CustomerDashboard.tsx   # Traveller portal (My Trips, Bookings, GoCash wallet)
│   │   ├── VendorPortal.tsx        # Isolated hotelier portal (room rates & 85% payout share)
│   │   ├── AdminPortal.tsx         # Super admin console (packages, bookings, enquiries)
│   │   ├── BookingModal.tsx        # Booking engine with guest roster & discounts
│   │   ├── PaymentModal.tsx        # Razorpay checkout with instant printable voucher
│   │   └── BottomNav.tsx           # Mobile dock navigation with elevated center action
```

---

## 3. Environment Variables (.env)

```env
# Gateway & Server Credentials
PORT=3000
NODE_ENV=production
RAZORPAY_KEY_ID="rzp_live_your_actual_key_id"
RAZORPAY_KEY_SECRET="your_actual_key_secret"
RAZORPAY_WEBHOOK_SECRET="wh_sec_your_webhook_secret"

# Agency Hotline Configuration
VITE_GODIGHA_PHONE="088491 25029"
VITE_GODIGHA_WHATSAPP="+918849125029"
```

---

## 4. Payment Gateway & Split Settlement Architecture

1. **Order Creation (`/api/payments/create-order`)**:
   - Customer initiates booking for a package or room.
   - Backend calculates base amount + 5% GST minus discounts/GoCash points.
   - Backend creates an Indian Gateway order with order ID `order_...`.
   - Splits payment: 85% allotted to the assigned partner hotel/service account, 15% platform management fee for GoDigha.

2. **Cryptographic Verification (`/api/payments/verify`)**:
   - Customer completes UPI/Card authorization.
   - Gateway returns `razorpay_order_id`, `razorpay_payment_id`, and `razorpay_signature`.
   - Server computes:
     `HMAC-SHA256(razorpay_order_id + "|" + razorpay_payment_id, RAZORPAY_KEY_SECRET)`
   - Only when signatures match is booking state set to `CONFIRMED`.

3. **Asynchronous Webhook (`/api/payments/webhook`)**:
   - Handles `payment.captured`, `order.paid`, `payment.failed`.
   - Validates `x-razorpay-signature` against `RAZORPAY_WEBHOOK_SECRET`.

---

## 5. Role-Based Access Control (RBAC)

- **CUSTOMER**: Access to own upcoming trips, booking vouchers, GoCash loyalty wallet, and enquiry tracking.
- **VENDOR / PARTNER**: Isolated property desk. Can only view and update tariffs for their own assigned hotel (e.g. Samir Mandal at Hotel Sea Star Grand Digha) and view net payouts.
- **ADMIN**: Complete GoDigha management suite: add packages, modify destinations, approve bookings, adjust enquiry pipelines, review revenue metrics.

---

## 6. Production Deployment Commands

```bash
# 1. Install dependencies
npm install

# 2. Build frontend assets
npm run build

# 3. Start full-stack server
npm run start
```
GoDigha will run on `http://0.0.0.0:3000` ready for production traffic.
